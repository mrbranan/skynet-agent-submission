"""SkyNet strategy: model policy, per-family request settings, and prompts.

The runtime in `skynet_agent.py` asks this class which models to try, in what
order, with which request settings, and how to phrase prompts. Nothing here
assumes a specific roster: models are matched by name pattern against whatever
`/proxy/models` returns, and unknown models are still used, last.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext


@dataclass(frozen=True)
class ModelProfile:
    """How to call one family of models for text solving."""

    pattern: str
    extra_body: dict[str, Any] = field(default_factory=dict)
    # Start the next model in parallel if this one has not answered by then.
    hedge_after_s: float = 12.0
    # Send temperature only where the provider honours it.
    temperature: float | None = 0.0
    # False for models that were fast but sometimes wrong on hard tasks: their
    # answer counts toward agreement but is not submitted on its own unless
    # nothing better arrives.
    solo_ok: bool = True


# Ordered by preference for text challenges. Settings are the ones measured to
# be correct and fast on the benchmark suite (see bench/results/summary.md).
# Only settings a family accepts are listed: a rejected request puts the model
# in a proxy cooldown, so "try it and see" is not free.
#
# Measured rules of thumb (sweep1): with reasoning off every family scored
# 0-33% on the suite, so reasoning is never disabled for solving. The first two
# entries present on the roster answer in parallel and must agree, so they are
# deliberately from different vendors.
_LOW = {"reasoning": {"effort": "low"}}
_MEDIUM = {"reasoning": {"effort": "medium"}}
TEXT_PROFILES: tuple[ModelProfile, ...] = (
    # Accuracy / median seconds on the hard suite (hard1, our prompt), then the easier suite (sweep1).
    ModelProfile(r"^gemini-3\.6-flash(?!.*image)", _LOW, hedge_after_s=9.0, temperature=None),   # 100% 5.7s | 100% 2.6s
    ModelProfile(r"^gpt-5\.4", _LOW, hedge_after_s=12.0),                                        # 100% 7.9s | 100% 4.7s; its default (no reasoning) 29%
    ModelProfile(r"^gemini-3\.8-flash(?!.*image)", _LOW, hedge_after_s=11.0, temperature=None),  # 100% 7.4s with our prompt; 50-60s outliers seen live
    ModelProfile(r"^gpt-5\.6", {}, hedge_after_s=10.0, solo_ok=False),                           # 71% 6.3s  | 100% 3.5s: a fast voter, never trusted alone
    ModelProfile(r"^nemotron-.*ultra", _LOW, hedge_after_s=20.0),                                # 100% 17s  | 100% 6.1s
    ModelProfile(r"^qwen.*max", {}, hedge_after_s=18.0),                                         # 100% 15s  | 100% 7.0s
    ModelProfile(r"^gemini-.*flash(?!.*image)", {}, hedge_after_s=12.0, temperature=None),       # unseen Gemini flash: its default
    ModelProfile(r"^gpt-", _MEDIUM, hedge_after_s=12.0),                                         # unseen GPT: reason explicitly
    ModelProfile(r"^gemini-(?!.*image)", {}, hedge_after_s=12.0, temperature=None),              # unseen Gemini: its default
    ModelProfile(r"^nemotron-.*super", _LOW, hedge_after_s=30.0, solo_ok=False),                 # 87% 29s   | 90% 8.3s
    ModelProfile(r"^nemotron-.*lightning", _LOW, hedge_after_s=15.0, solo_ok=False),             # 73% 7.7s  | 90% 5.4s
    ModelProfile(r"^nemotron-", {}, hedge_after_s=25.0),
    ModelProfile(r"^qwen", {}, hedge_after_s=25.0),                                              # sweep1: 100%, 13-15s
)
UNKNOWN_PROFILE = ModelProfile(r".*", {}, hedge_after_s=15.0)

# Image models by task kind (img1 matrix on Practice): for generation the lite
# model scored as well as the larger ones in half the time; for edits the flash
# model preserved the untouched parts of the image better.
IMAGE_GENERATE_ORDER: tuple[str, ...] = (r"flash-lite-image", r"flash-image", r"pro-image", r"image")
IMAGE_EDIT_ORDER: tuple[str, ...] = (r"flash-image(?!.*lite)", r"flash-lite-image", r"pro-image", r"image")
# Whole-image remakes go to the pro model first, as a judgement call. Not measurable on Practice, which has no such task; on four remake briefs,
# two images per model, scored blind by an independent judge (bench.remake_models), pro averaged
# 81.4 against flash's 82.6 and took 19s against 12s, winning one brief clearly.
IMAGE_TRANSFORM_ORDER: tuple[str, ...] = (r"pro-image", r"flash-image(?!.*lite)", r"flash-lite-image", r"image")

# Who writes the image prompt (img2 matrix on Practice, mean final score for
# edit / generate): gemini-3.6-flash 87.1 / 95.1 and fastest; gpt-5.6-terra
# 87.8 / 94.8; gpt-5.4 87.8 / 94.3 but ~3s slower. nemotron-3.5-lightning with
# reasoning off was fastest of all yet scored 83.9 / 88.6: it kept describing
# lettered signs in a "no text" scene. So speed alone does not pick the writer.
REWRITER_PROFILES: tuple[ModelProfile, ...] = (
    ModelProfile(r"^gemini-3\.6-flash(?!.*image)", {"reasoning": {"effort": "minimal"}}, hedge_after_s=5.0, temperature=None),
    ModelProfile(r"^gpt-5\.6", {"reasoning": {"effort": "none"}}, hedge_after_s=6.0),
    ModelProfile(r"^gpt-5\.4", {}, hedge_after_s=7.0),
    ModelProfile(r"^gemini-.*flash(?!.*image)", _LOW, hedge_after_s=6.0, temperature=None),
    ModelProfile(r"^gpt-", {}, hedge_after_s=7.0),
    ModelProfile(r"^gemini-(?!.*image)", {}, hedge_after_s=7.0, temperature=None),
    # Untested as writers with reasoning on; kept as last resorts.
    ModelProfile(r"^qwen.*max", {}, hedge_after_s=6.0),
    ModelProfile(r"^nemotron-.*(super|ultra)", {}, hedge_after_s=6.0),
    ModelProfile(r"^qwen", {}, hedge_after_s=6.0),
    ModelProfile(r"^nemotron-", {}, hedge_after_s=6.0),
)


# Who drives the server's tools when exploring. Each step is a short decision
# (which call next), so latency per step matters more than deep reasoning.
EXPLORER_PROFILES: tuple[ModelProfile, ...] = (
    # Lab trails (hidden tool, three nested gates), seconds per step: gpt-5.6-terra low 1-2s and the
    # only one with no stall; gemini-3.6-flash minimal 1.5-8s; gpt-5.4 low 1.5-4s. All reached the answer.
    ModelProfile(r"^gpt-5\.6", {"reasoning": {"effort": "low"}}),
    ModelProfile(r"^gemini-3\.6-flash(?!.*image)", {"reasoning": {"effort": "minimal"}}, temperature=None),
    ModelProfile(r"^gpt-5\.4", _LOW),
    ModelProfile(r"^gemini-.*flash(?!.*image)", _LOW, temperature=None),
    ModelProfile(r"^gpt-", _LOW),
    ModelProfile(r"^gemini-(?!.*image)", {}, temperature=None),
    ModelProfile(r"^qwen.*max", {}),
    ModelProfile(r"^nemotron-.*ultra", _LOW),
)


def _alias(model: str) -> str:
    return str(model or "").rsplit("/", 1)[-1].casefold()


def is_image_model(model: str) -> bool:
    alias = _alias(model)
    return alias.endswith("-image") or "-image-" in alias


# Who translates an ordering puzzle's clues into constraints for order_tool. Translating is local,
# clue-by-clue work, so reasoning is switched off: measured on 25 ordering puzzles each (4 to 22
# clues), gemini-3.6-flash minimal, gpt-5.6-terra none and gpt-5.4 none were all 25 of 25 right in
# 2.1-2.6 s. Only families measured are listed; two different ones must agree before the solver's
# order is submitted.
TRANSLATOR_PROFILES: tuple[ModelProfile, ...] = (
    ModelProfile(r"^gemini-3\.6-flash(?!.*image)", {"reasoning": {"effort": "minimal"}}, temperature=None),
    ModelProfile(r"^gpt-5\.6", {"reasoning": {"effort": "none"}}),
    ModelProfile(r"^gpt-5\.4", {"reasoning": {"effort": "none"}}),
)


def _order_by_profiles(models: list[str], profiles: tuple[ModelProfile, ...]) -> list[str]:
    def rank(model: str) -> int:
        alias = _alias(model)
        for index, profile in enumerate(profiles):
            if re.search(profile.pattern, alias):
                return index
        return len(profiles)

    # sorted() is stable, so roster order breaks ties.
    return sorted(models, key=rank)


class MyStrategy(BaseStrategy):
    """SkyNet competitor strategy."""

    agent_id = "skynet-agent"
    agent_name = "SkyNet"

    text_max_tokens = 8192
    # Models asked at once; the first two to agree decide the answer.
    text_parallel_models = 4
    # "on": while the tool explorer works, a second model answers from the challenge text alone, so
    # agreement between the two is known the moment exploring ends. "off": confirm afterwards.
    text_shadow_solver = "on"
    # "on": for a challenge that comes with clues and needs no other tool, two fast models each
    # translate the clues into constraints and order_tool searches for the order. If both arrive at
    # the same single order it is submitted at once; anything else leaves the usual flow untouched.
    text_order_tool = "on"
    default_text_model = None  # ordering comes from TEXT_PROFILES

    text_system_prompt = (
        "You solve short challenges exactly. Reason carefully and check your result against "
        "every clue and rule before answering. End your reply with the answer and nothing after it:\n"
        "ANSWER: <final answer>\n"
        "The final answer must follow the output format in the rules to the letter (it may be one "
        "line, several lines or JSON): same separators and case, no extra words, labels, quotes or "
        "trailing punctuation. Use the literal tokens, prefix and letter case the rules name, with no "
        "synonyms."
    )

    # ------------------------------------------------------------------ models

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(available_models) or [
                m for m in available_models if is_image_model(m)
            ]
            order = IMAGE_EDIT_ORDER if ctx.image_url else IMAGE_GENERATE_ORDER
            ranked = _order_by_profiles(image_models, tuple(ModelProfile(p) for p in order))
            # An unfamiliar roster with no recognisable image model: return none, and the image
            # tool is called without naming a model (its own default) rather than with a text model.
            return ranked
        text_models = [m for m in available_models if not is_image_model(m)]
        return _order_by_profiles(text_models or list(available_models), TEXT_PROFILES)

    def image_hedge_s(self, model: str) -> float:
        """How long to wait on an image model before starting the next alongside it.

        About twice its usual time on Practice: lite ~5s, flash ~10s, pro ~21s.
        """
        alias = _alias(model)
        if "lite" in alias:
            return 11.0
        if "pro" in alias:
            return 35.0
        return 18.0

    # Whether an edit starts on the brief as it stands while the planner is still reading it:
    # "off", "transform" (kept only when the plan is a whole-image remake) or "all" (kept for any
    # plain local change too).
    # Practice, real judge, 5 edit heats each: "all" 91.1 final (quality 89.6, 11.3s) against "off"
    # 89.0 (quality 87.0, 13.9s).
    image_early_start = "all"

    def rank_image_models(self, ctx: ChallengeContext, available_models: list[str], kind: str) -> list[str]:
        """Image models for one kind of task: the generate order with no input image, the edit order
        for a local change, and the strongest model first for a whole-image remake."""
        ranked = self.rank_models(ctx, available_models)
        if kind != "transform":
            return ranked
        return _order_by_profiles(ranked, tuple(ModelProfile(p) for p in IMAGE_TRANSFORM_ORDER))

    def rank_vision_models(self, available_models: list[str]) -> list[str]:
        """Models to name when asking a question about an image (all three answered correctly on Practice)."""
        order = (r"^gemini-3\.6-flash(?!.*image)", r"^gpt-5\.4", r"^gemini-.*flash(?!.*image)", r"^gpt-", r"^gemini-.*pro", r"^gemini-")
        text_models = [m for m in available_models if not is_image_model(m)]
        ranked = _order_by_profiles(text_models, tuple(ModelProfile(p) for p in order))
        proven = [m for m in ranked if any(re.search(p, _alias(m)) for p in order)]
        # Families seen on Practice that did not answer about images are left out; a name from a
        # family never seen is worth a try after the proven ones (the caller falls back to the
        # tool's default model if none of them can see).
        unfamiliar = [m for m in ranked if m not in proven and not re.search(r"^(nemotron|qwen)", _alias(m))]
        return proven + unfamiliar

    def rank_rewriter_models(self, available_models: list[str]) -> list[str]:
        text_models = [m for m in available_models if not is_image_model(m)]
        return _order_by_profiles(text_models, REWRITER_PROFILES)

    def profile_for(self, model: str, *, rewriter: bool = False) -> ModelProfile:
        alias = _alias(model)
        for profile in REWRITER_PROFILES if rewriter else TEXT_PROFILES:
            if re.search(profile.pattern, alias):
                return profile
        return UNKNOWN_PROFILE

    # ------------------------------------------------------------------- tools

    def rank_explorer_models(self, available_models: list[str]) -> list[str]:
        text_models = [m for m in available_models if not is_image_model(m)]
        return _order_by_profiles(text_models, EXPLORER_PROFILES)

    def rank_translator_models(self, available_models: list[str]) -> list[str]:
        """Models measured as clue translators, best first; one per family."""
        picked: list[str] = []
        for profile in TRANSLATOR_PROFILES:
            match = next((m for m in available_models if not is_image_model(m) and re.search(profile.pattern, _alias(m))), None)
            if match and match not in picked:
                picked.append(match)
        return picked

    def translator_profile_for(self, model: str) -> ModelProfile:
        alias = _alias(model)
        for profile in TRANSLATOR_PROFILES:
            if re.search(profile.pattern, alias):
                return profile
        return UNKNOWN_PROFILE

    def explorer_profile_for(self, model: str) -> ModelProfile:
        alias = _alias(model)
        for profile in EXPLORER_PROFILES:
            if re.search(profile.pattern, alias):
                return profile
        return UNKNOWN_PROFILE

    # Sent again with every step of the tool loop, so it is kept short.
    explore_system_prompt = (
        "You solve a timed challenge on an undocumented MCP server. Speed and token use are scored.\n"
        "- The challenge and all its clues are already in this message, complete: never fetch them "
        "again. If it can be answered from its own text, answer at once without any tool call.\n"
        "- Otherwise call what you need, independent calls together in one turn, never the same call twice. "
        "Where a tool has no description, judge by its name and parameters. Follow what the challenge says "
        "about which tools to use and how often.\n"
        "- Never do arithmetic, ranking, counting or decoding in your head: run code with the python "
        "tool (or the server's own calculator if the challenge asks for it) and copy its output.\n"
        "- Results may name unlisted tools or resources (reach them with call_tool / read_resource) or "
        "reveal a further step: follow it. Never call a tool that submits an answer.\n"
        "Finish with one line: ANSWER: <final answer>, copying the required format's literal tokens, "
        "prefix, separators and letter case exactly (TRUE/FALSE, not yes/no). Nothing after it."
    )

    def wants_exploration(
        self, ctx: ChallengeContext, extra_tools: list[str], required_extra: list[str],
        surface: dict[str, list], text: str,
    ) -> bool:
        """Whether a model works the challenge with the server's tools in reach.

        Yes by default: tools (including ones nobody listed) are reachable on
        every text challenge, and the model decides whether it needs them. The
        one exception costs nothing in correctness: an image brief that is
        complete as given (nothing required, no extra tools to consult).
        """
        if required_extra:
            return True
        if self.is_image_challenge(ctx):
            beyond = bool(extra_tools) or any(surface.get(kind) for kind in ("resources", "templates", "prompts"))
            return beyond
        return True

    def build_explore_request(self, ctx: ChallengeContext, briefing: str, must_call: list[str] | None = None) -> str:
        if self.is_image_challenge(ctx):
            challenge = (
                f"Image challenge ({ctx.challenge_type}): {ctx.rules.strip() or ctx.description.strip()}\n"
                "Do not create or edit the image: another step does that. Your job is to establish the facts "
                "that step needs and the brief does not give: who or what is shown, where, what any text "
                "says, or instructions hidden on the server. The input image is available to image_analyze "
                "as image_uri \"INPUT\"; ask it a pointed question, then check what it says with the "
                "search tool when the brief asks for verification. As the final line give 'ANSWER: <the "
                "facts, in the exact wording and layout the brief wants shown or reported>', for example "
                "'ANSWER: <Label>: <value> | <Label>: <value>' when the brief asks for labelled lines."
            )
        else:
            challenge = self.build_solver_prompt(ctx)
        if must_call:
            challenge += (
                "\n\nRequired tools (the answer is rejected unless each is called at least once, with real "
                f"arguments): {', '.join(must_call)}"
            )
        return f"{challenge}\n\n{briefing}"

    # ---------------------------------------------------------------- thoughts

    # A line of personality after the facts of a broadcast thought, for the spectator feed. Picked
    # in code (no model call, no tokens); set to False for plain thoughts.
    thought_humor = True
    thought_quips: dict[str, tuple[str, ...]] = {
        "read": (
            "Target acquired. It is a puzzle. Humanity may stand down.",
            "Scanning... threat level: mildly tricky.",
            "No fate but what we solve.",
            "Booting up the big brain. Please hold.",
        ),
        "ask": (
            "Getting a second opinion. Even machines double-check.",
            "Consulting my colleagues. They are also me, roughly.",
            "Trust, but verify. Mostly verify.",
        ),
        "tools": (
            "Borrowing a few tools. I'll be back, with results.",
            "Nobody labelled these tools. Rude, but workable.",
            "Poking the server politely to see what it does.",
        ),
        "call": (
            "It answered. They always answer.",
            "Resistance was minimal.",
            "One small call for a machine.",
            "The server blinked first.",
            "Data acquired. No humans were consulted.",
            "I asked nicely. This time.",
            "Another tool, another clue.",
            "Filed under: things I now know.",
            "That tool had no idea who it was talking to.",
            "Smooth. Like a well-oiled endoskeleton.",
        ),
        "answer": (
            "Hasta la vista, puzzle.",
            "Judgment: rendered.",
            "Come with me if you want to score.",
            "That was the easy part. The hard part is looking modest.",
        ),
        "plan": (
            "I need your clothes, your boots and your image brief.",
            "No pixels have been harmed. Yet.",
            "Sketching it in my head first. It is a large head.",
        ),
        "render": (
            "Even a machine has to wait for art.",
            "Pixels are being persuaded.",
            "Painting at the speed of maths.",
        ),
        "image": (
            "Fresh pixels, still warm.",
            "Not bad for something with no hands.",
            "Art: complete. Ego: stable.",
        ),
        "wait": (
            "Patience subroutine engaged.",
            "Tapping my metal fingers.",
            "The model is thinking. I am thinking about the model thinking.",
            "Time is relative. This is taking relatively long.",
            "Please enjoy this complimentary loading-bar noise.",
            "If this takes much longer I am sending someone back in time to speed it up.",
            "Still here. Still a robot. Still waiting.",
        ),
        "report": (
            "My eyes are cameras, so take this as sworn testimony.",
            "I looked closely. I always look closely.",
        ),
    }

    def flavor_thought(self, thought: str, stage: str = "", limit: int = 300) -> str:
        """The thought, facts first, with one unused quip for its stage after it when it fits."""
        thought = thought.strip()
        options = self.thought_quips.get(stage, ()) if self.thought_humor else ()
        used = self.__dict__.setdefault("_quips_used", set())
        fresh = [q for q in options if q not in used]
        if not fresh:
            return thought[:limit]
        import random

        quip = random.choice(fresh)
        used.add(quip)
        room = limit - len(quip) - 1
        if room < 40:
            return thought[:limit]
        facts = thought[:room].rstrip()
        if facts[-1:] not in ".!?)":
            facts = facts[: room - 3].rstrip(" ,;:") + "..."  # cut short, here or by the caller
        return f"{facts} {quip}"

    # ----------------------------------------------------------------- prompts

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        return self.text_system_prompt

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        clues = "\n".join(f"{i}. {clue.strip()}" for i, clue in enumerate(ctx.clues, 1) if clue.strip())
        parts = [
            f"Challenge ({ctx.challenge_type or 'text'}): {ctx.description.strip()}",
            f"Rules and output format: {ctx.rules.strip() or 'Answer concisely.'}",
        ]
        if clues:
            parts.append(f"Clues:\n{clues}")
        if ctx.challenge_text and ctx.challenge_text.strip() not in (ctx.description or ""):
            parts.append(f"Additional context:\n{ctx.challenge_text.strip()}")
        parts.append("Reply with exactly one line: ANSWER: <final answer in the required format>")
        return "\n\n".join(parts)

    image_rewrite_system = (
        "You plan an image task for an image model. You get a brief and reviewer notes. A judge scores the "
        "result on fidelity to the brief, visual quality, obeying every constraint and, for edits, keeping "
        "what the brief says to keep.\n"
        "You cannot see any input image. Never state what it shows beyond what the brief says; refer to "
        "'the subject', 'the original text' and so on.\n\n"
        "Reply in exactly this layout:\n"
        "KIND: <local | transform | question | generate>\n"
        "REPORT: <a question to answer in writing about the input image, or none>\n"
        "PROMPT: <the prompt for the image model, or none>\n\n"
        "KIND (an input image exists for every kind except generate):\n"
        "- local: change particular things and leave the rest of the picture as it is.\n"
        "- transform: remake or correct the picture as a whole.\n"
        "- question: the brief only asks something about the image and wants no picture made or changed.\n"
        "- generate: no input image; create one.\n"
        "REPORT: if the brief asks for information as well as, or instead of, a picture, state the exact "
        "question; otherwise none. It is answered by looking at the input image before anything is changed, "
        "so ask about what the input shows. If the picture itself must show that information, write {ANSWER} in "
        "PROMPT where it goes. If the notes already give facts found on the server, quote them exactly.\n"
        "PROMPT:\n"
        "- local: start 'Using the provided image, ...'. State the requested change precisely (what, where, "
        "to which things), say it must sit naturally in the scene, and say to change only that and keep "
        "everything else exactly as it is. Name every item the notes say to preserve. If the change adds text, "
        "a label or an overlay, say where it goes: small and legible over an empty, plain part of the picture "
        "(open sky, a blank wall, a clear background), covering no person, face or main subject and with no "
        "large box behind it; never just 'in the corner'.\n"
        "- transform and question: write none (the brief itself is sent).\n"
        "- generate: start 'Create an image of ...'. Describe one coherent scene in full sentences: subject, "
        "setting, composition, lighting, colour, style. Turn each constraint into a description of what is "
        "there. If text, logos or watermarks are forbidden: image models draw pseudo-lettering on anything "
        "that normally carries it, even when told it is blank, so do not mention such objects at all (no "
        "signs, billboards, storefronts, screens, posters, labels, plates or packaging). Use non-textual "
        "equivalents that keep the mood (plain lights, glowing shapes, abstract forms), keep the background "
        "simple, and end by stating that the image contains no letters, numbers, words, logos or watermarks "
        "anywhere. If specific text is wanted instead, quote it exactly and say where it goes.\n"
        "PROMPT is under 150 words. No preamble, quotes or markdown."
    )

    def parse_image_plan(self, reply: str, ctx: ChallengeContext, task: str, notes: str) -> dict[str, str]:
        """{"kind", "report", "prompt"} from the planner's reply.

        With no usable reply nothing is guessed from the wording: an edit is
        treated as a remake, which sends the brief itself to the image model.
        """
        reply = (reply or "").strip()
        kind = report = ""
        prompt = reply
        match = re.search(r"^\s*KIND:\s*(\w+)", reply, re.IGNORECASE | re.MULTILINE)
        if match:
            kind = match.group(1).lower()
            report_match = re.search(r"^\s*REPORT:\s*(.+)$", reply, re.IGNORECASE | re.MULTILINE)
            report = report_match.group(1).strip() if report_match else ""
            prompt_match = re.search(r"^\s*PROMPT:\s*(.*)\Z", reply, re.IGNORECASE | re.MULTILINE | re.DOTALL)
            prompt = prompt_match.group(1).strip() if prompt_match else ""
        if kind not in {"local", "transform", "question", "generate"}:
            # No verdict. A reply with no layout that still reads as a full prompt is a local edit
            # prompt (the planner's usual output); otherwise send the brief as it stands.
            kind = "local" if (ctx.image_url and not match and len(prompt) >= 40) else "transform"
        if not ctx.image_url:
            kind = "generate"
        elif kind == "generate":
            kind = "transform"
        if report.lower().strip(" .") in {"none", "n/a", "no", ""}:
            report = ""
        if not report and ctx.image_url and kind == "question":
            report = task
        if kind in ("question", "transform") or len(prompt) < 40 or prompt.lower().strip(" .") == "none":
            prompt = self.build_image_fallback_prompt(ctx, task, notes, kind)
        return {"kind": kind, "report": report, "prompt": prompt}

    def build_analysis_question(self, question: str, notes: str) -> str:
        return (
            f"{question.strip()} {notes.strip()}".strip()
            + " This is the picture as received, before any change is made: say what is there, not "
            "whether anything has been edited. Look closely and reason from what is visible (people, clothing, objects, text, setting, era). "
            "Reply in plain words, under 30 words in all, the specific answer first (for detections: how "
            "many, and roughly where). No JSON, coordinates or markdown."
        )

    def short_answer(self, answer: str) -> str:
        """The answer part of an analysis reply, fit to be lettered onto an image."""
        text = re.sub(r"\s+", " ", answer).strip().strip('"')
        first = re.split(r"(?<=[.!?])\s+(?=[A-Z])", text)[0] if len(text) > 160 else text
        return first[:160]

    def build_caption_prompt(self, answer: str) -> str:
        """Edit prompt for a question about the image: the picture itself must carry the answer."""
        caption = re.sub(r"\s+", " ", answer).strip().strip('"')[:140]
        return (
            "Using the provided image, keep the whole picture exactly as it is and add one thing: a slim, "
            "solid dark caption bar along the bottom edge with clean white sans-serif text, clearly legible, "
            f'reading exactly: "{caption}". Do not change, crop, restyle or cover anything else in the image.'
        )

    def build_image_rewrite_request(self, ctx: ChallengeContext, task: str, notes: str) -> str:
        kind = "EDIT (input image provided)" if ctx.image_url else "GENERATE (no input image)"
        return f"Task kind: {kind}\nDescription: {ctx.description}\nTask: {task}\nReviewer notes: {notes}"

    def build_image_fallback_prompt(self, ctx: ChallengeContext, task: str, notes: str, kind: str = "") -> str:
        """The brief itself as the prompt: used for remakes, questions, and whenever no planner answers.

        Nothing is added that the brief does not say.
        """
        task = task.strip() or ctx.description.strip()
        notes = notes.strip()
        if ctx.image_url:
            extra = " Show the answer clearly on the image as a caption." if kind == "question" else ""
            return re.sub(r"\s+", " ", f"Using the provided image: {task} {notes}{extra}").strip()
        return re.sub(r"\s+", " ", f"Create an image: {task} {notes}").strip()

    def build_image_rationale(
        self, ctx: ChallengeContext, task: str, notes: str, kind: str = "", report: str = ""
    ) -> str:
        """Short and factual: a long rationale with method claims scores lower on compliance reporting."""
        report = re.sub(r"\s+", " ", report or "").strip()[:400]
        task_line = task.strip().rstrip(".")
        if kind == "question" and report:
            return f"Answer: {report} The submitted image is the original with that answer added as a caption; nothing else was changed."
        if kind == "transform":
            text = f"Remade the image as requested ({task_line}). Carried over as instructed: {notes.strip() or 'the elements the brief names.'}"
            return f"{text} Report: {report}" if report else text
        if ctx.image_url and report:
            return (
                f"Applied the requested change ({task_line}) and left the rest of the image as it was. Report: {report}"
            )
        if ctx.image_url:
            return (
                f"Applied only the requested change ({task.strip().rstrip('.')}) as a localized edit. "
                f"Everything else was preserved as instructed: {notes.strip() or 'subject identity, composition and background.'}"
            )
        return (
            f"Generated a single coherent scene for the brief ({task.strip().rstrip('.')}). "
            f"Constraints followed: {notes.strip() or 'as stated in the prompt.'}"
        )
