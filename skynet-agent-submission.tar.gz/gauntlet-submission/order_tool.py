"""A constraint solver the models use for ordering puzzles.

A model reads the puzzle and writes each clue as one small expression over positions
(`pos["Alice"] < pos["Bob"]`); this module finds every order that satisfies all of them. The model
does the reading, the tool does the search: no wording is recognised here, so a reworded puzzle is
handled like any other.

Measured before it was wired in (three fast models with reasoning off, 25 ordering puzzles each,
from 4 to 22 clues, including two-part clues, gaps and odd/even slots): 75 of 75 right in 2-3 s,
where the same models answering directly got about 1 in 20 of the longer ones.

The expressions are never executed as code. They are parsed, checked against a short list of
permitted forms and evaluated by walking the tree.
"""

from __future__ import annotations

import ast
import json
import operator
import re
from typing import Any, Callable

MAX_ITEMS = 12
MAX_CONSTRAINTS = 80
MAX_EXPRESSION_CHARS = 400
# No number in a clue about at most twelve positions is anywhere near this.
MAX_NUMBER = 1_000_000
# Placements tried before the search gives up: a puzzle of 12 items with clues too weak to prune
# would otherwise run for minutes. Every puzzle measured needed fewer than 20,000.
MAX_PLACEMENTS = 400_000
# Expression nodes evaluated across one whole solve. A loop inside a loop inside an expression
# could otherwise make a single test expensive; the puzzles measured used well under a million.
MAX_STEPS = 3_000_000

SYSTEM_PROMPT = (
    "You translate an ordering puzzle into constraints for a solver. You do not solve it.\n"
    'Reply with one JSON object and nothing else: {"answer": "...", "items": [...], "separator": ", ", "constraints": [...]}.\n'
    'answer: what the task asks to be returned. "order" = every item exactly once, from position 1 to position n, joined by the separator '
    'and nothing else. "reversed" = the same list from position n down to position 1 (asked last to first, right to left, most recent first). '
    '"other" = anything else: a single item or a few of them, a number or count, a word such as AMBIGUOUS, JSON, numbered or separate lines, '
    'initials or any other rewriting of the names, or the list plus extra content.\n'
    "items: every item to be ordered, written exactly as it must appear in the final answer.\n"
    "separator: the exact text the answer format puts between items (usually a comma and a space).\n"
    "constraints: one Python boolean expression per clue, in clue order. pos[\"X\"] is the 1-based position of item X "
    "(1 = first, earliest, leftmost); n is the number of items. Allowed: integers, pos[...], n, + - * % //, abs() min() max() sum(), "
    "comparisons, in / not in with a tuple, and / or / not, and x if c else y. No other names, functions, strings or methods. "
    "A clue with two parts is one expression joined with and.\n"
    'Examples: "A is before B" -> pos["A"] < pos["B"]; "A is immediately after B" -> pos["A"] == pos["B"] + 1; '
    '"exactly one item between A and B" -> abs(pos["A"] - pos["B"]) == 2; "A is last" -> pos["A"] == n; '
    '"A is not first or second" -> pos["A"] not in (1, 2); "A and B are not adjacent" -> abs(pos["A"] - pos["B"]) > 1; '
    '"A is between B and C" -> min(pos["B"], pos["C"]) < pos["A"] < max(pos["B"], pos["C"]); '
    '"exactly two of A, B, C are in the first three" -> (pos["A"] <= 3) + (pos["B"] <= 3) + (pos["C"] <= 3) == 2; '
    '"if A is first then B is last" -> pos["A"] != 1 or pos["B"] == n.\n'
    "If the task is not purely putting one fixed set of items into a single order, or any clue cannot be written this way, "
    'or it needs a lookup, a calculation on other data or any tool, reply exactly {"items": [], "constraints": []}.'
)

_COMPARE: dict[type, Callable[[Any, Any], bool]] = {
    ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt, ast.LtE: operator.le, ast.Gt: operator.gt, ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b, ast.NotIn: lambda a, b: a not in b, ast.Is: operator.eq, ast.IsNot: operator.ne,
}
_FUNCTIONS = ("abs", "min", "max", "sum", "any", "all", "len", "range", "int", "bool")
MAX_COLLECTION = 64
# Every node kind an expression may contain. Anything else (attribute access other than
# [..].count(x), lambdas, names not listed, string operations, **, bit operations) is refused
# before the search starts.
_NODES = (
    ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub, ast.UAdd, ast.BinOp, ast.Add, ast.Sub, ast.Mult,
    ast.Mod, ast.FloorDiv, ast.Div, ast.Compare, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn, ast.Is, ast.IsNot,
    ast.IfExp, ast.Constant, ast.Name, ast.Load, ast.Store, ast.Subscript, ast.Call, ast.Attribute, ast.Tuple, ast.List, ast.Set,
    ast.GeneratorExp, ast.ListComp, ast.SetComp, ast.comprehension,
)


# Words in a task that mean the answer is not a plain row of names. The translating models are
# asked to say so themselves ("answer": "other"), and in a test two of three still called a JSON
# array a plain list, so the wording is checked as well. A task caught here is simply answered the
# usual way.
_NOT_A_PLAIN_LIST = re.compile(
    r"\b(json|yaml|xml|html|markdown|array|dictionary|dict|object|table|bullet(?:ed|s)?|numbered|one per line|per line|lines? per|each line|"
    r"separate lines?|new ?lines?|line breaks?|brackets?|braces|quoted|in quotes|quotation marks|initials?|first letters?|acronym|"
    r"abbreviat\w*|how many|number of|count of|sum of|total|which (?:one|item|person|team|event)|who (?:is|was|ate|came|presents?|stands?|finished)|"
    r"only the name of|only the (?:one|first|second|third|fourth|fifth|last|winner)(?! order)|position of|ambiguous|"
    r"explain|justify|reasoning|sentence|paragraph)\b",
    re.IGNORECASE,
)


def plain_list_wanted(task_text: str) -> bool:
    """False when the task's own wording asks for something other than the items in a row."""
    return not _NOT_A_PLAIN_LIST.search(task_text or "")


def build_user_prompt(description: str, rules: str, clues: list[str]) -> str:
    lines = [description.strip(), rules.strip(), "Clues:"] + [f"{i}. {clue}" for i, clue in enumerate(clues, 1)]
    return "\n".join(line for line in lines if line)


def _resolve(name: str, items: list[str]) -> str | None:
    """The item a model meant by `name`: exact, else the only one equal ignoring case, else the only
    one that differs by a leading category word ("Alpha" for "Team Alpha")."""
    if name in items:
        return name
    folded = name.casefold().strip()
    for same in (lambda item: item.casefold().strip() == folded,
                 lambda item: item.casefold().split()[-1:] == folded.split()[-1:] and bool(folded)):
        matches = [item for item in items if same(item)]
        if len(matches) == 1:
            return matches[0]
    return None


def _number(value: Any) -> int | float:
    """A truth value counts as 1 or 0, which is how "exactly two of these hold" is written."""
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)) and abs(value) <= MAX_NUMBER:
        return value
    raise ValueError("arithmetic is on small numbers only")


def compile_constraint(text: str, items: list[str], budget: list[int] | None = None) -> tuple[Callable[[dict[str, int]], bool], frozenset[str]]:
    """One clue expression as (test over positions, the items it reads). ValueError if it is not a permitted form.

    Permitted: integers, True/False, n, pos["Item"], + - * % // /, comparisons (chained too),
    in / not in, and / or / not, a if c else b, abs min max sum any all len int bool range,
    tuples/lists/sets of such values, [..].count(x), and a comprehension over a literal list of
    item names or integers. The expression is walked, never executed: nothing else can be reached.
    """
    if len(text) > MAX_EXPRESSION_CHARS:
        raise ValueError("expression too long")
    try:
        tree = ast.parse(text.strip(), mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"not an expression: {exc.msg}") from None
    count = len(items)
    names: set[str] = set()
    loop_names: set[str] = set()
    nodes = list(ast.walk(tree))
    if len(nodes) > 400:
        raise ValueError("expression too large")
    for node in nodes:
        if not isinstance(node, _NODES):
            raise ValueError(f"not permitted: {type(node).__name__}")
        if isinstance(node, ast.comprehension):
            if node.is_async or not isinstance(node.target, ast.Name) or node.target.id in ("pos", "n", *_FUNCTIONS):
                raise ValueError("not permitted: this kind of loop")
            loop_names.add(node.target.id)
    calls = {id(node.func) for node in nodes if isinstance(node, ast.Call)}
    subscripts = {id(node.slice) for node in nodes if isinstance(node, ast.Subscript)}
    for node in nodes:
        if isinstance(node, ast.Name):
            if node.id == "pos":
                continue  # only ever valid as pos[...]; checked where subscripts are
            if node.id in _FUNCTIONS:
                if id(node) not in calls:
                    raise ValueError(f"{node.id} must be called")
            elif node.id not in loop_names and node.id != "n":
                raise ValueError(f"unknown name {node.id}")
        elif isinstance(node, ast.Constant):
            if isinstance(node.value, str):
                found = _resolve(node.value, items)
                if found is None and id(node) in subscripts:
                    raise ValueError(f"unknown item {node.value!r}")
                if found is not None:
                    names.add(found)
            elif not (isinstance(node.value, (bool, int)) and abs(int(node.value)) <= 10_000):
                raise ValueError("only whole numbers, True/False and item names")
        elif isinstance(node, ast.Subscript):
            if not (isinstance(node.value, ast.Name) and node.value.id == "pos"
                    and (isinstance(node.slice, ast.Name) or (isinstance(node.slice, ast.Constant) and isinstance(node.slice.value, str)))):
                raise ValueError("only pos[\"Item\"] may be indexed")
        elif isinstance(node, ast.Call):
            method = (isinstance(node.func, ast.Attribute) and node.func.attr == "count"
                      and isinstance(node.func.value, (ast.List, ast.Tuple)) and len(node.args) == 1)
            if node.keywords or not (method or (isinstance(node.func, ast.Name) and node.func.id in _FUNCTIONS)):
                raise ValueError("this call is not permitted")
        elif isinstance(node, ast.Attribute) and id(node) not in calls:
            raise ValueError("not permitted: attribute access")
        elif isinstance(node, (ast.Tuple, ast.List, ast.Set)) and len(node.elts) > MAX_COLLECTION:
            raise ValueError("list too long")
    pos_names = [node for node in nodes if isinstance(node, ast.Name) and node.id == "pos"]
    if len(pos_names) != sum(isinstance(node, ast.Subscript) for node in nodes):
        raise ValueError("pos may only be used as pos[\"Item\"]")
    if not names:
        raise ValueError("the expression names no item")

    def collection(node: ast.AST, pos: dict[str, int], env: dict[str, Any]) -> list[Any]:
        """The values of something iterated or searched: a literal list, a range, or a comprehension."""
        if isinstance(node, (ast.Tuple, ast.List, ast.Set)):
            return [value(element, pos, env) for element in node.elts]
        if isinstance(node, (ast.GeneratorExp, ast.ListComp, ast.SetComp)):
            if len(node.generators) != 1:
                raise ValueError("one loop only")
            loop = node.generators[0]
            out = []
            for element in collection(loop.iter, pos, env):
                inner = {**env, loop.target.id: element}  # type: ignore[attr-defined]
                if all(value(test, pos, inner) for test in loop.ifs):
                    out.append(value(node.elt, pos, inner))
            return out
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "range":
            arguments = [_number(value(a, pos, env)) for a in node.args]
            if not 1 <= len(arguments) <= 3 or any(type(a) is not int or abs(a) > 100 for a in arguments) or (len(arguments) == 3 and arguments[2] == 0):
                raise ValueError("range needs one to three small whole numbers")
            numbers = list(range(*arguments))  # at most 201 values
            steps[0] -= len(numbers)  # building and scanning them is work, charged like any other
            return numbers
        raise ValueError("a list was expected")

    steps = budget if budget is not None else [MAX_STEPS]

    def value(node: ast.AST, pos: dict[str, int], env: dict[str, Any]) -> Any:
        steps[0] -= 1
        if steps[0] < 0:
            raise ValueError("search too large")
        if isinstance(node, ast.Expression):
            return value(node.body, pos, env)
        if isinstance(node, ast.BoolOp):
            results = (bool(value(v, pos, env)) for v in node.values)
            return all(results) if isinstance(node.op, ast.And) else any(results)
        if isinstance(node, ast.UnaryOp):
            operand = value(node.operand, pos, env)
            if isinstance(node.op, ast.Not):
                return not operand
            return -_number(operand) if isinstance(node.op, ast.USub) else _number(operand)
        if isinstance(node, ast.BinOp):
            left, right = _number(value(node.left, pos, env)), _number(value(node.right, pos, env))
            if isinstance(node.op, (ast.Mod, ast.FloorDiv, ast.Div)):
                if right == 0:
                    raise ValueError("division by zero")
                return left % right if isinstance(node.op, ast.Mod) else left // right if isinstance(node.op, ast.FloorDiv) else left / right
            return _number(left + right if isinstance(node.op, ast.Add) else left - right if isinstance(node.op, ast.Sub) else left * right)
        if isinstance(node, ast.Compare):
            left = value(node.left, pos, env)
            for op, comparator in zip(node.ops, node.comparators):
                if isinstance(op, (ast.In, ast.NotIn)):
                    right: Any = collection(comparator, pos, env)
                else:
                    right = value(comparator, pos, env)
                if not _COMPARE[type(op)](left, right):
                    return False
                left = right
            return True
        if isinstance(node, ast.IfExp):
            return value(node.body if value(node.test, pos, env) else node.orelse, pos, env)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            if node.id == "n":
                return count
            if node.id in env:
                return env[node.id]
            raise ValueError(f"unknown name {node.id}")
        if isinstance(node, ast.Subscript):
            key = value(node.slice, pos, env)
            item = _resolve(key, items) if isinstance(key, str) else None
            if item is None:
                raise ValueError("pos[...] must name an item")
            return pos[item]
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute):  # [a, b, c].count(x)
                wanted = value(node.args[0], pos, env)
                return sum(1 for element in collection(node.func.value, pos, env) if element == wanted)
            name = node.func.id  # type: ignore[attr-defined]
            if name in ("abs", "int", "bool"):
                if len(node.args) != 1:
                    raise ValueError(f"{name} takes one value")
                single = value(node.args[0], pos, env)
                return bool(single) if name == "bool" else abs(_number(single)) if name == "abs" else int(_number(single))
            values = collection(node.args[0], pos, env) if len(node.args) == 1 else [value(a, pos, env) for a in node.args]
            if name == "len":
                return len(values)
            if name in ("any", "all"):
                return any(values) if name == "any" else all(values)
            numbers = [_number(v) for v in values]
            if name == "sum":
                return _number(sum(numbers))
            if not numbers:
                raise ValueError(f"{name} of nothing")
            return min(numbers) if name == "min" else max(numbers)
        raise ValueError(f"not permitted: {type(node).__name__}")

    def test(pos: dict[str, int]) -> bool:
        try:
            return bool(value(tree, pos, {}))
        except (TypeError, KeyError, AttributeError) as exc:  # a form that parsed but does not compute
            raise ValueError(f"cannot evaluate: {type(exc).__name__}") from None

    return test, frozenset(names)


def solve(items: list[str], constraints: list[str], limit: int = 2, stats: dict[str, int] | None = None) -> list[list[str]]:
    """Up to `limit` orders of `items` that satisfy every constraint. ValueError on a malformed problem."""
    if not 2 <= len(items) <= MAX_ITEMS or len(set(items)) != len(items) or any(not item or len(item) > 80 for item in items):
        raise ValueError("items must be 2 to 12 distinct names")
    if not 1 <= len(constraints) <= MAX_CONSTRAINTS:
        raise ValueError("no constraints, or too many")
    budget = [MAX_STEPS]
    checks = [compile_constraint(text, items, budget) for text in constraints]
    found: list[list[str]] = []
    pos: dict[str, int] = {}
    free = set(range(1, len(items) + 1))
    # Most-constrained items first, so a wrong placement is noticed early.
    order = sorted(items, key=lambda item: -sum(item in names for _, names in checks))

    tried = 0

    def place(index: int) -> None:
        nonlocal tried
        if len(found) >= limit:
            return
        tried += 1
        if tried > MAX_PLACEMENTS:
            raise ValueError("search too large")
        if index == len(order):
            found.append(sorted(items, key=pos.__getitem__))
            return
        item = order[index]
        for spot in sorted(free):
            pos[item] = spot
            free.discard(spot)
            if all(test(pos) for test, names in checks if item in names and names <= pos.keys()):
                place(index + 1)
            free.add(spot)
            del pos[item]

    try:
        place(0)
    finally:
        if stats is not None:
            stats.update(placements=tried, steps=MAX_STEPS - budget[0])
    return found


def settle(reply: str) -> dict[str, Any]:
    """What a translating model's reply comes to.

    status: "unique" (answer holds the one order), "several" (the clues leave more than one),
    "none" (they contradict each other as translated), "declined" (the model said this is not
    an ordering puzzle) or "error" (the reply could not be used).
    """
    try:
        data = json.loads(reply[reply.index("{"): reply.rindex("}") + 1])
        items = [str(item).strip() for item in data.get("items") or []]
        constraints = [str(text) for text in data.get("constraints") or []]
        if not items or not constraints:
            return {"status": "declined", "answer": ""}
        # The solver produces one thing: the items in a row. A task that wants anything else (the
        # third name only, a JSON array, numbered lines, initials) is not answered from here. In a
        # test of 27 awkward challenges this was the one way the tool gave wrong answers.
        wanted = str(data.get("answer") or "").strip().lower()
        if wanted not in ("order", "reversed"):
            return {"status": "declined", "answer": "", "error": f"answer is {wanted or 'unstated'}"}
        separator = data.get("separator")
        if not isinstance(separator, str) or not separator.strip(" \t"):
            separator = ", "
        elif len(separator) > 5 or any(c.isalnum() or c in "\n\r\"'[]{}()" for c in separator):
            # Line breaks, words or brackets between items: a format the plain list does not cover.
            return {"status": "declined", "answer": "", "error": "unusual separator"}
        stats: dict[str, int] = {}
        found = solve(items, constraints, stats=stats)
    except (ValueError, TypeError, AttributeError, KeyError, RecursionError, MemoryError, OverflowError) as exc:
        return {"status": "error", "answer": "", "error": f"{type(exc).__name__}: {str(exc)[:120]}"}
    if wanted == "reversed":
        found = [order[::-1] for order in found]
    status = "unique" if len(found) == 1 else "several" if found else "none"
    return {"status": status, "answer": separator.join(found[0]) if len(found) == 1 else "", "items": len(items),
            "constraints": len(constraints), "orders": [separator.join(order) for order in found], **stats}
