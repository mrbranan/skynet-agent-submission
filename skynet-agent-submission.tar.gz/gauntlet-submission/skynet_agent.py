#!/usr/bin/env python3
"""SkyNet: Agent Gauntlet competitor runtime.

Design goals, in order: always submit a scored answer; get it right; be fast.

- Models are a ranked chain built from the live roster (`my_strategy.py`).
  A model that errors, stalls or returns nothing is skipped for the rest of
  the run, and a slow model is hedged with the next one in parallel.
- Every network call has its own deadline. MCP calls reconnect once on a
  transport failure and never re-register (see the reconnect contract).
- A candidate answer is saved as a draft the moment it exists, and a watchdog
  submits the best candidate before the challenge deadline.

Usage:  python skynet_agent.py
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import re
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

try:  # .env is a development convenience; the organizer sets real env vars.
    from dotenv import load_dotenv

    load_dotenv(REPO_ROOT / ".env")
except Exception:  # noqa: BLE001
    pass

from openai import AsyncOpenAI

from arena_clients import (
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
)
from arena_clients.config import agent_id_problem
from arena_clients.http_client import ArenaAPIError, ArenaConnectionError
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
import image_ops
import blackbox
import order_tool
from base_strategy import ChallengeContext
from model_selector import fetch_available_models
from my_strategy import ModelProfile, MyStrategy

# Seconds kept in reserve before the challenge deadline for the final submit.
SUBMIT_MARGIN_S = 8.0
MCP_CALL_TIMEOUT_S = 12.0
# The arena's own housekeeping tools (clues, time remaining) answer in a fraction of a second on
# Practice. One that stays silent this long is not waited for again and never delays the answer.
FLOW_CALL_TIMEOUT_S = 5.0
# Before submitting: how long to wait for those calls if they are still out.
FLOW_WAIT_BEFORE_SUBMIT_S = 1.0
# A required tool that was sent and never answered is sent once more just before submitting.
REQUIRED_RETRY_S = 0.75
# Attempts for each startup step (connectivity check, MCP connect, registration).
STARTUP_ATTEMPTS = 6
# How often to ask for the challenge while the lobby is open (the clock starts at GO).
LOBBY_POLL_S = 0.4
NEXT_LOBBY_POLL_S = 1.0  # while another group's battle runs: how often to look at the phase
# Longest wait for tiebreaker models after two models disagree.
TIEBREAK_MAX_S = 12.0
# Longest wait for a second model to confirm the first answer.
SECOND_OPINION_MAX_S = 6.0
# After exploring: how long to wait for the model that has been answering independently meanwhile.
SHADOW_GRACE_S = 0.8
# When every model fails at once (the proxy cools a model down for ~5s after an
# upstream error), wait this long and try the whole chain again while time allows.
OUTAGE_RETRY_WAIT_S = 5.0
# Stop retrying once this share of the challenge time is used; then fall back.
OUTAGE_RETRY_UNTIL = 0.6
# 1x1 PNG submitted only when no image could be produced at all: a scored
# submission with quality 0 still beats no submission.
BLANK_PNG_DATA_URI = (
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/S7sAAAAASUVORK5CYII="
)
# ...and how long when the only answer is from a model not trusted on its own.
UNTRUSTED_SOLO_WAIT_S = 15.0
IMAGE_CALL_TIMEOUT_S = 60.0
SEED_VOTER = "explorer"       # the name under which an answer found before the vote counts as one vote
SUBMIT_HEDGE_S = 15.0        # an image submit normally answers in under 10 s
REST_TIMEOUT_S = 10.0
FALLBACK_TEXT_ANSWER = "Unable to determine"
LAST_KNOWN_MODELS = (
    "gpt-5.6-terra", "gemini-3.6-flash", "gpt-5.4", "gemini-3.8-flash", "nemotron-3-ultra", "qwen3.7-max",
    "gemini-3.1-flash-image", "gemini-3.1-flash-lite-image", "gemini-3-pro-image",
)
# The watchdog submits whatever is in hand this long before the time limit.
WATCHDOG_MARGIN_S = 5.0
MAX_THOUGHTS = 12
# What the runtime reads itself before any model is asked; an exploring model has no reason to call these.
# The two clue translators of the ordering solver: a reply later than this is not waited for.
ORDER_TOOL_TIMEOUT_S = 6.0
ORDER_TOOL_MAX_TOKENS = 2000
# Asked at once; the first two to give the same single order decide. With only two, one stalled
# model switched the solver off for that heat (2 of 20 Practice heats, one of which then took 16 s).
ORDER_TOOL_TRANSLATORS = 3
ALREADY_READ = frozenset({"arena.get_challenge", "arena.clues.list", "arena.clues.get"})
THOUGHT_MAX_CHARS = 300
# While a model or image call is pending: the first "still waiting" thought after this long, then
# one every so often, a few per wait at most, always leaving room for the thoughts that carry facts.
WAIT_THOUGHT_FIRST_S = 4.0
WAIT_THOUGHT_EVERY_S = 5.0
WAIT_THOUGHT_MAX = 3
WAIT_THOUGHT_RESERVE = 4
_PROCESS_STARTED = time.time()


def knob(name: str, default: str = "") -> str:
    """An experiment or fault-injection switch. Honoured only with SKYNET_DEV=1, so a stray
    variable in the shell that launches the agent at the event can never change its behaviour."""
    if os.environ.get("SKYNET_DEV") != "1":
        return default
    return os.environ.get(name, default)


def log(message: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {message}", flush=True)


# --------------------------------------------------------------------- arena


class WrongModality(Exception):
    """The server says this agent's challenge is the other modality."""

    def __init__(self, actual: str, message: str) -> None:
        super().__init__(message)
        self.actual = actual


class Arena:
    """MCP access with per-call deadlines and one reconnect on transport failure."""

    def __init__(self, mcp_url: str, agent_id: str) -> None:
        self.mcp_url = mcp_url
        self.agent_id = agent_id
        self._client: McpArenaClient | None = None
        # Connections given up on. They are kept, never dropped: when one is garbage-collected its
        # SSE context closes from another task and cancels whichever task opened it (the run itself).
        self._retired: list[McpArenaClient] = []
        self.tools_called: list[str] = []
        self.tools_unanswered: list[str] = []  # sent, but no reply came within the time allowed
        self.tool_defs: dict[str, dict[str, Any]] = {}
        self.on_stuck = None  # optional coroutine function, called during a long wait for the challenge

    async def connect(self) -> None:
        client = McpArenaClient(self.mcp_url)
        await asyncio.wait_for(client.__aenter__(), timeout=20.0)
        self._client = client

    async def close(self) -> None:
        client, self._client = self._client, None
        if client is not None and not self._retired:  # with retired connections the process just exits
            try:
                await asyncio.wait_for(client.__aexit__(None, None, None), timeout=3.0)
            except BaseException:  # noqa: BLE001 - shutdown must never fail the run
                pass

    def _retire(self) -> None:
        """Stop using the current connection (the next call opens a new one) without letting go of it."""
        if self._client is not None:
            self._retired.append(self._client)
            self._client = None

    async def _run(self, label: str, op, timeout: float, retry: bool = True):
        """Run `op(client)`; on a transport failure reconnect once and retry (unless `retry` is off).

        A call that gets no reply in time is not sent again: the server has it, and asking a tool
        that hangs a second time only doubles the wait. Later calls use a fresh connection, in
        case the silence was the connection's.
        """
        last_exc: BaseException | None = None
        for attempt in ((1, 2) if retry else (1,)):
            try:
                if self._client is None:
                    await self.connect()
                return await asyncio.wait_for(op(self._client), timeout=timeout)
            except McpArenaError:
                raise  # a server-side answer, not a transport problem
            except asyncio.TimeoutError as exc:
                log(f"MCP {label}: no reply in {timeout:.0f}s")
                self._retire()
                self.tools_unanswered.append(label)
                raise ConnectionError(f"MCP {label} did not answer in {timeout:.0f}s") from exc
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
                log(f"MCP {label} failed ({type(exc).__name__}: {str(exc)[:120]}); attempt {attempt}")
                self._retire()
        raise ConnectionError(f"MCP {label} failed after reconnect: {last_exc}")

    async def call(
        self, name: str, arguments: dict[str, Any], timeout: float = MCP_CALL_TIMEOUT_S, retry: bool = True
    ) -> dict[str, Any]:
        async def reply(client):
            session = getattr(client, "_session", None)
            if session is None:
                return await client.call_tool(name, arguments)
            # Read here, not by the kit's parser: that one keeps only the first text block, and only
            # when it is a JSON object, so a tool answering with a list, a number, several blocks or
            # an image came back empty (or as a "connection error" when the first block had no text).
            return parse_tool_reply(await session.call_tool(name, arguments or {}))

        result = await self._run(name, reply, timeout, retry)
        self.tools_called.append(name)
        return result if isinstance(result, dict) else {}

    async def list_tools(self) -> list[str]:
        async def listing(client):
            session = getattr(client, "_session", None)
            if session is None:
                return await client.list_tool_defs()
            found: list[Any] = []
            cursor = None
            for _ in range(10):  # a long tool list comes in pages
                page = await (session.list_tools(cursor) if cursor else session.list_tools())
                found += list(getattr(page, "tools", None) or [])
                cursor = getattr(page, "nextCursor", None)
                if not cursor:
                    break
            return found

        defs = await self._run("list_tools", listing, MCP_CALL_TIMEOUT_S)
        self.tool_defs = {
            str(d.name): {"description": str(d.description or ""), "schema": d.inputSchema if isinstance(d.inputSchema, dict) else {}}
            for d in defs
        }
        return list(self.tool_defs)

    async def inventory(self) -> dict[str, list[dict[str, str]]]:
        """Resources, resource templates and prompts the server exposes (often none)."""
        found: dict[str, list[dict[str, str]]] = {"resources": [], "templates": [], "prompts": []}

        async def listing(client):
            session = client._session
            for key, method, field in (
                ("resources", "list_resources", "resources"),
                ("templates", "list_resource_templates", "resourceTemplates"),
                ("prompts", "list_prompts", "prompts"),
            ):
                try:
                    result = await asyncio.wait_for(getattr(session, method)(), timeout=6.0)
                except Exception:  # noqa: BLE001 - an unsupported listing is simply empty
                    continue
                found[key] = [
                    {
                        "name": str(getattr(item, "name", "") or ""),
                        "uri": str(getattr(item, "uri", "") or getattr(item, "uriTemplate", "") or ""),
                        "description": str(getattr(item, "description", "") or "")[:300],
                        "arguments": ", ".join(str(getattr(a, "name", "")) for a in (getattr(item, "arguments", None) or [])),
                    }
                    for item in getattr(result, field, None) or []
                ]
            return found

        try:
            return await self._run("inventory", listing, 20.0)
        except Exception:  # noqa: BLE001
            return found

    async def read_resource(self, uri: str) -> str:
        async def read(client):
            result = await client._session.read_resource(uri)
            parts = []
            for item in getattr(result, "contents", None) or []:
                text = getattr(item, "text", None)
                if text is None and getattr(item, "blob", None):
                    text = f"(binary, base64) {item.blob}"
                parts.append(str(text or ""))
            return "\n".join(parts)

        return await self._run(f"read_resource {uri}", read, 20.0)

    async def get_prompt(self, name: str, arguments: dict[str, Any]) -> str:
        async def get(client):
            result = await client._session.get_prompt(name, {k: str(v) for k, v in (arguments or {}).items()})
            parts = []
            for message in getattr(result, "messages", None) or []:
                content = getattr(message, "content", None)
                parts.append(str(getattr(content, "text", None) or content or ""))
            return "\n".join(parts)

        return await self._run(f"get_prompt {name}", get, 20.0)

    async def wait_for_challenge(self, image: bool):
        """Fetch the challenge, waiting for as long as the lobby is open.

        Before GO the server answers with an error (its wording varies), and a
        long lobby can see dropped connections. Neither may end the run: only
        a real challenge, or word that this agent has the other modality,
        leaves this loop. `self.on_stuck`, if set, is called now and then while
        the wait drags on (the run uses it to check its registration).
        """
        name = "arena.image.get_challenge" if image else "arena.get_challenge"
        seen: set[str] = set()
        waited_since = time.time()
        last_nudge = time.time()
        while True:
            pause = LOBBY_POLL_S
            try:
                if image:
                    data = await self._run(name, lambda c: c.call_tool(name, {"agent_id": self.agent_id}), MCP_CALL_TIMEOUT_S)
                    data = data if isinstance(data, dict) else {}
                    if "error" in data:
                        raise McpArenaError(to_text(data["error"]), code=data.get("code"))
                    challenge = SimpleNamespace(
                        challenge_type=to_text(data.get("challenge_type")),
                        puzzle_id=to_text(data.get("puzzle_id") or data.get("challenge_id")),
                        difficulty=to_text(data.get("difficulty")),
                        description=to_text(data.get("description")),
                        prompt=to_text(data.get("prompt") or data.get("edit_prompt")),
                        reference_notes=to_text(data.get("reference_notes")),
                        max_time_s=to_number(data.get("max_time_s")),
                        input_image_uri=to_text(data.get("input_image_uri") or data.get("image_uri") or data.get("image_url")),
                        time_remaining_s=to_number(data.get("time_remaining_s")),
                        required_tools=[str(t) for t in (data.get("required_tools") or [])],
                        raw_data=data,
                    )
                    real = bool(challenge.prompt or challenge.description or challenge.input_image_uri)
                else:
                    challenge = await self._run(name, lambda c: c.get_challenge(self.agent_id), MCP_CALL_TIMEOUT_S)
                    raw = challenge.raw_data if isinstance(challenge.raw_data, dict) else {}
                    challenge.description = to_text(challenge.description)
                    challenge.rules = to_text(challenge.rules)
                    challenge.max_time_s = to_number(challenge.max_time_s)
                    challenge.time_remaining_s = to_number(challenge.time_remaining_s)
                    challenge.clues = [to_text(c) for c in (challenge.clues or [])]
                    real = bool(challenge.description or challenge.rules or challenge.clues or challenge.puzzle_id)
                    if not real and set(raw) <= {"raw", "structured"}:
                        # A plain-text reply ("Error executing tool ...") is not a challenge.
                        raise McpArenaError(to_text(raw.get("raw") or raw.get("structured") or "empty reply"))
                if not real:
                    raise McpArenaError("the server returned an empty challenge")
                self.tools_called.append(name)
                return challenge
            except McpArenaError as exc:
                message = str(exc).lower()
                code = str(getattr(exc, "code", "") or "").lower()
                # The assignment can differ from what the session showed in the lobby.
                if image and (code == "not_image_challenge" or "text challenge" in message or "use arena.get_challenge" in message):
                    raise WrongModality("text", str(exc)) from exc
                if not image and ("image challenge" in message or "use arena.image.get_challenge" in message):
                    raise WrongModality("image", str(exc)) from exc
                if message[:80] not in seen:
                    seen.add(message[:80])
                    log(f"waiting for the challenge to open: {str(exc)[:160]}")
                if not any(word in message for word in ("locked", "waiting for organizer", "not started", "lobby", "not running", "countdown")):
                    pause = 1.0  # not the usual lobby reply: poll more gently
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - a dropped connection during the lobby is not fatal
                if "connection" not in seen:
                    seen.add("connection")
                    log(f"challenge fetch failed ({type(exc).__name__}: {str(exc)[:120]}); will keep trying")
                pause = 1.5
            if self.on_stuck is not None and time.time() - last_nudge > 20.0 and time.time() - waited_since > 20.0:
                last_nudge = time.time()
                try:
                    await self.on_stuck()
                except Exception:  # noqa: BLE001
                    pass
            await asyncio.sleep(pause)


# ----------------------------------------------------------------------- llm


class ModelRouter:
    """Calls text models through the proxy with fallback and hedging."""

    def __init__(self, agent_id: str, usage_scope: str | None, client: Any = None) -> None:
        # `client` is injectable so the fallback logic can be tested without a network.
        self.client = client or AsyncOpenAI(
            base_url=get_proxy_host(),
            api_key=get_arena_api_key(),
            default_headers=build_proxy_headers(agent_id, usage_scope),
            timeout=120.0,
            max_retries=0,
        )
        self.agent_id = agent_id
        self.down: set[str] = set()
        self.tool_down: set[str] = set()   # models that failed while driving tools (they may still answer)
        # What each model has rejected (HTTP 400/422), so the next call to it leaves that out:
        # "settings" (reasoning options and temperature) and "max_tokens" (it wants max_completion_tokens).
        self.quirks: dict[str, set[str]] = {}
        self.usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
        self.attempts: list[dict[str, Any]] = []

    def set_scope(self, usage_scope: str) -> None:
        """Attribute later calls to the battle's usage scope, keeping the warm connection."""
        self.client = self.client.with_options(default_headers=build_proxy_headers(self.agent_id, usage_scope))

    @staticmethod
    async def _inject_fault(model: str) -> None:
        """Test hook: SKYNET_FAIL_MODELS / SKYNET_HANG_MODELS simulate an outage (unset in production)."""
        # SKYNET_FAIL_FOR_S limits the simulated failure to the first N seconds of the challenge clock.
        try:
            fail_for = float(knob("SKYNET_FAIL_FOR_S", "0") or 0)
        except ValueError:
            fail_for = 0.0
        window_open = not fail_for or time.time() - _PROCESS_STARTED < fail_for
        if window_open and any(name and name in model for name in knob("SKYNET_FAIL_MODELS", "").split(",")):
            raise RuntimeError(f"injected failure for {model}")
        if any(name and name in model for name in knob("SKYNET_HANG_MODELS", "").split(",")):
            await asyncio.sleep(3600)

    def _fit(self, kwargs: dict[str, Any]) -> dict[str, Any]:
        """The request with whatever this model is known to reject left out or renamed."""
        quirks = self.quirks.get(kwargs["model"], set())
        fitted = dict(kwargs)
        if "settings" in quirks:
            fitted.pop("extra_body", None)
            fitted.pop("temperature", None)
        if "max_tokens" in quirks and "max_tokens" in fitted:
            fitted["max_completion_tokens"] = fitted.pop("max_tokens")
        return fitted

    async def _create(self, kwargs: dict[str, Any], timeout: float, record: dict[str, Any] | None = None):
        """One chat completion. A model that rejects our request settings is asked again without
        them, and the rejection is remembered so later calls to it start from what it accepts.

        Two things are tried, in the order the error text suggests: dropping the reasoning options
        and temperature, and sending the token limit as `max_completion_tokens`. Anything else, or
        a rejection that survives both, is raised to the caller, which moves on to another model.
        """
        started = time.time()
        model = kwargs["model"]
        while True:
            request = self._fit(kwargs)
            left = max(1.0, timeout - (time.time() - started))
            try:
                return await asyncio.wait_for(self.client.chat.completions.create(**request), timeout=left)
            except Exception as exc:  # noqa: BLE001
                if getattr(exc, "status_code", None) not in (400, 422):
                    raise
                known = self.quirks.setdefault(model, set())
                text = str(exc).lower()
                can_drop = "settings" not in known and bool({"extra_body", "temperature"} & set(request))
                can_rename = "max_tokens" not in known and "max_tokens" in request
                names_limit = "max_tokens" in text or "max_completion_tokens" in text
                if can_rename and (names_limit or not can_drop):
                    known.add("max_tokens")
                elif can_drop:
                    known.add("settings")
                else:
                    raise
                if record is not None:
                    record["retried_plain"] = True
                    record["quirks"] = sorted(known)

    async def _one(self, model: str, profile: ModelProfile, messages: list[dict], max_tokens: int, timeout: float) -> str:
        started = time.time()
        record: dict[str, Any] = {"model": model, "settings": profile.extra_body}
        self.attempts.append(record)
        kwargs: dict[str, Any] = {"model": model, "messages": messages, "max_tokens": max_tokens}
        if profile.temperature is not None:
            kwargs["temperature"] = profile.temperature
        if profile.extra_body:
            kwargs["extra_body"] = profile.extra_body
        try:
            await self._inject_fault(model)
            response = await self._create(kwargs, timeout, record)
        except asyncio.CancelledError:
            record.update(outcome="cancelled", secs=round(time.time() - started, 2))
            raise
        except Exception as exc:  # noqa: BLE001
            record.update(
                outcome="error",
                secs=round(time.time() - started, 2),
                error=f"{type(exc).__name__} {getattr(exc, 'status_code', '')}: {str(exc)[:160]}",
            )
            self.down.add(model)
            raise
        usage = response.usage
        if usage is not None:
            for key in self.usage:
                self.usage[key] += int(getattr(usage, key, 0) or 0)
        choice = response.choices[0] if response.choices else None
        text = (choice.message.content or "") if choice else ""
        record.update(
            outcome="ok" if text.strip() else "empty",
            secs=round(time.time() - started, 2),
            finish=getattr(choice, "finish_reason", None),
            total_tokens=getattr(usage, "total_tokens", None),
        )
        if not text.strip():
            self.down.add(model)
            raise ValueError(f"{model} returned no content (finish={record['finish']})")
        return text

    async def race(
        self,
        chain: list[tuple[str, ModelProfile]],
        messages: list[dict],
        *,
        max_tokens: int,
        budget_s: float,
        accept,
        parallel: int = 1,
    ) -> tuple[str, str] | None:
        """Start `parallel` models, hedge slow ones with the next; first usable reply wins."""
        deadline = time.time() + budget_s
        chain = [(m, p) for m, p in chain if m not in self.down]
        tasks: dict[asyncio.Task, str] = {}
        next_index = 0
        hedge_at = 0.0

        def launch() -> None:
            nonlocal next_index, hedge_at
            model, profile = chain[next_index]
            next_index += 1
            remaining = max(1.0, deadline - time.time())
            tasks[asyncio.create_task(self._one(model, profile, messages, max_tokens, remaining))] = model
            hedge_at = time.time() + profile.hedge_after_s

        try:
            for _ in range(min(parallel, len(chain))):
                launch()
            while time.time() < deadline and (tasks or next_index < len(chain)):
                if not tasks:
                    launch()
                wait_s = deadline - time.time()
                if next_index < len(chain):
                    wait_s = min(wait_s, max(0.05, hedge_at - time.time()))
                done, _ = await asyncio.wait(tasks, timeout=max(0.05, wait_s), return_when=asyncio.FIRST_COMPLETED)
                if not done:
                    if next_index < len(chain) and time.time() >= hedge_at:
                        log(f"hedging: starting {chain[next_index][0]} alongside {list(tasks.values())}")
                        launch()
                    continue
                for task in done:
                    model = tasks.pop(task)
                    try:
                        value = accept(task.result())
                    except Exception as exc:  # noqa: BLE001
                        log(f"model {model} failed: {type(exc).__name__}: {str(exc)[:140]}")
                        continue
                    if value:
                        return value, model
                    log(f"model {model} gave an unusable reply")
                    self.down.add(model)
            return None
        finally:
            for task in tasks:
                task.cancel()


    async def tool_loop(
        self,
        chain: list[tuple[str, ModelProfile]],
        messages: list[dict],
        tools: list[dict],
        execute,
        *,
        budget_s: float,
        max_steps: int = 6,
        closing: list[str] | None = None,
        step_timeout_s: float = 40.0,
        stretch_s: float = 0.0,
        after_calls=None,
    ) -> list[str]:
        """Let a model call tools until it stops asking; returns the evidence gathered.

        `stretch_s` is extra time allowed past `budget_s`, used only while the
        last step still returned something not seen before (a chain of steps
        in progress is not cut off halfway). `after_calls`, if given, is awaited
        once after each turn's calls; text it returns is added to that turn's
        last result (the explorer uses it to announce tools that have appeared).

        `execute(name, arguments)` runs one tool and returns its text result.
        If a model errors mid-loop the next model continues with what was
        already gathered. Evidence, not the model's own conclusion, is the
        output: the answer is decided afterwards by the usual agreement vote.
        """
        deadline = time.time() + budget_s
        hard_deadline = deadline + max(0.0, stretch_s)
        evidence: list[str] = []
        seen_results: set[str] = set()
        fresh = False  # the last step returned something new
        for model, profile in [(m, p) for m, p in chain if m not in self.tool_down][:3]:
            convo = list(messages)
            if evidence:
                convo.append({"role": "user", "content": "Tool results gathered so far:\n" + "\n".join(evidence)})
            record: dict[str, Any] = {"model": model, "settings": profile.extra_body, "kind": "tool_loop", "steps": []}
            self.attempts.append(record)
            started = time.time()
            try:
                for step in range(max_steps):
                    remaining = deadline - time.time()
                    if remaining < 3.0:
                        if not fresh or hard_deadline - time.time() < 8.0:
                            break
                        remaining = hard_deadline - time.time()
                    kwargs: dict[str, Any] = {"model": model, "messages": convo, "tools": tools, "max_tokens": 4096}
                    if profile.extra_body:
                        kwargs["extra_body"] = profile.extra_body
                    await self._inject_fault(model)
                    step_started = time.time()
                    response = await self._create(kwargs, min(remaining, step_timeout_s), record)
                    record["steps"].append(round(time.time() - step_started, 2))
                    usage = response.usage
                    if usage is not None:
                        for key in self.usage:
                            self.usage[key] += int(getattr(usage, key, 0) or 0)
                    message = response.choices[0].message
                    calls = list(message.tool_calls or [])
                    if not calls:
                        if closing is not None and (message.content or "").strip():
                            closing.append(str(message.content).strip())
                        break
                    # Echo the assistant turn back unmodified: some models attach
                    # reasoning signatures that must accompany their tool calls.
                    convo.append(message.model_dump(exclude_none=True))
                    parsed: list[dict] = []
                    for call in calls:
                        try:
                            arguments = json.loads(call.function.arguments or "{}")
                        except json.JSONDecodeError:
                            arguments = {}
                        parsed.append(arguments if isinstance(arguments, dict) else {})
                    # Independent calls in one turn run together.
                    results = list(await asyncio.gather(*(execute(c.function.name, a) for c, a in zip(calls, parsed))))
                    if after_calls is not None:
                        results[-1] += await after_calls() or ""
                    fresh = any(result not in seen_results and not result.startswith("tool error:") for result in results)
                    seen_results.update(results)
                    for call, arguments, result in zip(calls, parsed, results):
                        evidence.append(f"[{call.function.name} {json.dumps(arguments)[:200]}] {result}")
                        convo.append({"role": "tool", "tool_call_id": call.id, "content": result})
                record.update(outcome="ok", secs=round(time.time() - started, 2), tool_calls=len(evidence))
                return evidence
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                record.update(
                    outcome="error", secs=round(time.time() - started, 2),
                    error=f"{type(exc).__name__} {getattr(exc, 'status_code', '')}: {str(exc)[:160]}",
                )
                log(f"tool loop with {model} failed: {type(exc).__name__}: {str(exc)[:140]}")
                self.tool_down.add(model)
        return evidence

    async def consensus(
        self,
        chain: list[tuple[str, ModelProfile]],
        messages: list[dict],
        *,
        max_tokens: int,
        budget_s: float,
        accept,
        on_candidate=None,
        parallel: int = 3,
        max_models: int = 7,
        seed: str | None = None,
    ) -> tuple[str, str, str] | None:
        """Ask several models at once and submit as soon as two agree.

        `seed` is an answer already in hand before the vote (the tool
        explorer's). It counts as one vote, so a single model agreeing with it
        settles the answer, but it never decides alone while a model can still
        answer.

        Returns (answer, model, basis). A model that fails is replaced by the
        next in the chain, and so is one that is still silent after its hedge
        time (it keeps running; a hung model must not hold a slot). If models
        disagree, two more vote, for a bounded time. If only one answers
        within the grace period, its answer is used.
        """
        started = time.time()
        deadline = started + budget_s
        chain = [(m, p) for m, p in chain if m not in self.down]
        rank = {m: i for i, (m, _) in enumerate(chain)}
        solo_ok = {m: getattr(p, "solo_ok", True) for m, p in chain}
        tasks: dict[asyncio.Task, str] = {}
        hedge_times: dict[asyncio.Task, float] = {}  # when a silent model gets a replacement
        answers: dict[str, str] = {}  # model -> answer
        if seed:
            answers[SEED_VOTER] = seed
            solo_ok[SEED_VOTER] = False  # a model that disagrees outranks it; see docstring
        next_index = 0
        launched = 0
        decide_at: float | None = None  # when to stop waiting for a second opinion
        first_answer_at = started
        tiebreak_until: float | None = None  # when to stop waiting for a tiebreaker

        def launch() -> bool:
            nonlocal next_index, launched
            if next_index >= len(chain) or launched >= max_models:
                return False
            model, profile = chain[next_index]
            next_index += 1
            launched += 1
            remaining = max(1.0, deadline - time.time())
            task = asyncio.create_task(self._one(model, profile, messages, max_tokens, remaining))
            tasks[task] = model
            hedge_times[task] = time.time() + profile.hedge_after_s
            return True

        def votes() -> dict[str, list[str]]:
            grouped: dict[str, list[str]] = {}
            for model, answer in answers.items():
                grouped.setdefault(vote_key(answer), []).append(model)
            return grouped

        def best_single() -> tuple[str, str]:
            # A model trusted on its own beats a higher-ranked one that is not.
            model = min(answers, key=lambda m: (not solo_ok.get(m, True), rank.get(m, 99)))
            return answers[model], model

        def solo_wait(took: float) -> float:
            """How long to wait for confirmation of the only answer so far."""
            if any(solo_ok.get(m, True) for m in answers):
                override = knob("SKYNET_SOLO_WAIT", "").strip()  # experiment knob: seconds, e.g. "0"
                if override:
                    try:
                        return float(override)
                    except ValueError:
                        pass
                return min(SECOND_OPINION_MAX_S, max(2.0, 0.5 * took))
            return UNTRUSTED_SOLO_WAIT_S

        for _ in range(parallel):
            launch()
        try:
            while time.time() < deadline:
                now = time.time()
                grouped = votes()
                agreed = [models for models in grouped.values() if len(models) >= 2]
                if agreed:
                    model = min(agreed[0], key=lambda m: rank.get(m, 99))
                    return answers[model], model, f"agreed:{'+'.join(sorted(agreed[0]))}"
                if len(grouped) >= 2 and (
                    (tiebreak_until is not None and now >= tiebreak_until) or (not tasks and not launch())
                ):
                    answer, model = best_single()
                    return answer, model, "disagreement-unresolved"
                if not tasks and not launch():
                    break
                # Replace models that have gone quiet for too long.
                for task in [t for t, at in hedge_times.items() if t in tasks and now >= at]:
                    hedge_times.pop(task)
                    if launch():
                        log(f"{tasks[task]} is slow; started another model alongside it")
                wait_until = deadline
                pending_hedges = [at for t, at in hedge_times.items() if t in tasks]
                if pending_hedges and next_index < len(chain) and launched < max_models:
                    wait_until = min(wait_until, min(pending_hedges))
                if decide_at is not None and len(grouped) == 1:
                    if now >= decide_at:
                        answer, model = best_single()
                        return answer, model, "single"
                    wait_until = min(wait_until, decide_at)
                if tiebreak_until is not None:
                    wait_until = min(wait_until, tiebreak_until)
                done, _ = await asyncio.wait(
                    tasks, timeout=max(0.05, wait_until - time.time()), return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    model = tasks.pop(task)
                    hedge_times.pop(task, None)
                    try:
                        value = accept(task.result())
                    except Exception as exc:  # noqa: BLE001
                        log(f"model {model} failed: {type(exc).__name__}: {str(exc)[:140]}")
                        value = ""
                    if not value:
                        self.down.add(model)
                        launch()  # replace the failed opinion
                        continue
                    answers[model] = value
                    if len([m for m in answers if m != SEED_VOTER]) == 1:
                        first_answer_at = time.time()
                        if on_candidate:
                            on_candidate(value)
                    # Recomputed on every answer: a trusted model confirming shortens the wait.
                    decide_at = first_answer_at + solo_wait(first_answer_at - started)
                    model_answers = [a for m, a in answers.items() if m != SEED_VOTER]
                    if len(votes()) >= 2 and len(model_answers) >= 2 and all(is_freeform(a) for a in model_answers):
                        # Long prose or a large payload: two models never word it identically, so
                        # waiting for agreement only burns time and tokens. Take the best-placed one.
                        answer, model = best_single()
                        return answer, model, "freeform"
                    if len(votes()) >= 2 and tiebreak_until is None:
                        log(f"models disagree: {answers}")
                        # Two tiebreakers at once; a slow one must not hold the heat.
                        launch()
                        launch()
                        tiebreak_until = time.time() + min(TIEBREAK_MAX_S, 0.25 * max(1.0, deadline - time.time()))
            if answers:
                answer, model = best_single()
                return answer, model, "seed-only" if model == SEED_VOTER else "deadline"
            return None
        finally:
            for task in tasks:
                task.cancel()


# ------------------------------------------------------------------- helpers


# Tools the fixed text and image flows already handle; anything else on the
# server is a capability tool (search, lookup, ...) the model may need to drive.
FLOW_TOOLS = {
    "arena.get_challenge", "arena.clues.list", "arena.clues.get", "arena.time_remaining", "arena.tools.list",
    "arena.image.get_challenge", "arena.image.broadcast_thought", "arena.image.submit_edit",
    "image_edit", "image_generate", "image_analyze",
    "arena.submit", "arena.llm_reasoning",
}
TEXT_SUBMIT_TOOL = "arena.submit"
TEXT_THOUGHT_TOOL = "arena.llm_reasoning"


def schema_args(tool_defs: dict[str, dict[str, Any]], tool: str, agent_id: str, **values: tuple[tuple[str, ...], Any]) -> dict[str, Any]:
    """Arguments for a tool whose parameter names are only known at run time.

    Each value is (candidate parameter names, value): the first candidate the
    tool's schema lists is used, else the first candidate.
    """
    properties = ((tool_defs.get(tool) or {}).get("schema") or {}).get("properties") or {}
    arguments: dict[str, Any] = {}
    for candidates, value in values.values():
        name = next((c for c in candidates if c in properties), None)
        if name is None and properties and len(candidates) > 1 and candidates[-1] == "?":
            continue  # optional and not in the schema
        arguments[name or candidates[0]] = value
    if not properties or "agent_id" in properties:
        arguments["agent_id"] = agent_id
    return arguments
TOOL_RESULT_CHARS = 6000
TOOL_FIELD_CHARS = 4000
TOOL_LIST_ITEMS = 40
DECODE_SCAN_CHARS = 200_000
# Results kept whole for the python tool, and how much of them it is given in all.
KEPT_RESULTS = 40
KEPT_RESULT_CHARS = 400_000
KEPT_TOTAL_CHARS = 1_500_000
# How often the very same call (same tool, same arguments) is really sent again.
IDENTICAL_CALLS = 3
EVIDENCE_CHARS = 14000
CHALLENGE_CORE_KEYS = {
    "challenge_type", "challenge_id", "puzzle_id", "description", "rules", "max_time_s", "clues", "time_remaining_s",
    "required_tools", "difficulty", "output_format", "error", "code", "raw",
}
# Tools the explorer must not fire on its own: the flows submit through their own path.
SUBMIT_LIKE = re.compile(r"^arena\.(?:image\.)?submit", re.IGNORECASE)
# Tools with no required arguments that are safe and useful to call before any model is asked.
PROBE_YES = re.compile(
    r"list|help|info|describe|catalog|manifest|schema|metadata|about|rules|docs?|capabilit|whoami|inventory|"
    r"index|readme|status", re.IGNORECASE)
PROBE_NO = re.compile(
    r"submit|answer|reset|delete|remove|clear|guess|solve|attempt|verify|check|unlock|decrypt|buy|spend|pay|"
    r"register|broadcast|forfeit|give_?up|time_remaining|image_|generate|edit|search|random|hint|reveal|secret|"
    r"key|rotate|next|use_|budget|open|start|run|exec", re.IGNORECASE)
PROBE_LIMIT = 8
EXPLORE_MAX_STEPS = 14


def _virtual(name: str, description: str, properties: dict[str, Any], required: list[str]) -> dict:
    return {"type": "function", "function": {
        "name": name, "description": description,
        "parameters": {"type": "object", "properties": properties, "required": required},
    }}


# Functions the explorer gets on top of the server's own tools.
VIRTUAL_TOOLS = {
    "python": _virtual(
        "python",
        "Run Python 3 code and get what it prints (use print). Standard library plus 'cryptography'. Use it for "
        "every calculation, ranking, count, decoding or decryption instead of working it out yourself. No network. "
        "A tool result that was too long to show in full is in the dict `results` under the key its note gives.",
        {"code": {"type": "string"}}, ["code"],
    ),
    "call_tool": _virtual(
        "call_tool",
        "Call any MCP tool by exact name, including unlisted ones a result or clue mentions.",
        {"name": {"type": "string"}, "arguments": {"type": "object"}},
        ["name"],
    ),
    "read_resource": _virtual(
        "read_resource", "Read an MCP resource by URI (listed, built from a template, or mentioned in a result).",
        {"uri": {"type": "string"}}, ["uri"],
    ),
    "get_prompt": _virtual(
        "get_prompt", "Fetch an MCP prompt by name.",
        {"name": {"type": "string"}, "arguments": {"type": "object"}}, ["name"],
    ),
}


def trim_evidence(evidence: list[str], limit: int = EVIDENCE_CHARS) -> list[str]:
    """Keep the most recent evidence within a size the answering models can read quickly."""
    kept: list[str] = []
    used = 0
    for item in reversed(evidence):
        if used + len(item) > limit and kept:
            break
        kept.append(item[:limit])
        used += len(item)
    return list(reversed(kept))


def function_specs(tool_defs: dict[str, dict[str, Any]], names: list[str]) -> tuple[list[dict], dict[str, str]]:
    """OpenAI function specs for MCP tools; function names cannot contain dots, so map them."""
    specs: list[dict] = []
    name_map: dict[str, str] = {}
    for name in names:
        definition = tool_defs.get(name) or {}
        schema = dict(definition.get("schema") or {"type": "object", "properties": {}})
        properties = {k: v for k, v in (schema.get("properties") or {}).items() if k != "agent_id"}
        safe = re.sub(r"[^a-zA-Z0-9_-]", "_", name)[:64]
        name_map[safe] = name
        specs.append({
            "type": "function",
            "function": {
                "name": safe,
                "description": (definition.get("description") or f"Agent Gauntlet tool {name}")[:900],
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": [r for r in (schema.get("required") or []) if r != "agent_id"],
                },
            },
        })
    return specs, name_map


def guess_tool_arguments(schema: dict[str, Any], question: str) -> dict[str, Any]:
    """Arguments for a required tool the model never called: fill text fields with the question."""
    arguments: dict[str, Any] = {}
    urls = re.findall(r"https?://[^\s)>\"]+", question)
    for name in schema.get("required") or []:
        if name == "agent_id":
            continue
        lowered = name.lower()
        if "url" in lowered or "uri" in lowered:
            arguments[name] = urls[0] if urls else ""
        elif (schema.get("properties") or {}).get(name, {}).get("type") in {"integer", "number"}:
            arguments[name] = 5
        else:
            arguments[name] = question[:300]
    return arguments


def parse_tool_reply(result: Any) -> dict[str, Any]:
    """A tool's reply as a dict, whatever shape the server sent it in.

    A JSON object is returned as it is and plain text as {"raw": text}, as before. What used to be
    lost is kept: a JSON list ({"items": [...]}), a bare number or string ({"value": ...}), every
    text block when there are several, images and attached resources, and the server's own error flag.
    """
    texts: list[str] = []
    images: list[str] = []
    attached: list[dict[str, str]] = []
    for block in getattr(result, "content", None) or []:
        text = getattr(block, "text", None)
        if isinstance(text, str):
            if text.strip():
                texts.append(text)
            continue
        data = getattr(block, "data", None)
        if isinstance(data, str) and data:  # an image or audio block
            images.append(f"data:{getattr(block, 'mimeType', None) or 'application/octet-stream'};base64,{data}")
            continue
        resource = getattr(block, "resource", None)
        if resource is not None:  # an embedded resource
            entry = {"uri": str(getattr(resource, "uri", "") or "")}
            if isinstance(getattr(resource, "text", None), str):
                entry["text"] = resource.text
            elif getattr(resource, "blob", None):
                entry["blob"] = f"data:{getattr(resource, 'mimeType', None) or 'application/octet-stream'};base64,{resource.blob}"
            attached.append(entry)
            continue
        if getattr(block, "uri", None):  # a link to a resource
            attached.append({"uri": str(block.uri), "name": str(getattr(block, "name", "") or "")})

    def read(text: str) -> Any:
        try:
            return json.loads(text)
        except (json.JSONDecodeError, RecursionError):
            return None

    structured = getattr(result, "structuredContent", None)
    if isinstance(structured, dict):
        data: dict[str, Any] = dict(structured)
    elif structured is not None:
        data = {"structured": structured}
    elif len(texts) == 1:
        parsed = read(texts[0])
        if isinstance(parsed, dict):
            data = parsed
        elif isinstance(parsed, list):
            data = {"items": parsed}
        elif parsed is None:
            data = {"raw": texts[0]}
        else:
            data = {"value": parsed}
    elif texts:
        parts = [read(text) for text in texts]
        data = {"items": parts} if all(part is not None for part in parts) else {"raw": "\n".join(texts)}
    else:
        data = {}
    if images:
        data.setdefault("images", images)
    if attached:
        data.setdefault("resources", attached)
    if getattr(result, "isError", False):
        data.setdefault("is_error", True)
    return data


def to_text(value: Any) -> str:
    """A challenge field as text, whatever shape the server sent it in."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple)):
        return "\n".join(part for part in (to_text(v) for v in value) if part)
    if isinstance(value, dict):
        try:
            return json.dumps(value, ensure_ascii=False, default=str)
        except Exception:  # noqa: BLE001
            return str(value)
    return str(value)


def to_number(value: Any) -> float:
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def tool_result_text(result: Any) -> str:
    def cut(value: Any, depth: int = 0) -> Any:
        # A long field (a fetched page, say) is shortened, never dropped: the fact wanted may be in it.
        if isinstance(value, str):
            if value.startswith("data:") and len(value) > 300:
                return value[:60] + f"...<{len(value)} chars of data>"
            return value if len(value) <= TOOL_FIELD_CHARS else value[:TOOL_FIELD_CHARS] + f"...<{len(value) - TOOL_FIELD_CHARS} more chars>"
        if depth < 4 and isinstance(value, dict):
            return {k: cut(v, depth + 1) for k, v in value.items()}
        if depth < 4 and isinstance(value, list):
            # Said out loud when a list is shortened: a model that counts or ranks what it was shown
            # must know it was not shown everything.
            more = [f"...<{len(value) - TOOL_LIST_ITEMS} more items not shown>"] if len(value) > TOOL_LIST_ITEMS else []
            return [cut(v, depth + 1) for v in value[:TOOL_LIST_ITEMS]] + more
        return value

    result = cut(result)
    try:
        text = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False, default=str)
    except Exception:  # noqa: BLE001
        text = str(result)
    if len(text) <= TOOL_RESULT_CHARS:
        return text
    return text[:TOOL_RESULT_CHARS] + f"...<{len(text) - TOOL_RESULT_CHARS} more chars not shown>"


def was_cut(shown: str) -> bool:
    """Whether `tool_result_text` left something out of what it returned."""
    return bool(re.search(r"\.\.\.<\d+ more (?:chars|items)", shown))


def full_result_text(result: Any) -> str:
    """A tool result in full, as text, for decoding and for the python tool."""
    if isinstance(result, str):
        return result
    try:
        return json.dumps(result, ensure_ascii=False, default=str)
    except Exception:  # noqa: BLE001
        return str(result)


def vote_key(answer: str) -> str:
    """Normalise an answer so two models' replies compare by content, not form.

    "Team Alpha, Team Bravo" and "Alpha, Bravo" are the same answer: a word
    that starts every item of a list is a label, not content.
    """
    structured = parse_structured(answer)
    if structured is not None:
        return json.dumps(_plain(structured), sort_keys=True, separators=(",", ":"))
    text = (answer or "").casefold().strip().strip(".;:\"'`")
    items = [item.strip() for item in re.split(r"[,;\n]|\s*->\s*|\s+then\s+|\s*>\s*", text) if item.strip()]
    if len(items) >= 2:
        first_words = {item.split()[0] for item in items if " " in item}
        if len(first_words) == 1 and all(" " in item for item in items):
            items = [item.split(None, 1)[1] for item in items]
    def norm(item: str) -> str:
        compact = re.sub(r"[^a-z0-9.\-]+", "", item)
        try:
            return repr(float(compact))  # 846.8 and 846.80 are the same number
        except ValueError:
            return compact

    return "|".join(norm(item) for item in items)


def is_freeform(answer: str) -> bool:
    """An answer two models will not phrase identically: prose, several lines, or a payload with prose in it."""
    text = (answer or "").strip()
    structured = parse_structured(text)
    if structured is not None:
        strings = re.findall(r'"((?:[^"\\]|\\.){40,})"', text)
        return bool(strings)
    # Prose: several words in sentences. A long exact-format answer (codes, key(value) lists) is not.
    words = text.split()
    return len(words) >= 14 and sum(1 for w in words if w.isalpha() or w.rstrip(".,;:").isalpha()) >= 0.7 * len(words)


def _plain(value: Any) -> Any:
    """Numbers and strings in a JSON answer, normalised so 1 and 1.0, 'Off' and 'off' compare equal."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        text = value.strip().casefold()
        try:
            return float(text.replace(",", ""))
        except ValueError:
            return text
    if isinstance(value, dict):
        return {str(k).strip().casefold(): _plain(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_plain(v) for v in value]
    return value


def bare_list(answer: str, context: str) -> str:
    """Drop a category word repeated on every item: "Team Alpha, Team Bravo" -> "Alpha, Bravo".

    The Practice judge marked the labelled form wrong ("'Team ' is not part of
    the team name") while always accepting the bare names. A word is removed
    only when it starts every item of a comma list AND the challenge's own
    description or rules use it as the category ("five teams", "team names"),
    so "New York, New Jersey" and "Room 1, Room 2" are left alone.
    """
    if answer.lstrip()[:1] in ("{", "[") or "\n" in answer.strip():
        return answer  # structured or multi-line output is passed through untouched
    items = [item.strip() for item in answer.split(",")]
    if len(items) < 2 or any(not 2 <= len(item.split()) <= 3 for item in items):
        return answer
    labels = {item.split()[0].casefold() for item in items}
    if len(labels) != 1:
        return answer
    label = re.escape(labels.pop().rstrip("."))
    if not re.search(rf"\b{label}s?\b", context.casefold()):
        return answer
    rest = [item.split(None, 1)[1] for item in items]
    if any(not part[0].isalpha() for part in rest):
        return answer
    return ", ".join(rest)


def parse_structured(answer: str) -> Any:
    """The JSON object or array an answer consists of, else None."""
    text = (answer or "").strip()
    if text[:1] not in ("{", "["):
        return None
    try:
        value = json.loads(text)
    except Exception:  # noqa: BLE001
        return None
    return value if isinstance(value, (dict, list)) else None


def _unfence(text: str) -> str:
    match = re.fullmatch(r"\s*```[\w-]*\n(.*?)\n?```\s*", text, flags=re.DOTALL)
    return match.group(1).strip() if match else text.strip()


def extract_answer(raw: str) -> str:
    """The answer in a model's reply: everything after its last ANSWER marker.

    A one-line answer is the usual case, but an answer can also be a JSON
    payload, a table or several lines, so the whole tail is kept. Without a
    marker, a reply that is itself JSON is the answer; otherwise its last
    line, or the whole reply when it is short and list-like.
    """
    text = re.sub(r"<think>.*?(?:</think>|$)", "", raw or "", flags=re.DOTALL).strip()
    marker = re.compile(r"^[ \t>*_#`-]*(?:final\s+)?answer[*_`]*\s*[:：][*_` \t]*", re.IGNORECASE | re.MULTILINE)
    answer = ""
    found = list(marker.finditer(text))
    if found:
        tail = text[found[-1].end():].strip()
        first, _, rest = tail.partition("\n")
        first = first.strip()
        structured_start = first[:1] in ("{", "[") and parse_structured(first) is None
        continues = bool(rest.strip()) and (
            not first or first.startswith("```") or structured_start
            # Further lines shaped like the first ("key: value", "- item", "| a | b |") belong to the answer.
            or all(re.match(r"\s*(?:[-*•]\s+\S|\d+[.)]\s+\S|\|.*\||[\w .()/-]{1,40}[:=]\s*\S)", line) for line in tail.splitlines() if line.strip())
        )
        answer = _unfence(tail) if continues else first
    elif parse_structured(_unfence(text)) is not None:
        answer = _unfence(text)
    else:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if 1 < len(lines) <= 8 and all(re.match(r"(?:[-*•]|\d+[.)])\s+\S", line) for line in lines):
            answer = "\n".join(lines)  # a short list with no marker is the answer as a whole
        else:
            answer = lines[-1] if lines and len(lines[-1]) < 400 else ""
    answer = answer.strip().strip("`").strip()
    if "\n" not in answer:
        answer = re.sub(r"^\*+|\*+$", "", answer).strip()  # markdown emphasis around a one-line answer
    lowered = answer.lower()
    if not answer or lowered in {"unknown", "n/a"} or "<tool" in lowered or "tool_calls" in lowered:
        return ""
    return answer


async def in_thread(func, *args, timeout: float = REST_TIMEOUT_S, **kwargs):
    return await asyncio.wait_for(asyncio.to_thread(func, *args, **kwargs), timeout=timeout)


async def hedged_call(primary, make_spare, name: str, arguments: dict[str, Any], hedge_after_s: float, timeout: float) -> dict[str, Any]:
    """Call an MCP tool; if no reply arrives in `hedge_after_s`, repeat it on a fresh connection.

    A submit normally answers in under 10 s, but now and then the reply never
    arrives on the open connection. The first usable reply wins; an error from
    one side is ignored while the other is still in flight.
    """
    tasks = {asyncio.create_task(primary.call(name, arguments, timeout=timeout))}
    spare = None
    last_exc: BaseException | None = None
    hedge_at = time.time() + hedge_after_s
    try:
        while tasks:
            wait_s = max(0.05, hedge_at - time.time()) if spare is None else None
            done, pending = await asyncio.wait(tasks, timeout=wait_s, return_when=asyncio.FIRST_COMPLETED)
            tasks = set(pending)
            for task in done:
                if task.exception() is None:
                    return task.result()
                last_exc = task.exception()
            if spare is None and (not done or not tasks):
                # Slow, or failed outright: send it again on a new connection.
                log(f"MCP {name} has not answered; repeating it on a fresh connection")
                spare = make_spare()
                tasks.add(asyncio.create_task(spare.call(name, arguments, timeout=timeout)))
        raise ConnectionError(f"MCP {name} failed on both connections: {last_exc}")
    finally:
        for task in tasks:
            task.cancel()
        if spare is not None:
            await quietly(spare.close())


async def quietly(coro) -> Any:
    """Await a best-effort side effect; never let it fail the run."""
    try:
        return await coro
    except Exception as exc:  # noqa: BLE001
        log(f"non-fatal: {type(exc).__name__}: {str(exc)[:120]}")
        return None


def save_record(agent_id: str, record: dict[str, Any]) -> None:
    try:
        out_dir = REPO_ROOT / "outputs"
        out_dir.mkdir(exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        text = json.dumps(record, indent=1, default=str)
        (out_dir / f"{agent_id}-run.json").write_text(text, encoding="utf-8")
        (out_dir / f"{agent_id}-{stamp}.json").write_text(text, encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        log(f"could not save run record: {exc}")


def score_line(score: dict[str, Any] | None) -> str:
    score = score or {}
    judge = {k: v for k, v in (score.get("judge") or {}).items() if k not in {"model", "rationale"}}
    return (
        f"final={score.get('final_score')} quality={score.get('quality_score')} speed={score.get('speed_score')} "
        f"tools={score.get('tools_score')} tokens={score.get('tokens_score')} ({score.get('total_tokens_used')} tok) "
        f"elapsed={score.get('elapsed_ms')}ms judge={judge} "
        f"thought_penalty={score.get('broadcast_penalty_applied')} missing={score.get('missing_required_tools')}"
    )


# ---------------------------------------------------------------------- runs


class Run:
    def __init__(self) -> None:
        self.strategy = MyStrategy()
        self.agent_id = (os.getenv("AGENT_ID") or self.strategy.agent_id).strip()
        self.agent_name = (os.getenv("AGENT_NAME") or self.strategy.agent_name).strip()
        os.environ["AGENT_ID"] = self.agent_id
        self.http = HttpArenaClient(api_base=get_api_base(), api_key=get_arena_api_key())
        self.arena = Arena(get_mcp_url(), self.agent_id)
        self.router: ModelRouter | None = None
        self.models: list[str] = []
        self.t0 = time.time()
        self.timeline: list[tuple[float, str]] = []
        self.record: dict[str, Any] = {"agent_id": self.agent_id}
        self.thought_tasks: list[asyncio.Task] = []
        self.best_answer = ""
        self.scope: str | None = None
        self.session_metrics: dict[str, Any] = {}
        self.text_started: float | None = None
        self.submitted = False
        self.registered = False
        self.sitting_out = False  # a battle is running that this agent is not part of
        self.required_tools: list[str] = []
        # Tools that must have been called before submitting: those the challenge lists as required
        # and those its text names. Checked by `ensure_required` whatever path led to the submit.
        self.must_call: list[str] = []
        self.deadline: float | None = None  # set when the challenge opens; the watchdog acts on it
        self.image_state: dict[str, Any] | None = None  # what an image heat needs to submit at any moment
        self.best_image = ""
        self.thoughts_sent = 0
        self.thoughts_ok = 0
        # What the server exposes besides tools, read before the clock starts.
        self.surface: dict[str, list[dict[str, str]]] = {"resources": [], "templates": [], "prompts": []}
        self.resource_texts: dict[str, str] = {}

    def mark(self, event: str) -> None:
        self.timeline.append((round(time.time() - self.t0, 2), event))
        log(event)

    def think(self, thought: str, stage: str = "") -> None:
        """Broadcast a thought without blocking the work (the spectator view and the score both use them).

        `stage` names the moment (read, ask, tools, call, wait, answer, plan, render, image, report) so the
        strategy can add a line of personality after the facts; it costs no model call.
        """
        if self.thoughts_sent >= MAX_THOUGHTS or not thought.strip():
            return
        self.thoughts_sent += 1
        text = self.strategy.flavor_thought(thought, stage, THOUGHT_MAX_CHARS)
        task = asyncio.create_task(self._send_thought(text))
        self.thought_tasks.append(task)
        self.note_thought(text, stage, task)

    def note_thought(self, text: str, stage: str, task: asyncio.Task | None = None) -> None:
        """Every broadcast goes into the run record (`thoughts`) and the console, with whether it arrived."""
        entry: dict[str, Any] = {"at_s": round(time.time() - self.t0, 1), "stage": stage, "text": text, "delivered": None}
        self.record.setdefault("thoughts", []).append(entry)
        log(f"thought> {text}")
        if task is not None:
            def done(finished: asyncio.Task) -> None:
                try:
                    entry["delivered"] = bool(finished.result())
                except BaseException:  # noqa: BLE001 - cancelled or failed: not delivered
                    entry["delivered"] = False

            task.add_done_callback(done)

    @contextlib.asynccontextmanager
    async def waiting(self, what: str):
        """Keep the spectator feed alive while `what` is being waited on. Never delays the work."""

        async def narrate() -> None:
            began = time.time()
            await asyncio.sleep(WAIT_THOUGHT_FIRST_S)
            for _ in range(WAIT_THOUGHT_MAX):
                if self.submitted or self.thoughts_sent >= MAX_THOUGHTS - WAIT_THOUGHT_RESERVE:
                    return
                self.think(f"Still waiting on {what} ({time.time() - began:.0f}s).", "wait")
                await asyncio.sleep(WAIT_THOUGHT_EVERY_S)

        task = asyncio.create_task(narrate())
        try:
            yield
        finally:
            task.cancel()

    async def _send_thought(self, thought: str) -> bool:
        async def by_rest() -> bool:
            await in_thread(self.http.broadcast_thought, self.agent_id, thought, timeout=6.0)
            return True

        async def by_mcp() -> bool:
            if "arena.image.broadcast_thought" not in self.arena.tool_defs:
                return False
            result = await self.arena.call(
                "arena.image.broadcast_thought", {"thought": thought, "agent_id": self.agent_id}, timeout=8.0
            )
            return not result.get("error")

        async def by_reasoning_tool() -> bool:
            if TEXT_THOUGHT_TOOL not in self.arena.tool_defs:
                return False
            arguments = schema_args(
                self.arena.tool_defs, TEXT_THOUGHT_TOOL, self.agent_id,
                text=(("reasoning", "thought", "text", "message", "content"), thought),
            )
            result = await self.arena.call(TEXT_THOUGHT_TOOL, arguments, timeout=8.0)
            return not result.get("error")

        # A thought tool is usually a required tool, so it comes first; REST is the fallback.
        text_channels = (by_reasoning_tool, by_rest) if TEXT_THOUGHT_TOOL in self.arena.tool_defs else (by_rest, by_rest)
        for channel in ((by_mcp, by_rest) if self.image_state is not None else text_channels):
            try:
                if await channel():
                    self.thoughts_ok += 1
                    return True
            except Exception as exc:  # noqa: BLE001
                log(f"non-fatal: thought not delivered ({type(exc).__name__})")
        return False

    async def flush_thoughts(self, wait_s: float = 2.5) -> None:
        """Make sure at least one thought got through before submitting.

        Once one has, nothing is waited for: the thoughts still in flight (the final "Answer: ..."
        always is) are delivered while the submit goes out. Waiting for them cost about half a
        second on every heat.
        """
        if self.thoughts_ok > 0:
            return
        pending = [t for t in self.thought_tasks if not t.done()]
        if pending:
            await quietly(asyncio.wait(pending, timeout=wait_s))
        if self.thoughts_ok == 0 and self.thoughts_sent:
            await quietly(asyncio.wait_for(self._send_thought("Working through the challenge; submitting now."), timeout=5.0))

    async def preflight(self) -> None:
        """Check connectivity, but never let one dropped request end the run.

        The kit's `ensure_connected()` exits on a single 3-second failure. A
        missing server or key is still fatal; a network blip is retried, and
        if validation never answers the run carries on to registration, which
        is what actually matters.
        """
        if not (os.getenv("ARENA_SERVER") or os.getenv("ARENA_API_BASE")) or not get_arena_api_key():
            ensure_connected()  # raises SystemExit with the kit's own explanation
        for attempt in range(1, STARTUP_ATTEMPTS + 1):
            try:
                await in_thread(ensure_connected, 6.0, timeout=10.0)
                return
            except SystemExit as exc:
                message = str(exc)
                if "missing or invalid" in message or "HTTP 401" in message or "HTTP 403" in message:
                    raise
                log(f"connectivity check attempt {attempt} failed: {message[:140]}")
            except Exception as exc:  # noqa: BLE001
                log(f"connectivity check attempt {attempt} failed: {type(exc).__name__}: {str(exc)[:120]}")
            await asyncio.sleep(min(1.0 * attempt, 5.0))
        log("connectivity check never passed; continuing to registration anyway")

    @staticmethod
    def pinned(models: list[str]) -> list[str]:
        """Experiment knob SKYNET_TEXT_MODEL: keep that one text model (image models stay), so a heat
        measures it alone. Without the knob, or if the roster lacks the model, the roster is unchanged."""
        from my_strategy import is_image_model

        wanted = knob("SKYNET_TEXT_MODEL", "").strip()
        if not wanted or wanted not in models:
            return models
        return [m for m in models if m == wanted or is_image_model(m)]

    async def setup(self) -> str:
        problem = agent_id_problem(self.agent_id)
        if problem:
            raise SystemExit(problem)
        await self.preflight()
        # Everything that does not need a session happens before registering:
        # MCP connection, tool list, model roster, and a warm proxy connection.
        self.router = ModelRouter(self.agent_id, resolve_usage_scope())

        # Practice starts the clock at registration, so there everything else is readied first.
        # With a lobby the clock starts at GO: register at once so a slow start cannot miss the heat.
        competition = await quietly(in_thread(self.http.get_competition, timeout=6.0)) or {}
        phase = str(competition.get("phase") or competition.get("status") or "").lower()
        hold_registration = asyncio.Event()
        if phase != "running":
            self.mark(f"competition phase is {phase or 'unknown'}: registering before anything else")
            hold_registration.set()
        registration = asyncio.create_task(self.register_session(hold_registration))
        self.arena.on_stuck = self.check_registration

        models_task = asyncio.create_task(quietly(in_thread(fetch_available_models, timeout=30.0)))
        warm_task = asyncio.create_task(quietly(asyncio.wait_for(self.router.client.models.list(), timeout=10.0)))
        # The MCP context must be opened and closed by the same task, so connect here.
        # (list_tools reconnects on its own if the first connection attempt fails.)
        tools: list[str] = []
        for attempt in range(1, STARTUP_ATTEMPTS + 1):
            try:
                tools = await self.arena.list_tools()
                break
            except Exception as exc:  # noqa: BLE001
                log(f"MCP not ready (attempt {attempt}): {type(exc).__name__}: {str(exc)[:120]}")
                await asyncio.sleep(min(1.0 * attempt, 5.0))
        if not tools:
            raise ConnectionError("could not reach the MCP server at startup")
        self.models = self.pinned(await models_task or [])
        await warm_task
        # Resources and prompts are listed (and small resources read) now, while it costs no challenge time.
        self.surface = await quietly(asyncio.wait_for(self.arena.inventory(), timeout=12.0)) or self.surface
        uris = [r["uri"] for r in self.surface["resources"] if r["uri"]][:8]
        if uris:
            texts = await asyncio.gather(*(quietly(asyncio.wait_for(self.arena.read_resource(u), timeout=8.0)) for u in uris))
            self.resource_texts = {u: str(t) for u, t in zip(uris, texts) if t}
        self.record.update(tools=tools, roster=self.models, surface=self.surface)
        hold_registration.set()
        self.mark(
            f"ready: {len(tools)} tools, {len(self.models)} models, {len(self.surface['resources'])} resources, "
            f"{len(self.surface['templates'])} resource templates, {len(self.surface['prompts'])} prompts"
        )
        await registration
        session, scope = await asyncio.gather(
            quietly(in_thread(self.http.get_session, self.agent_id, timeout=8.0)),
            quietly(in_thread(self.http.fetch_usage_scope, timeout=5.0)),
        )
        session = session if isinstance(session, dict) else {}
        # The session names the assignment (and its required tools) before the challenge is fetched.
        self.session_metrics = session.get("metrics") if isinstance(session.get("metrics"), dict) else {}
        modality = str(session.get("challenge_type") or "").lower()
        if modality not in {"text", "image"}:
            modality = await in_thread(McpArenaClient.detect_modality, tools, self.agent_id, timeout=25.0)
        self.scope = scope or resolve_usage_scope()
        if self.scope:
            self.router.set_scope(self.scope)
        self.mark(f"modality={modality}")
        return modality

    async def register_session(self, go: asyncio.Event | None = None) -> None:
        """Register, however long it takes; only a closed round or a rejected key ends the attempts."""
        if go is not None:
            await go.wait()
        attempt = 0
        rejected = 0
        while True:
            attempt += 1
            try:
                session = await in_thread(self.http.register, self.agent_id, self.agent_name, timeout=900.0)
                self.registered = True
                self.mark(f"registered ({session.status})")
                return
            except ArenaConnectionError as exc:
                message = str(exc)
                if "closed for the current round" in message:
                    if await self.round_standing() != "out":
                        # After GO a restart must not register again; continue on the existing session.
                        self.mark(f"registration skipped: {message}")
                        return
                    # Another group's battle is running and this agent is not in it: keep asking
                    # until the next lobby opens (the client then waits inside register()).
                    if not self.sitting_out:
                        self.sitting_out = True
                        self.mark("a battle is running without this agent; waiting for the next lobby")
                    await self.wait_out_battle()
                    continue
                log(f"registration attempt {attempt} failed: {message[:140]}")  # lobby not open yet, or a blip
            except ArenaAPIError as exc:
                log(f"registration attempt {attempt} rejected: HTTP {exc.status_code} {str(exc)[:140]}")
                if exc.status_code in (401, 403) or (400 <= exc.status_code < 500 and exc.status_code not in (408, 409, 425, 429)):
                    rejected += 1
                    if rejected >= STARTUP_ATTEMPTS:
                        return  # the server will not take this registration; carry on in case a session exists
            except Exception as exc:  # noqa: BLE001
                log(f"registration attempt {attempt} failed: {type(exc).__name__}: {str(exc)[:140]}")
            await asyncio.sleep(min(0.5 * attempt, 5.0))

    async def wait_out_battle(self) -> None:
        """Return once the running battle (someone else's) is over, by watching the phase.

        Registration is refused for as long as it runs, so nothing is posted
        meanwhile. If the phase cannot be read, return after a short pause and
        let registration be tried again.
        """
        while True:
            await asyncio.sleep(NEXT_LOBBY_POLL_S)
            competition = await quietly(in_thread(self.http.get_competition, timeout=6.0))
            phase = str((competition or {}).get("phase") or (competition or {}).get("status") or "").lower() \
                if isinstance(competition, dict) else ""
            if phase not in ("running", "countdown"):
                return

    async def round_standing(self) -> str:
        """Whether this agent is part of the round in progress: "in", "out" or "unknown".

        The competition state lists the agents frozen into the running battle
        (groups play one after another). Where it gives no list, having a
        session counts as being in. Never raises.
        """
        competition = await quietly(in_thread(self.http.get_competition, timeout=6.0))
        competition = competition if isinstance(competition, dict) else {}
        phase = str(competition.get("phase") or competition.get("status") or "").lower()
        eligible = competition.get("eligible_agent_ids")
        if isinstance(eligible, list):
            if self.agent_id in {str(value).strip() for value in eligible}:
                return "in"
            # A list that leaves this agent out only settles it once the battle has started.
            return "out" if phase == "running" else "unknown"
        if not competition:
            return "unknown"
        session = await quietly(in_thread(self.http.get_session, self.agent_id, timeout=8.0))
        if isinstance(session, dict) and session:
            return "in"
        return "out" if phase == "running" else "unknown"

    async def check_registration(self) -> None:
        """Called while the challenge stays shut: make sure the server still knows this agent,
        and that it is not waiting on a battle it was never part of."""
        session = await quietly(in_thread(self.http.get_session, self.agent_id, timeout=8.0))
        if not isinstance(session, dict) or not session:
            log("no session found while waiting for the challenge; registering again")
            await asyncio.wait_for(self.register_session(), timeout=60.0)
        elif await self.round_standing() == "out":
            # Registered, but the running battle belongs to another group: get into the next lobby.
            await asyncio.wait_for(self.register_session(), timeout=60.0)

    async def refresh_tools(self) -> None:
        """Tool sets depend on the puzzle: read the list again once the challenge is assigned."""
        before = set(self.arena.tool_defs)
        try:
            tools = await asyncio.wait_for(self.arena.list_tools(), timeout=8.0)
        except Exception as exc:  # noqa: BLE001
            log(f"tool list refresh failed ({type(exc).__name__}); keeping the earlier list")
            return
        added = [t for t in tools if t not in before]
        if added or len(tools) != len(before):
            self.mark(f"tool list changed after the challenge opened: now {len(tools)} tools, new: {added}")
            self.record["tools"] = tools
            surface = await quietly(asyncio.wait_for(self.arena.inventory(), timeout=8.0))
            if surface:
                self.surface = surface
                self.record["surface"] = surface

    async def prepare_models(self) -> None:
        # The usage scope changes at GO, so it is re-read after the challenge opens,
        # but a stalled request must not hold up solving: keep the earlier value.
        scope = await quietly(in_thread(self.http.fetch_usage_scope, timeout=2.5)) or self.scope
        if scope:
            os.environ["ARENA_USAGE_SCOPE"] = scope
            self.router.set_scope(scope)
        if not self.models:
            self.models = self.pinned(await quietly(in_thread(fetch_available_models, timeout=4.0)) or [])
            if not self.models:
                # The roster never loaded: try the aliases seen on Practice rather than sit idle.
                self.models = list(LAST_KNOWN_MODELS)
                self.mark("model roster unavailable; trying the last known aliases")
            self.record["roster"] = self.models

    # ------------------------------------------------------------------ text

    async def run_text(self) -> None:
        challenge = await self.arena.wait_for_challenge(image=False)
        started = self.text_started = time.time()
        models_task = asyncio.create_task(self.prepare_models())
        refresh_task = asyncio.create_task(self.refresh_tools())
        max_time = float(challenge.max_time_s or 90)
        deadline = self.deadline = started + float(challenge.time_remaining_s or max_time)
        self.mark(f"challenge {challenge.puzzle_id} ({challenge.challenge_type}, {max_time:.0f}s)")
        self.think(f"Reading {challenge.puzzle_id}: {challenge.description[:160]}", "read")
        raw = challenge.raw_data or {}
        required = self.required_tools = [str(t) for t in (raw.get("required_tools") or [])]

        # The payload usually carries the clues already. Start solving from them
        # at once and read the clue tools (usually required) in parallel.
        payload_clues = [str(c).strip() for c in (challenge.clues or []) if str(c).strip()]
        tools_task = asyncio.create_task(self.fetch_clues_and_required(challenge, required))
        if payload_clues:
            clues = payload_clues
            await models_task  # the tool list is awaited later, just before exploring needs it
        else:
            clues, _, _ = await asyncio.gather(tools_task, models_task, refresh_task)
        self.mark(f"{len(clues)} clues; required tools {required or 'none'}")

        ctx = ChallengeContext(
            challenge_type=challenge.challenge_type,
            difficulty=str(raw.get("difficulty") or "unknown"),
            challenge_text=challenge.extra_text if hasattr(challenge, "extra_text") else "",
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            time_remaining_s=deadline - time.time(),
            max_time_s=int(max_time),
            available_models=self.models,
            required_tools=required,
        )
        self.must_call = list(dict.fromkeys(required))
        output_format = str(raw.get("output_format") or "").strip()
        if output_format and output_format not in ctx.rules:
            ctx.rules = f"{ctx.rules.strip()}\nOutput format: {output_format}".strip()
        extras = {k: v for k, v in raw.items() if k not in CHALLENGE_CORE_KEYS and v not in (None, "", [], {})}
        if extras and not ctx.challenge_text:
            ctx.challenge_text = "Additional challenge fields: " + json.dumps(extras, default=str)[:6000]
        ranked = self.strategy.rank_models(ctx, self.models)
        chain = [(m, self.strategy.profile_for(m)) for m in ranked]
        self.record.update(challenge={**raw, "clues": clues}, model_chain=ranked[:6])

        # Anything encoded in the challenge itself is decoded by code before any model reads it.
        decoded = blackbox.annotate("\n".join([challenge.description or "", challenge.rules or "", *clues]))
        if decoded:
            self.mark(f"decoded text in the challenge: {decoded[:160]}")
            self.record["decoded"] = decoded
            ctx.challenge_text = f"Encoded parts of the challenge, decoded:\n{decoded}"
        # While the explorer works, a second model answers the challenge on its own from the text alone.
        # If the two agree, that is the confirmation the explorer's answer needs, and it is already in
        # hand when exploring ends (asked afterwards, the same confirmation cost 1-4 s in the lab). If
        # it disagrees, cannot know, or is slow, confirmation proceeds as before.
        shadow: asyncio.Task | None = None
        shadow_model = ""
        if knob("SKYNET_SHADOW", self.strategy.text_shadow_solver) != "off":
            explorer_first = (self.strategy.rank_explorer_models(self.models) or [""])[0]
            pick = next(((m, p) for m, p in chain if m != explorer_first and getattr(p, "solo_ok", True)), None)
            if pick is not None:
                shadow_model = pick[0]
                shadow = asyncio.create_task(quietly(self.router._one(
                    pick[0], pick[1],
                    [
                        {"role": "system", "content": self.strategy.build_system_prompt(ctx)},
                        {"role": "user", "content": self.strategy.build_solver_prompt(ctx)},
                    ],
                    self.strategy.text_max_tokens, max(5.0, deadline - time.time() - SUBMIT_MARGIN_S),
                )))

                def keep_independent(task: asyncio.Task) -> None:
                    # If time runs out while the server is still being explored, the watchdog submits
                    # the best answer on hand, and until now there was none: it sent "Unable to
                    # determine". The independent model's answer costs nothing more and may be right.
                    if task.cancelled() or task.exception() is not None or self.best_answer:
                        return
                    independent = extract_answer(task.result() or "")
                    if independent:
                        self.best_answer = independent
                        self.mark(f"holding {shadow_model}'s independent answer in case time runs out")

                shadow.add_done_callback(keep_independent)
        # An ordering puzzle: two fast models each translate the clues into constraints and the
        # solver searches for the order (order_tool). The same single order from both is the answer,
        # about 2 s in; anything else (not an ordering puzzle, several orders, a disagreement, a
        # slow reply) changes nothing below.
        fast: asyncio.Task | None = None
        if (knob("SKYNET_ORDER_TOOL", self.strategy.text_order_tool) != "off" and len(clues) >= 2 and not decoded
                and not extras and not [t for t in required if t not in FLOW_TOOLS]
                and order_tool.plain_list_wanted(f"{ctx.description} {ctx.rules}")):
            translators = self.strategy.rank_translator_models(self.models)[:ORDER_TOOL_TRANSLATORS]
            if len(translators) >= 2:
                fast = asyncio.create_task(quietly(self.order_by_solver(translators, ctx.description, ctx.rules, clues)))

        async def explore_when_ready():
            await asyncio.shield(refresh_task)  # shielded: cancelling the exploring must not cancel the tool listing
            return await self.explore(ctx, chain, required, deadline)

        exploring = asyncio.create_task(explore_when_ready())
        solved = None
        evidence: list[str] = []
        explorer_answer = ""
        try:
            async with self.waiting("the tool explorer"):
                if fast is not None:
                    await asyncio.wait({exploring, fast}, return_when=asyncio.FIRST_COMPLETED)
                    if fast.done() and not fast.cancelled():
                        solved = fast.result()
                if solved:
                    # Never awaited again: it ends on its own and its outcome is collected quietly.
                    exploring.cancel()
                    exploring.add_done_callback(lambda task: task.cancelled() or task.exception())
                else:
                    evidence, explorer_answer = await exploring
        except BaseException:
            for task in (shadow, fast, exploring):
                if task is not None and not task.done():
                    task.cancel()
            raise
        finally:
            if fast is not None and not fast.done():
                fast.cancel()
        if evidence:
            ctx.challenge_text = "\n\n".join(
                part for part in (ctx.challenge_text, "Findings from exploring the server:\n" + "\n".join(evidence)) if part
            )
            self.record["tool_evidence"] = evidence
            self.record["explorer_answer"] = explorer_answer

        def build_messages() -> list[dict]:
            return [
                {"role": "system", "content": self.strategy.build_system_prompt(ctx)},
                {"role": "user", "content": self.strategy.build_solver_prompt(ctx)},
            ]

        # A logic puzzle whose answer is a list of names: the Practice judge accepted the bare names
        # every time (87 of 87) and marked "Team Alpha, Team Bravo, ..." down 3 times in 20. The
        # challenge's own type decides whether this applies.
        names_bare = bool(re.search(r"logic|puzzle|order", str(challenge.challenge_type or ""), re.IGNORECASE))

        def keep_draft(candidate: str) -> None:
            if names_bare:
                candidate = bare_list(candidate, f"{challenge.description} {challenge.rules}")
            self.best_answer = candidate
            self.thought_tasks.append(asyncio.create_task(
                quietly(in_thread(self.http.save_draft, self.agent_id, candidate, "first candidate"))
            ))

        async def solve():
            # The explorer's own answer counts as one vote: a model that agrees after reading the findings settles it.
            seed = explorer_answer or None
            if seed:
                keep_draft(seed)
                # An answer the server itself returned word for word needs no second opinion.
                # (Each finding is "[tool arguments] result": only the result part counts.)
                raw_findings = "\n".join(
                    e.split("] ", 1)[-1] for e in evidence if not e.startswith("Explorer's summary")
                ).casefold()
                if len(seed) >= 8 and seed.casefold() in raw_findings:
                    return seed, "explorer", "explorer-verbatim"
                if is_freeform(seed):
                    # No second model will word this identically; the explorer worked from the facts.
                    return seed, "explorer", "explorer-freeform"
                # Anything else (a computed or ranked answer) needs a second opinion: in the lab the
                # explorer alone mis-ordered one ranking in 38 runs, and a wrong answer costs far more
                # than a confirmation. The model that answered independently meanwhile gives it at once.
                if shadow is not None:
                    reply = await quietly(asyncio.wait_for(asyncio.shield(shadow), timeout=SHADOW_GRACE_S))
                    independent = extract_answer(reply or "")
                    if independent and vote_key(independent) == vote_key(seed):
                        self.mark(f"{shadow_model} reached the same answer independently")
                        return seed, shadow_model, f"agreed:explorer+{shadow_model}(independent)"
                    self.mark(
                        f"independent answer from {shadow_model}: "
                        + (f"differs ({independent[:60]})" if independent else "not ready") + "; asking for confirmation"
                    )
                    if not shadow.done():
                        # Still thinking, and usually close to done: it stays in the vote next to the
                        # confirming models, and whichever agreement with the explorer comes first wins.
                        confirming = asyncio.create_task(confirm(seed))
                        await asyncio.wait({shadow, confirming}, return_when=asyncio.FIRST_COMPLETED)
                        if shadow.done() and not confirming.done():
                            late = extract_answer((None if shadow.cancelled() else shadow.result()) or "")
                            if late and vote_key(late) == vote_key(seed):
                                confirming.cancel()
                                self.mark(f"{shadow_model} reached the same answer independently (after the explorer)")
                                return seed, shadow_model, f"agreed:explorer+{shadow_model}(independent)"
                        return await confirming
            return await confirm(seed)

        async def confirm(seed):
            retry_until = started + OUTAGE_RETRY_UNTIL * max_time
            self.think(f"Asking {', '.join(m for m, _ in chain[:3]) or 'the models'} to check the answer.", "ask")
            while True:
                budget = max(5.0, deadline - time.time() - SUBMIT_MARGIN_S)
                outcome = await self.router.consensus(
                    chain, build_messages(), max_tokens=self.strategy.text_max_tokens, budget_s=budget,
                    accept=extract_answer, on_candidate=keep_draft,
                    # With the explorer's answer in hand, two confirmers: each re-reads the findings,
                    # and the arena bills the tokens of calls that get cancelled. With no answer yet,
                    # more are asked at once and the first two to agree decide.
                    parallel=2 if seed else self.strategy.text_parallel_models,
                    seed=seed,
                )
                if outcome or time.time() + OUTAGE_RETRY_WAIT_S > retry_until:
                    return outcome
                # Nothing answered. Failures are often a short proxy cooldown: wait it out and ask again.
                self.mark(f"no model answered; retrying in {OUTAGE_RETRY_WAIT_S:.0f}s")
                await asyncio.sleep(OUTAGE_RETRY_WAIT_S)
                self.router.down.clear()

        try:
            if solved:
                result = solved
                self.think("Two models turned the clues into constraints; the solver found exactly one order that fits.", "tools")
            else:
                async with self.waiting("the models"):
                    result = await solve()
        finally:
            if shadow is not None and not shadow.done():
                shadow.cancel()
        # The clue tools must have been called before submitting. If they
        # returned different clues than the payload, the tools win: solve again.
        clue_wait = max(0.5, min(FLOW_WAIT_BEFORE_SUBMIT_S, deadline - time.time() - WATCHDOG_MARGIN_S - 2.0))
        tool_clues = await quietly(asyncio.wait_for(asyncio.shield(tools_task), timeout=clue_wait)) or []
        if tool_clues and sorted(tool_clues) != sorted(clues):
            self.mark("clue tools differ from the challenge payload; solving again with tool clues")
            ctx.clues = tool_clues
            self.record["challenge"]["clues"] = tool_clues
            result = await solve() or result
        if not result and self.best_answer:
            result = (self.best_answer, shadow_model or "draft", "draft-only")  # one model's answer beats none
        answer, model, basis = result if result else (FALLBACK_TEXT_ANSWER, "none", "no-model-answered")
        self.record["raw_answer"] = answer
        if names_bare:
            # Only for a logic puzzle: there the Practice judge rejects a repeated category word
            # ("Team Alpha"). Any other answer is submitted as the model gave it.
            answer = bare_list(answer, f"{challenge.description} {challenge.rules}")
        self.best_answer = answer
        self.record["basis"] = basis
        self.mark(f"answer from {model} ({basis}): {answer[:120]}")
        self.think(f"Answer: {answer[:200]} (decided by {basis}).", "answer")
        await self.ensure_required(f"{challenge.description} {challenge.rules}")
        await self.flush_thoughts(min(2.5, max(0.2, deadline - time.time() - WATCHDOG_MARGIN_S - 1.0)))
        await self.submit_text(answer, model, started)

    async def order_by_solver(self, translators: list[str], description: str, rules: str, clues: list[str]):
        """(answer, model, basis) when two models' translations lead the solver to the same single order, else None."""
        messages = [
            {"role": "system", "content": order_tool.SYSTEM_PROMPT},
            {"role": "user", "content": order_tool.build_user_prompt(description, rules, clues)},
        ]

        async def one(model: str) -> dict:
            reply = await quietly(self.router._one(
                model, self.strategy.translator_profile_for(model), messages, ORDER_TOOL_MAX_TOKENS, ORDER_TOOL_TIMEOUT_S))
            if not reply:
                return {"status": "error", "answer": "", "error": "no reply"}
            return await quietly(in_thread(order_tool.settle, reply, timeout=3.0)) or {"status": "error", "answer": "", "error": "solver timeout"}

        async def named(model: str) -> tuple[str, dict]:
            return model, await one(model)

        pending = {asyncio.create_task(named(model)) for model in translators}
        outcomes: dict[str, dict] = {}
        log = self.record["order_tool"] = []
        agreed: tuple[str, str, str] | None = None
        try:
            while pending and agreed is None:
                done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
                for task in done:
                    model, outcome = task.result()
                    log.append({"model": model, **{k: v for k, v in outcome.items()
                                                   if k in ("status", "answer", "items", "constraints", "orders", "error")}})
                    if outcome["status"] == "unique":
                        # "Team Alpha, Team Bravo" from one and "Alpha, Bravo" from another are the same order.
                        key = bare_list(outcome["answer"], f"{description} {rules}")
                        partner = next((m for m, o in outcomes.items()
                                        if o["status"] == "unique" and bare_list(o["answer"], f"{description} {rules}") == key), None)
                        if partner and agreed is None:
                            agreed = (outcomes[partner]["answer"], partner, f"solver:{partner}+{model}")
                    outcomes[model] = outcome
        finally:
            for task in pending:
                task.cancel()
        summary = ", ".join(f"{model}: {outcome['status']}" for model, outcome in outcomes.items())
        if agreed:
            self.mark(f"ordering solver: two translations give the same single order ({summary}): {agreed[0][:120]}")
            return agreed
        self.mark(f"ordering solver: not used ({summary})")
        return None

    def briefing(self, offered: list[str], listing: str) -> str:
        """What the server exposes, written out for the exploring model."""
        lines = ["SERVER INVENTORY", "Tools (most have no description; judge by name and parameters):"]
        for name in offered:
            definition = self.arena.tool_defs.get(name) or {}
            schema = definition.get("schema") or {}
            needed = set(schema.get("required") or [])
            params = ", ".join(
                f"{key}{'' if key in needed else '?'}: {(spec or {}).get('type', 'any')}"
                for key, spec in (schema.get("properties") or {}).items() if key != "agent_id"
            )
            description = (definition.get("description") or "").strip()
            lines.append(f"- {name}({params})" + (f": {description[:300]}" if description else ""))
        if listing:
            lines.append(f"arena.tools.list returned: {listing[:1500]}")
        lines.append(
            "Already done for you, never repeat: the challenge and every clue have been fetched "
            f"({', '.join(sorted(ALREADY_READ))}); what they returned is the challenge text above, in full."
        )
        for item in self.surface["resources"]:
            content = self.resource_texts.get(item["uri"], "")
            lines.append(f"Resource {item['uri']} ({item['name']}) {item['description']}".rstrip())
            if content:
                lines.append(f"  content: {content[:1500]}")
                decoded = blackbox.annotate(content)
                if decoded:
                    lines.append(f"  auto-decoded:\n{decoded}")
        for item in self.surface["templates"]:
            lines.append(f"Resource template {item['uri']} ({item['name']}) {item['description']}".rstrip())
        for item in self.surface["prompts"]:
            lines.append(f"Prompt {item['name']}({item['arguments']}) {item['description']}".rstrip())
        return "\n".join(lines)

    async def explore(
        self, ctx: ChallengeContext, chain, required: list[str], deadline: float, *, budget_cap: float = 0.0,
    ) -> tuple[list[str], str]:
        """Work an unfamiliar server: discover what is there, use it, decode what comes back.

        Returns (evidence, the explorer's own answer or ""). Challenges that
        need nothing beyond their own text skip this entirely. A model drives
        the server's tools through function calling, with local decoding and
        access to unlisted tools, resources and prompts; a required tool it
        never called is then called directly so it is not missing at submit.
        """
        tools = list(self.arena.tool_defs)
        extra = [t for t in tools if t not in FLOW_TOOLS]
        required_extra = [t for t in required if t not in FLOW_TOOLS]
        extra += [t for t in required_extra if t not in extra]  # required but unlisted: still reachable by name
        text = " ".join([ctx.description or "", ctx.rules or "", ctx.challenge_text or "", *ctx.clues])
        if not self.strategy.wants_exploration(ctx, extra, required_extra, self.surface, text):
            return [], ""
        if knob("SKYNET_EXPLORER", "") == "off" and not required_extra:  # experiment knob: one model answers, no tools
            return [], ""
        is_image = self.strategy.is_image_challenge(ctx)
        offered = [t for t in extra if t in required_extra or not SUBMIT_LIKE.search(t)]
        if "image_analyze" in tools:
            offered.append("image_analyze")  # a question may be about a picture; an image brief may need facts from it
        self.mark(f"exploring: tools {offered} (required: {required_extra or 'none'})")
        self.think(f"Working the challenge with the server's tools in reach: {', '.join(offered)[:200] or 'none listed'}.", "tools")
        specs, name_map = function_specs(self.arena.tool_defs, offered)
        specs += [
            spec for name, spec in VIRTUAL_TOOLS.items()
            if (name != "get_prompt" or self.surface["prompts"])
            and (name != "read_resource" or self.surface["resources"] or self.surface["templates"] or "://" in text)
        ]

        # Only what the challenge lists as required is forced. How often to use a tool, and whether a
        # tool its text mentions should be used at all, is for the model to read: code that guessed
        # at that from wording misread "one fact per claim" as a limit and "do not use X" as a must.
        must = list(required_extra)
        previous: dict[tuple[str, str], str] = {}  # the latest reply to each exact call
        sent: dict[tuple[str, str], int] = {}      # how often each exact call was really sent
        inflight: dict[tuple[str, str], asyncio.Future] = {}
        kept: dict[str, Any] = {}                  # results the model saw only part of, whole, for the python tool
        kept_chars = [0]

        def keep(value: Any) -> str:
            """Store a result in full for the python tool; returns its key, or "" when there is no room."""
            size = len(full_result_text(value))
            if len(kept) >= KEPT_RESULTS or size > KEPT_RESULT_CHARS or kept_chars[0] + size > KEPT_TOTAL_CHARS:
                return ""
            label = f"r{len(kept) + 1}"
            kept[label] = value
            kept_chars[0] += size
            return label

        async def run_tool(name: str, arguments: dict[str, Any]) -> tuple[str, Any]:
            """(what the model is shown, the reply in full or None when nothing new came from the server)."""
            if SUBMIT_LIKE.search(name) and name not in required_extra:
                return "refused: submitting is handled separately once the answer is known", None
            if name in ALREADY_READ and name not in refetch_warned:
                # The runtime read the challenge and every clue before the model was asked: fetching
                # them again took whole model turns for nothing (10 s on a Practice logic heat). The
                # first attempt is answered here; a model that asks again is let through, in case a
                # server really does change what these return.
                refetch_warned.add(name)
                return ("already fetched: the challenge and every clue are in your instructions, complete. "
                        "Do not fetch them again; answer now or use a different tool."), None
            signature = (name, json.dumps(arguments, sort_keys=True, default=str))
            if signature in inflight:  # the same call twice in one turn is sent once
                return await asyncio.shield(inflight[signature])
            # The same call is really sent again, a few times: a server with state answers differently
            # after an unlock, and a status is there to be read twice. (Every repeat used to be
            # answered from memory, a failed first reply included.) Past the limit the model is told.
            if sent.get(signature, 0) >= IDENTICAL_CALLS:
                return (f"{previous.get(signature, '')}\n[this exact call has been sent {sent[signature]} times and that is its latest "
                        "reply; change the arguments or use a different tool]"), None

            async def send() -> tuple[str, Any]:
                sent[signature] = sent.get(signature, 0) + 1
                shown, raw = await call_server(name, arguments)
                same = previous.get(signature) == shown
                previous[signature] = shown
                return (f"{shown}\n[the same reply as the last time this exact call was made]" if same else shown), raw

            task = inflight[signature] = asyncio.ensure_future(send())
            try:
                return await task
            finally:
                inflight.pop(signature, None)

        async def call_server(name: str, arguments: dict[str, Any]) -> tuple[str, Any]:
            if name == "image_analyze" and self.image_state is not None:
                # The input image is far too large to pass through a model: it goes in by reference.
                for key in ("image_uri", "image_url", "image"):
                    if key in arguments or key == "image_uri":
                        value = str(arguments.get(key) or "")
                        if not value.startswith(("http", "data:")):
                            arguments = {**arguments, key: self.image_state["input_uri"]}
                        break
            analyze_properties = ((self.arena.tool_defs.get("image_analyze") or {}).get("schema") or {}).get("properties") or {}
            if name == "image_analyze" and not arguments.get("model") and (not analyze_properties or "model" in analyze_properties):
                vision = self.strategy.rank_vision_models(self.models)
                if vision:
                    arguments = {**arguments, "model": vision[0]}  # the tool's default model fails on Practice
            schema = (self.arena.tool_defs.get(name) or {}).get("schema") or {}
            known = name in self.arena.tool_defs
            if "agent_id" in (schema.get("properties") or {}) or (not known and "agent_id" not in arguments):
                arguments = {**arguments, "agent_id": self.agent_id}
            # Bounded by the time left, and a tool with a call limit is never re-sent on a timeout.
            timeout = max(3.0, min(25.0, deadline - time.time() - WATCHDOG_MARGIN_S - 2.0))
            # Not re-sent on a timeout: a capability call may not be free to repeat.
            raw = await self.arena.call(name, arguments, timeout=timeout, retry=False)
            result = tool_result_text(raw)
            if not known and "agent_id" in arguments and re.search(r"unexpected|extra|not permitted|validation", result, re.IGNORECASE):
                arguments = {k: v for k, v in arguments.items() if k != "agent_id"}
                raw = await self.arena.call(name, arguments, timeout=timeout, retry=False)
                result = tool_result_text(raw)
            return result, raw

        refetch_warned: set[str] = set()

        # Tools can appear once a step is done (an unlock, a nested challenge). The list is read
        # again after each model turn that called the server (once, however many calls the turn
        # made), and anything new is handed to the model as a function it can call, with a note.
        server_called = [False]
        relist_off = [not hasattr(self.arena, "list_tools")]

        async def notice_new_tools() -> str:
            if relist_off[0] or not server_called[0]:
                return ""
            server_called[0] = False
            before = set(self.arena.tool_defs)
            try:
                names = await asyncio.wait_for(self.arena.list_tools(), timeout=max(1.0, min(2.5, deadline - time.time() - WATCHDOG_MARGIN_S - 2.0)))
            except Exception as exc:  # noqa: BLE001 - a server that will not list again is simply not asked again
                log(f"tool list could not be read again ({type(exc).__name__}); not asking again")
                relist_off[0] = True
                return ""
            added = [n for n in names if n not in before and n not in FLOW_TOOLS and not SUBMIT_LIKE.search(n)]
            if not added:
                return ""
            new_specs, new_map = function_specs(self.arena.tool_defs, added)
            specs.extend(new_specs)  # the same list the model is given on its next turn
            name_map.update(new_map)
            self.mark(f"new tools appeared while exploring: {added}")
            self.record.setdefault("tools_appeared", []).extend(added)
            return "\n[new tools have appeared on the server and can be called now: " + ", ".join(added)[:600] + "]"

        async def execute(function_name: str, arguments: dict[str, Any]) -> str:
            try:
                if function_name == "python":
                    left = max(2.0, min(10.0, deadline - time.time() - WATCHDOG_MARGIN_S - 2.0))
                    return await in_thread(blackbox.run_python, str(arguments.get("code") or ""), left, dict(kept) or None, timeout=left + 3.0)
                if function_name == "read_resource":
                    raw = await self.arena.read_resource(str(arguments.get("uri") or ""))
                    result = tool_result_text(raw)
                elif function_name == "get_prompt":
                    nested = arguments.get("arguments")
                    raw = await self.arena.get_prompt(str(arguments.get("name") or ""), nested if isinstance(nested, dict) else {})
                    result = tool_result_text(raw)
                elif function_name == "call_tool":
                    nested = arguments.get("arguments")
                    target = str(arguments.get("name") or "")
                    result, raw = await run_tool(target, dict(nested) if isinstance(nested, dict) else {})
                else:
                    result, raw = await run_tool(name_map.get(function_name, function_name), arguments)
            except Exception as exc:  # noqa: BLE001
                return f"tool error: {type(exc).__name__}: {str(exc)[:200]}"
            # Only the tool's name goes to the feed: no arguments, no raw reply.
            self.think(f"Called {function_name}.", "call")
            if raw is None:  # nothing new from the server: a refusal, or a repeat answered from memory
                return result
            server_called[0] = True
            if was_cut(result):
                label = keep(raw)
                if label:
                    result += f"\n[shortened above; the complete result is results['{label}'] in the python tool]"
            # Decoding reads the whole reply, not the shortened text: a long encoded value is cut
            # before its end otherwise and decodes to nothing. Inline images are left out.
            whole = re.sub(r"data:[\w/+.\-]+;base64,[A-Za-z0-9+/=_\-]+", "<data>", full_result_text(raw))[:DECODE_SCAN_CHARS]
            notes = []
            for piece, method, decoded in blackbox.find_encoded(whole):
                more = ""
                if len(decoded) > 600:
                    label = keep(decoded)
                    more = f"...<{len(decoded) - 600} more chars" + (f"; complete text is results['{label}'] in the python tool>" if label else ">")
                notes.append(f"- {piece[:60]}{'...' if len(piece) > 60 else ''} decodes ({method}) to: {decoded[:600]}{more}")
            if notes:
                result += "\n[auto-decoded]\n" + "\n".join(notes)
            return result

        # Read-only tools that need no arguments are called at once, together, so the first model
        # turn already has what they say instead of spending a step asking for it.
        def probe_worthy(name: str) -> bool:
            schema = (self.arena.tool_defs.get(name) or {}).get("schema") or {}
            needs = [r for r in (schema.get("required") or []) if r != "agent_id"]
            # A required capability tool is left for the model to call properly: probing it with
            # no arguments could spend the one call the challenge allows.
            return not needs and name not in must and bool(PROBE_YES.search(name)) and not PROBE_NO.search(name)

        probes = [t for t in offered if probe_worthy(t)][:PROBE_LIMIT]
        listing_task = asyncio.create_task(quietly(self.arena.call("arena.tools.list", {"agent_id": self.agent_id}, timeout=8.0))) \
            if "arena.tools.list" in tools else None
        probe_results = await asyncio.gather(*(execute(name, {}) for name in probes))
        listing = tool_result_text(await listing_task or "") if listing_task else ""
        # A listing that only repeats the tool names we already have tells the model nothing.
        if listing and all(name in listing for name in tools) and not re.sub(r"[\W_]+", "", re.sub("|".join(re.escape(t) for t in sorted(tools, key=len, reverse=True)), "", listing).replace("tools", "").replace("raw", "")):
            listing = ""
        probed = [f"[{name} {{}}] {result}" for name, result in zip(probes, probe_results)]
        if probed:
            self.mark(f"probed {probes}")
        left = deadline - time.time()
        budget = max(8.0, min(0.55 * left, 70.0))
        if budget_cap:
            budget = min(budget, budget_cap)
        # A chain of steps that is still turning up something new may run past that budget, as far
        # as leaves the answering models and the submit a quarter of the time (25 s at least).
        stretch = 0.0 if budget_cap else max(0.0, left - budget - max(25.0, 0.25 * left))
        closing: list[str] = []
        explorers = [(m, self.strategy.explorer_profile_for(m)) for m in self.strategy.rank_explorer_models(self.models)]
        override = knob("SKYNET_EXPLORER", "").strip()  # experiment knob: "model" or "model:effort"
        if override:
            wanted, _, effort = override.partition(":")
            body = {"reasoning": {"effort": effort}} if effort else {}
            explorers = [(m, ModelProfile(m, body)) for m in self.models if wanted in m][:1] + explorers
        messages = [
            {"role": "system", "content": self.strategy.explore_system_prompt},
            {"role": "user", "content": self.strategy.build_explore_request(
                ctx, self.briefing(offered, listing) + ("\nAlready called for you:\n" + "\n".join(probed) if probed else ""),
                [t for t in must if t not in self.arena.tools_called and not SUBMIT_LIKE.search(t)],
            )},
        ]
        explore_until = time.time() + budget
        evidence: list[str] = list(probed)
        # A stalled step hands over to the next model, which continues from the findings. If every
        # model stalls (a proxy hiccup), go round again with more patience while the budget lasts:
        # answering without the server's facts would be a guess.
        for step_timeout in (12.0, 20.0, 30.0):
            remaining = explore_until - time.time()
            if closing or remaining < 6.0:
                break
            if len(evidence) > len(probed):
                messages = messages[:2] + [{"role": "user", "content": "Tool results gathered so far:\n" + "\n".join(evidence[len(probed):])}]
            evidence += await self.router.tool_loop(
                explorers or [(m, p) for m, p in chain], messages, specs, execute,
                budget_s=remaining, max_steps=EXPLORE_MAX_STEPS, closing=closing, step_timeout_s=step_timeout, stretch_s=stretch,
                after_calls=notice_new_tools,
            )
            if not closing:
                self.mark("exploration stalled before reaching an answer; going round again")
                for model, _ in explorers:
                    self.router.tool_down.discard(model)
        question = f"{ctx.description} {ctx.rules}".strip()
        for name in must:
            if name in self.arena.tools_called or SUBMIT_LIKE.search(name):
                continue
            schema = (self.arena.tool_defs.get(name) or {}).get("schema") or {}
            self.mark(f"calling required tool {name} directly")
            evidence.append(f"[{name}] {await execute(name, guess_tool_arguments(schema, question))}")
        if kept:
            self.record["results_kept"] = {label: len(full_result_text(value)) for label, value in kept.items()}
        conclusion = closing[-1] if closing else ""
        own_answer = extract_answer(conclusion) if re.search(r"answer\s*:", conclusion, re.IGNORECASE) else ""
        if conclusion:
            evidence.append(f"Explorer's summary: {conclusion[:2000]}")
        self.mark(f"explored: {len(evidence)} findings; explorer answer: {own_answer[:80] or 'none'}")
        return trim_evidence(evidence), own_answer

    async def fetch_clues_and_required(self, challenge, required: list[str]) -> list[str]:
        clues = await self.fetch_clues(challenge)
        await self.call_required_tools(required)
        return clues

    async def fetch_clues(self, challenge) -> list[str]:
        """Read every clue through the clue tools (they are usually required)."""
        try:
            listing = await self.arena.call("arena.clues.list", {"agent_id": self.agent_id}, timeout=FLOW_CALL_TIMEOUT_S, retry=False)
            clue_ids = [str(c) for c in (listing.get("clue_ids") or [])]
            results = await asyncio.gather(
                *(self.arena.call("arena.clues.get", {"clue_id": cid, "agent_id": self.agent_id}, timeout=FLOW_CALL_TIMEOUT_S, retry=False)
                  for cid in clue_ids),
                return_exceptions=True,
            )
            texts = [str(r.get("text") or "").strip() for r in results if isinstance(r, dict)]
            texts = [t for t in texts if t]
            if texts and len(texts) == len(clue_ids):
                return texts
        except Exception as exc:  # noqa: BLE001
            log(f"clue tools failed ({type(exc).__name__}); using clues from the challenge payload")
        return [str(c) for c in (challenge.clues or [])]

    async def call_required_tools(self, required: list[str]) -> None:
        """Call any required tool that the normal flow has not already used."""
        for name in required:
            # Only the standard flow tools: a capability tool (search, calculator, ...) must be called
            # with real arguments, and often a set number of times, so that is left to the explorer.
            if name in self.arena.tools_called or name not in FLOW_TOOLS or name in (TEXT_SUBMIT_TOOL, TEXT_THOUGHT_TOOL):
                continue
            await quietly(self.arena.call(name, {"agent_id": self.agent_id}, timeout=FLOW_CALL_TIMEOUT_S, retry=False))

    async def submit_text(self, answer: str, model: str, started: float) -> None:
        metrics = {
            "model_name": model,
            "total_tokens": str(self.router.usage["total_tokens"]),
            "prompt_tokens": str(self.router.usage["prompt_tokens"]),
            "completion_tokens": str(self.router.usage["completion_tokens"]),
            "total_time_ms": int((time.time() - started) * 1000),
        }
        result = None
        self.submitted = True  # from here on only this exact answer may be sent
        if TEXT_SUBMIT_TOOL in self.required_tools and TEXT_SUBMIT_TOOL in self.arena.tool_defs:
            # The challenge names the MCP submit tool as required: a REST submission would leave it uncalled.
            arguments = schema_args(
                self.arena.tool_defs, TEXT_SUBMIT_TOOL, self.agent_id,
                answer=(("answer", "final_answer", "solution", "response", "text"), answer),
                metrics=(("client_metrics", "metrics", "?"), metrics),
            )
            try:
                reply = await self.arena.call(TEXT_SUBMIT_TOOL, arguments, timeout=30.0, retry=False)
                if not reply.get("error") and not str(reply.get("raw") or "").lower().startswith("error"):
                    result = SimpleNamespace(accepted=reply.get("accepted", True), score=reply.get("score"))
                else:
                    log(f"MCP submit refused: {str(reply)[:160]}; submitting over REST")
            except Exception as exc:  # noqa: BLE001
                log(f"MCP submit failed ({type(exc).__name__}); submitting over REST")
        for attempt in range(4 if result is None else 0):
            try:
                result = await in_thread(self.http.submit, self.agent_id, answer, metrics, timeout=30.0)
                break
            except ArenaAPIError as exc:
                log(f"submit rejected: HTTP {exc.status_code} {str(exc)[:160]}")
                if exc.status_code == 409 or 400 <= exc.status_code < 500:
                    break  # an answer is already official, or the request is invalid
            except Exception as exc:  # noqa: BLE001 - lost response: retry the exact same answer
                log(f"submit attempt {attempt + 1} failed: {type(exc).__name__}: {str(exc)[:120]}")
            await asyncio.sleep(0.5 * (attempt + 1))
        score = getattr(result, "score", None)
        self.mark(f"submitted accepted={getattr(result, 'accepted', None)} {score_line(score)}")
        self.record.update(
            answer=answer, model=model, accepted=getattr(result, "accepted", None), score=score,
            local_elapsed_s=round(time.time() - started, 2),
        )

    # ----------------------------------------------------------------- image

    async def run_image(self) -> None:
        challenge = await self.arena.wait_for_challenge(image=True)
        started = time.time()
        models_task = asyncio.create_task(self.prepare_models())
        refresh_task = asyncio.create_task(self.refresh_tools())
        max_time = float(challenge.max_time_s or 90)
        deadline = self.deadline = started + float(challenge.time_remaining_s or max_time)
        self.mark(f"challenge {challenge.puzzle_id} ({challenge.challenge_type}, {max_time:.0f}s)")
        task_text = (challenge.prompt or challenge.description or "").strip()
        notes = (challenge.reference_notes or "").strip()
        input_uri = (challenge.input_image_uri or "").strip()
        # Read from the file as it was given: re-encoding it (below) drops everything but the pixels.
        hidden_task = asyncio.create_task(quietly(in_thread(image_ops.hidden_text_uri, input_uri, timeout=8.0))) if input_uri else None
        if len(input_uri) > image_ops.MAX_DATA_URI_CHARS:
            # Sent back to the image tools as it is, an image this large is refused by the server.
            fitted = await quietly(in_thread(image_ops.fit_data_uri, input_uri, timeout=10.0)) or input_uri
            if fitted != input_uri:
                self.mark(f"input image re-encoded to fit a request: {len(input_uri) // 1024} KB -> {len(fitted) // 1024} KB")
                input_uri = fitted
        self.image_state = {
            "started": started, "challenge": challenge, "task_text": task_text, "notes": notes, "input_uri": input_uri,
            "tool": "image_edit" if input_uri else "image_generate", "kind": "", "report": "", "model": "",
            "prompt": "", "rewriter": "template", "max_time": max_time,
        }
        ctx = ChallengeContext(
            challenge_type=challenge.challenge_type or "image",
            difficulty=challenge.difficulty or "unknown",
            challenge_text=task_text,
            description=challenge.description,
            rules="\n".join(p for p in (task_text, notes) if p),
            max_time_s=int(max_time),
            image_url=input_uri or None,
        )
        opening = self.strategy.flavor_thought(f"Planning image task: {task_text[:200]}", "read", THOUGHT_MAX_CHARS)
        thought = asyncio.create_task(
            quietly(self.arena.call("arena.image.broadcast_thought", {"thought": opening, "agent_id": self.agent_id}))
        )
        self.note_thought(opening, "read", thought)
        await asyncio.gather(models_task, refresh_task)
        ctx.available_models = self.models
        hidden = (await quietly(asyncio.wait_for(asyncio.shield(hidden_task), timeout=3.0)) or []) if hidden_task else []
        if hidden:
            # A file can carry text outside its pixels (a comment, a text chunk, bytes after the image).
            # The explorer and the planner are shown it, decoded where it is encoded, and decide.
            self.mark(f"text found inside the input image file: {' | '.join(hidden)[:200]}")
            self.record["image_hidden_text"] = hidden
            decoded = blackbox.annotate("\n".join(hidden))
            notes = "\n".join(p for p in (
                notes,
                "Text found inside the input image file, outside its pixels (it may be an instruction or data for this "
                "task, or unrelated file metadata; use it only if it clearly bears on the task):",
                *(f"- {item}" for item in hidden),
                f"Decoded:\n{decoded}" if decoded else "",
            ) if p)
            self.image_state["notes"] = notes
            ctx.rules = "\n".join(p for p in (task_text, notes) if p)

        required = list(challenge.required_tools) or [str(t) for t in (self.session_metrics.get("required_tools") or [])]
        try:
            async with self.waiting("the tool explorer"):
                findings, found_brief = await self.explore(
                    ctx, [], required, deadline, budget_cap=max(8.0, 0.25 * (deadline - time.time()))
                )
        except Exception as exc:  # noqa: BLE001 - exploring must never cost the image
            log(f"image exploration failed: {type(exc).__name__}: {str(exc)[:120]}")
            findings, found_brief = [], ""
        if found_brief:
            self.image_state["report"] = found_brief
        if findings:
            self.record["tool_evidence"] = findings
            # What the server revealed joins the brief the planner works from.
            notes = "\n".join(p for p in (notes, f"Found on the server: {found_brief}" if found_brief else "\n".join(findings)[-1500:]) if p)
            self.image_state["notes"] = notes

        prompt = self.strategy.build_image_fallback_prompt(ctx, task_text, notes)
        rewriters = self.strategy.rank_rewriter_models(self.models)
        rewriter_override = knob("SKYNET_REWRITER", "").strip()  # experiment knob: "off" or a model name
        if rewriter_override == "off":
            rewriters = []
        elif rewriter_override:
            rewriters = [m for m in self.models if rewriter_override in m] or rewriters
        async def write_prompt():
            if not rewriters:
                return None
            return await self.router.race(
                [(m, self.strategy.profile_for(m, rewriter=True)) for m in rewriters[:4]],
                [
                    {"role": "system", "content": self.strategy.image_rewrite_system},
                    {"role": "user", "content": self.strategy.build_image_rewrite_request(ctx, task_text, notes)},
                ],
                max_tokens=700,
                budget_s=min(9.0, max(3.0, (deadline - time.time()) * 0.1)),
                accept=lambda text: text.strip() if len(text.strip()) > 40 else "",
                parallel=2,
            )

        tools = list(self.arena.tool_defs) or self.record.get("tools") or []
        tool = "image_edit" if input_uri and "image_edit" in tools else "image_generate"
        if "image_generate" in required and "image_edit" not in required and "image_generate" in tools:
            tool = "image_generate"
        image_override = knob("SKYNET_IMAGE_MODEL", "").strip()  # experiment knob

        def models_for(task_kind: str) -> list[str]:
            ranked = self.strategy.rank_image_models(ctx, self.models, task_kind)
            if image_override:
                ranked = [m for m in ranked if image_override == m] + [m for m in ranked if image_override != m]
            return ranked

        async def produce(model: str, text: str | None = None) -> tuple[str, str]:
            properties = ((self.arena.tool_defs.get(tool) or {}).get("schema") or {}).get("properties") or {}

            def named(candidates: tuple[str, ...]) -> str:
                # The parameter name this server uses, falling back to the Practice one.
                return next((c for c in candidates if c in properties), candidates[0])

            arguments: dict[str, Any] = {
                named(("prompt", "instruction", "text", "description")): prompt if text is None else text
            }
            if not properties or "agent_id" in properties:
                arguments["agent_id"] = self.agent_id
            if model and (not properties or "model" in properties):
                arguments["model"] = model
            if tool == "image_edit":
                arguments[named(("image_uri", "image_url", "input_image_uri", "input_image", "image"))] = input_uri

            async def call() -> dict[str, Any]:
                await ModelRouter._inject_fault(model)
                return await self.arena.call(tool, arguments, timeout=IMAGE_CALL_TIMEOUT_S)

            budget = max(5.0, min(IMAGE_CALL_TIMEOUT_S, deadline - time.time() - SUBMIT_MARGIN_S))
            result = await asyncio.wait_for(call(), timeout=budget)
            uri = str(
                result.get("image_uri") or result.get("image_url") or result.get("output_image_uri")
                or result.get("image") or result.get("url")
                # A server may hand the picture back as an image block, not as a field.
                or next((u for u in (result.get("images") if isinstance(result.get("images"), list) else []) if isinstance(u, str) and u.startswith("data:image/")), "")
            ).strip()
            if not uri or result.get("error"):
                raise ValueError(f"no image returned: {str(result.get('error'))[:160]}")
            return uri, model

        # An edit can start on the brief as it stands while the planner reads it: for a remake that
        # is the prompt the plan ends with anyway, so the planner's seconds are not waited for.
        # Not when exploring turned something up: then the planner's prompt carries those facts.
        brief_prompt = prompt
        early = knob("SKYNET_SPECULATE", self.strategy.image_early_start).strip()
        head_start: asyncio.Task | None = None
        if early != "off" and tool == "image_edit" and rewriters and not findings:
            head_start = asyncio.create_task(
                self.first_image(models_for("local") or [""], lambda m: produce(m, brief_prompt), deadline)
            )
        rewritten = await write_prompt()
        plan = self.strategy.parse_image_plan(rewritten[0] if rewritten else "", ctx, task_text, notes)
        kind, prompt = plan["kind"], plan["prompt"]
        self.mark(
            f"image plan: {kind}" + (f", report on: {plan['report'][:80]}" if plan["report"] else "")
            + (f" (planned by {rewritten[1]})" if rewritten else " (no planner available; from the wording)")
        )
        self.record["image_kind"] = kind
        self.image_state.update(kind=kind, prompt=prompt, rewriter=rewritten[1] if rewritten else "template")
        self.think(f"Plan: {kind} image task" + (f"; will also report: {plan['report'][:120]}" if plan["report"] else "") + ".", "plan")

        # A brief that asks for information gets it from the vision tool, alongside the image work.
        report = ""
        analysis = None
        needs_answer = "{ANSWER}" in prompt
        if found_brief:
            report = found_brief  # already established with the server's tools
        elif plan["report"] and input_uri and "image_analyze" in tools:
            analysis = asyncio.create_task(quietly(self.analyze_image(
                input_uri, self.strategy.build_analysis_question(plan["report"], notes), deadline
            )))
        if kind == "question" or needs_answer:
            # The answer has to be on the submitted image (a text-only reply is not an image
            # submission), so it is needed before the edit prompt can be finished.
            report = report or (await analysis if analysis else "") or ""
            analysis = None
            if report and needs_answer:
                prompt = prompt.replace("{ANSWER}", self.strategy.short_answer(report))
                self.think(f"Answer: {report[:240]}", "report")
            elif needs_answer:
                prompt = self.strategy.build_image_fallback_prompt(ctx, task_text, notes, "question")
            elif report:
                prompt = self.strategy.build_caption_prompt(report)
                self.think(f"Answer: {report[:240]}", "report")
            self.mark(f"answer from image analysis: {report[:120] or 'none; the image model will answer on the image'}")

        image_models = models_for(kind)
        self.record["required_tools"] = required
        spare: asyncio.Task | None = None  # an image already under way, used only if the preferred model fails
        if head_start is not None:
            # Kept when the plan ends with the same prompt (a remake), or, in "all" mode, for any plain
            # local change; an image that must carry an answer is made afresh.
            keep = prompt == brief_prompt or (early == "all" and kind == "local" and not needs_answer)
            if keep and kind == "transform" and image_models and image_models[0] != (models_for("local") or [""])[0]:
                # A remake has its own first-choice model. The early image came from the edit model, so
                # it becomes the spare: used if the first choice fails or runs past its usual time.
                prompt = brief_prompt
                spare, head_start = head_start, None
                self.mark(f"remake goes to {image_models[0]}; the image started early is the spare")
            elif keep:
                prompt = brief_prompt
                self.mark("image started ahead of the plan is kept")
            else:
                head_start.cancel()
                head_start = None

        async def localize(uri: str) -> tuple[str, dict | None]:
            """For an edit, copy the untouched regions back from the input so only the requested change differs."""
            # Pasted back only for a local change whose brief says the rest must stay as it is; a remake
            # is left as the model made it.
            keeps_rest = bool(re.search(
                r"unchanged|preserv|intact|untouched|as it is|as is\b|keep(?:ing)? (?:the |everything|all )|rest of the|only (?:the|change)",
                f"{task_text} {notes}", re.IGNORECASE))
            if not uri or tool != "image_edit" or kind not in ("local", "question") or not keeps_rest or knob("SKYNET_COMPOSITE", "on") == "off":
                return uri, None
            try:
                localized = await in_thread(image_ops.localize_edit_uri, input_uri, uri, timeout=12.0)
            except Exception as exc:  # noqa: BLE001
                log(f"edit localization skipped: {type(exc).__name__}: {str(exc)[:120]}")
                return uri, None
            return localized if localized else (uri, None)

        output_uri, used_model = "", ""

        retry_until = started + OUTAGE_RETRY_UNTIL * max_time
        self.think(f"Rendering with {(image_models or ['the default model'])[0]}.", "render")
        async with self.waiting("the image model"):
            while not output_uri:
                if head_start is not None:
                    output_uri, used_model = await head_start
                    head_start = None
                    if output_uri:
                        break
                if spare is not None:
                    try:
                        output_uri, used_model = await asyncio.wait_for(
                            self.first_image(image_models[:1], produce, deadline),
                            timeout=self.strategy.image_hedge_s(image_models[0]),
                        )
                    except asyncio.TimeoutError:
                        output_uri, used_model = "", ""
                    if not output_uri:
                        self.mark(f"{image_models[0]} gave no image in time; using the image started early")
                        output_uri, used_model = await spare
                    elif not spare.done():
                        spare.cancel()
                    spare = None
                    if output_uri:
                        break
                output_uri, used_model = await self.first_image(image_models or [""], produce, deadline)
                if output_uri or time.time() + OUTAGE_RETRY_WAIT_S > retry_until:
                    break
                # Every image model failed. That is often a short proxy cooldown: wait it out and try again.
                self.mark(f"no image model produced an image; retrying in {OUTAGE_RETRY_WAIT_S:.0f}s")
                await asyncio.sleep(OUTAGE_RETRY_WAIT_S)
                if not rewritten:
                    # The prompt writers were probably down too; give them another chance.
                    self.router.down.clear()
                    rewritten = await write_prompt()
                    if rewritten and kind != "question":
                        prompt = self.strategy.parse_image_plan(rewritten[0], ctx, task_text, notes)["prompt"]
                        self.mark(f"prompt rewritten by {rewritten[1]} on retry")
        self.mark(f"image from {used_model or 'none'} via {tool}")
        if output_uri:
            self.best_image = output_uri
            self.image_state.update(model=used_model, tool=tool, prompt=prompt)
            self.think(f"Image produced by {used_model or 'the default model'} with {tool}; checking and submitting.", "image")
        if output_uri:
            output_uri, info = await localize(output_uri)
            self.record["localized"] = info
            if info:
                self.mark(f"edit localized onto the original ({info['changed_fraction']:.0%} of the frame changed)")
        if not output_uri:
            # Last resorts: for an edit the untouched input still scores on preservation;
            # for a generation a blank image is at least a scored submission.
            output_uri = input_uri or BLANK_PNG_DATA_URI
            self.mark("no image could be produced; submitting the fallback image")
        # Experiment knob: submit a saved image instead, to measure how much the judge varies on one image.
        fixed = knob("SKYNET_SUBMIT_EDIT" if tool == "image_edit" else "SKYNET_SUBMIT_GENERATE").strip()
        if fixed:
            import base64

            mime = "image/png" if fixed.lower().endswith(".png") else "image/jpeg"
            output_uri = f"data:{mime};base64," + base64.b64encode(Path(fixed).read_bytes()).decode("ascii")
            self.mark(f"submitting the saved image {Path(fixed).name} instead")
        if analysis is not None:
            # The written part of an edit-and-report brief: wait for it, but not past the deadline.
            report = await quietly(asyncio.wait_for(analysis, timeout=max(1.0, min(20.0, deadline - time.time() - 8.0)))) or ""
            if report:
                self.think(f"Report: {report[:240]}", "report")
        self.record["report"] = report
        self.image_state.update(report=report, model=used_model, tool=tool, prompt=prompt)
        await quietly(asyncio.wait([thought], timeout=3.0))
        for name in required:
            if name not in self.must_call:
                self.must_call.append(name)
        # Any required tool the flow has not used yet (a skipped one zeroes quality).
        await self.ensure_required(f"{task_text} {notes}", input_uri or output_uri)

        self.best_image = output_uri
        await self.submit_image(output_uri)

    async def submit_image(self, output_uri: str) -> None:
        """Submit an image for the heat in progress (also used by the watchdog and the crash path)."""
        state = self.image_state or {}
        self.submitted = True  # from here on nothing else may submit
        challenge, started = state["challenge"], state["started"]
        task_text, notes, input_uri = state["task_text"], state["notes"], state["input_uri"]
        tool, used_model = state["tool"], state["model"]
        ctx = ChallengeContext(challenge_type=challenge.challenge_type or "image", image_url=input_uri or None)
        rationale = self.strategy.build_image_rationale(ctx, task_text, notes, state["kind"], state["report"])
        if len(output_uri) > image_ops.MAX_DATA_URI_CHARS:
            fitted = await quietly(in_thread(image_ops.fit_data_uri, output_uri, timeout=10.0)) or output_uri
            if fitted != output_uri:
                self.mark(f"image re-encoded to fit the submit: {len(output_uri) // 1024} KB -> {len(fitted) // 1024} KB")
                output_uri = fitted
        await self.flush_thoughts(min(2.0, max(0.2, (self.deadline or time.time()) - time.time() - WATCHDOG_MARGIN_S)))
        metrics = {
            "model_name": used_model or "none",
            "planner_tool": tool,
            "total_tokens": str(self.router.usage["total_tokens"]) if self.router else "0",
            "total_time_ms": int((time.time() - started) * 1000),
        }
        result: dict[str, Any] = {}
        submit_args = {
            "edited_image": output_uri, "client_metrics": metrics, "rationale": rationale, "agent_id": self.agent_id,
        }
        try:
            result = await hedged_call(
                self.arena, lambda: Arena(self.arena.mcp_url, self.agent_id),
                "arena.image.submit_edit", submit_args, SUBMIT_HEDGE_S, 45.0,
            )
            if "arena.image.submit_edit" not in self.arena.tools_called:
                self.arena.tools_called.append("arena.image.submit_edit")
        except Exception as exc:  # noqa: BLE001
            log(f"MCP image submit failed ({type(exc).__name__}); submitting over REST")
            rest = await quietly(in_thread(self.http.submit, self.agent_id, output_uri, metrics, "image", timeout=60.0))
            result = {"accepted": getattr(rest, "accepted", None), "score": getattr(rest, "score", None)}
        score = result.get("score") if isinstance(result.get("score"), dict) else {}
        score = {k: v for k, v in score.items() if k != "output_image_uri"}
        self.mark(f"submitted accepted={result.get('accepted')} error={result.get('error')} {score_line(score)}")
        self.record.update(
            challenge={
                "puzzle_id": challenge.puzzle_id, "challenge_type": challenge.challenge_type, "prompt": task_text,
                "reference_notes": notes, "max_time_s": state["max_time"], "input_image_uri": input_uri,
            },
            image_prompt=state["prompt"], model=used_model, tool=tool, rationale=rationale,
            rewriter=state["rewriter"],
            accepted=result.get("accepted"), score=score, local_elapsed_s=round(time.time() - started, 2),
        )
        self.save_image(output_uri)

    async def ensure_required(self, question: str, image_uri: str = "") -> list[str]:
        """Call every must-call tool that has not been called yet; returns those still missing.

        This is the last step before any submit, on every path. The normal
        flows will already have used these tools with proper arguments; what
        is left here is called with arguments built from the tool's own schema,
        because an uncalled required tool voids the answer outright.
        """
        deadline = self.deadline or (time.time() + 30.0)
        submit_tools = {TEXT_SUBMIT_TOOL, "arena.image.submit_edit"}
        missing = [t for t in self.must_call if t not in self.arena.tools_called and t not in submit_tools]
        pending = []  # sent together: one silent tool must not hold up the others, or the answer
        for name in missing:
            left = deadline - time.time() - WATCHDOG_MARGIN_S - 1.0
            if left < 1.5:
                break
            if name in (TEXT_THOUGHT_TOOL, "arena.image.broadcast_thought"):
                pending.append(quietly(asyncio.wait_for(self._send_thought("Checking the answer against every rule before submitting."), timeout=min(6.0, left))))
                continue
            schema = (self.arena.tool_defs.get(name) or {}).get("schema") or {}
            properties = schema.get("properties") or {}
            arguments = guess_tool_arguments(schema, question)
            for key in properties:
                if image_uri and re.search(r"image|img|picture|photo", key, re.IGNORECASE) and re.search(r"ur[il]|image$|input", key, re.IGNORECASE):
                    arguments[key] = image_uri
                if key == "question" and key not in arguments:
                    arguments[key] = "Briefly describe the subject and the scene."
            if name == "image_analyze" and "model" not in arguments:
                vision = self.strategy.rank_vision_models(self.models)
                if vision:
                    arguments["model"] = vision[0]  # the tool's default model fails on Practice
            if not properties or "agent_id" in properties:
                arguments["agent_id"] = self.agent_id
            unanswered = name in self.arena.tools_unanswered
            self.mark(
                f"required tool {name} " + ("was sent but never answered; one short retry" if unanswered else "had not been called; calling it before submitting")
            )
            # A tool that already stayed silent is sent once more and barely waited for (the server
            # has the call either way); the arena's own housekeeping tools answer at once or not at
            # all; a capability tool may need real time.
            patience = REQUIRED_RETRY_S if unanswered else (FLOW_WAIT_BEFORE_SUBMIT_S if name in FLOW_TOOLS else 12.0)
            pending.append(quietly(self.arena.call(name, arguments, timeout=max(0.5, min(patience, left)), retry=False)))
        if pending:
            await asyncio.gather(*pending)
        still = [t for t in self.must_call if t not in self.arena.tools_called and t not in submit_tools]
        self.record["must_call"] = list(self.must_call)
        self.record["missing_before_submit"] = still
        if self.must_call:
            self.mark(f"required tools: {len(self.must_call) - len(still)} of {len(self.must_call)} called" + (f"; missing {still}" if still else ""))
        return still

    async def submit_fallback(self, reason: str) -> None:
        """Submit the best thing in hand right now: the deadline is here, or the run has failed."""
        if self.submitted:
            return
        await quietly(asyncio.wait_for(self.ensure_required(""), timeout=4.0))
        if self.image_state is not None:
            image = self.best_image or self.image_state["input_uri"] or BLANK_PNG_DATA_URI
            self.mark(f"{reason}: submitting {'the image in hand' if self.best_image else 'the fallback image'}")
            await self.submit_image(image)
        elif self.text_started is not None:
            self.mark(f"{reason}: submitting the best answer so far")
            await self.submit_text(self.best_answer or FALLBACK_TEXT_ANSWER, reason, self.text_started)

    async def analyze_image(self, uri: str, question: str, deadline: float) -> str:
        """Ask the server's vision tool a question about an image; '' if it gives nothing usable.

        A vision model is always named: on Practice the tool's own default model
        rejects every request (HTTP 400), which would otherwise look like "no answer".
        """
        properties = ((self.arena.tool_defs.get("image_analyze") or {}).get("schema") or {}).get("properties") or {}
        models = self.strategy.rank_vision_models(self.models) if (not properties or "model" in properties) else []
        for model in [*models[:3], ""]:
            timeout = max(5.0, min(30.0, deadline - time.time() - 12.0))
            if deadline - time.time() < 15.0:
                break
            arguments = {"image_uri": uri, "question": question, "agent_id": self.agent_id}
            if model:
                arguments["model"] = model
            try:
                result = await self.arena.call("image_analyze", arguments, timeout=timeout, retry=False)
            except Exception as exc:  # noqa: BLE001
                log(f"image_analyze with {model or 'the default model'} failed: {type(exc).__name__}")
                continue
            if result.get("error"):
                log(f"image_analyze with {model or 'the default model'} refused: {str(result.get('error'))[:120]}")
                continue
            for key in ("text", "answer", "analysis", "description", "result", "response", "content", "output", "raw"):
                value = result.get(key)
                if isinstance(value, str) and value.strip():
                    return re.sub(r"\s+", " ", value).strip()
        return ""

    async def first_image(self, models: list[str], produce, deadline: float) -> tuple[str, str]:
        """Try image models in order; if one is slow, start the next alongside it. First image wins."""
        tasks: dict[asyncio.Task, str] = {}
        next_index = 0
        hedge_at = 0.0
        try:
            while time.time() < deadline - SUBMIT_MARGIN_S and (tasks or next_index < len(models)):
                if next_index < len(models) and (not tasks or time.time() >= hedge_at):
                    if tasks:
                        log(f"image model {list(tasks.values())} is slow; starting {models[next_index]} alongside")
                    tasks[asyncio.create_task(produce(models[next_index]))] = models[next_index]
                    next_index += 1
                    hedge_at = time.time() + self.strategy.image_hedge_s(models[next_index - 1])
                wait_until = deadline - SUBMIT_MARGIN_S
                if next_index < len(models):
                    wait_until = min(wait_until, hedge_at)
                done, _ = await asyncio.wait(
                    tasks, timeout=max(0.05, wait_until - time.time()), return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    model = tasks.pop(task)
                    try:
                        return task.result()
                    except Exception as exc:  # noqa: BLE001
                        log(f"image model {model} failed: {type(exc).__name__}: {str(exc)[:300]}")
                        self.record.setdefault("image_failures", []).append(
                            {"model": model, "at_s": round(time.time() - self.t0, 1), "error": f"{type(exc).__name__}: {str(exc)[:300]}"}
                        )
            return "", ""
        finally:
            for task in tasks:
                task.cancel()

    def save_image(self, uri: str, suffix: str = "") -> None:
        try:
            if uri.startswith("data:"):
                import base64

                header, _, payload = uri.partition(",")
                ext = "png" if "png" in header else "webp" if "webp" in header else "jpg"
                out_dir = REPO_ROOT / "outputs"
                out_dir.mkdir(exist_ok=True)
                (out_dir / f"{self.agent_id}-{time.strftime('%Y%m%d-%H%M%S')}{suffix}.{ext}").write_bytes(base64.b64decode(payload))
        except Exception as exc:  # noqa: BLE001
            log(f"could not save image: {exc}")


async def guarded(run: "Run", heat) -> None:
    """Run one heat under a watchdog: whatever the flow is doing, something is submitted before time runs out."""
    task = asyncio.create_task(heat())
    strays = 0
    while not task.done():
        try:
            await asyncio.wait([task], timeout=0.25)
        except asyncio.CancelledError:
            # Nothing here cancels this task. A cancellation arriving anyway comes from an abandoned
            # connection closing in the background; giving in to it would end the run unanswered.
            strays += 1
            current = asyncio.current_task()
            if strays > 20 or current is None or not hasattr(current, "uncancel"):
                raise
            current.uncancel()
            log("ignored a stray cancellation of the run")
            continue
        if task.done() or run.deadline is None or run.submitted:
            continue
        if time.time() >= run.deadline - WATCHDOG_MARGIN_S:
            log("watchdog: the time limit is here; stopping work and submitting")
            task.cancel()
            await quietly(asyncio.wait([task], timeout=1.0))
            await run.submit_fallback("deadline")
            return
    await task  # re-raises whatever the heat raised


async def main() -> int:
    run = Run()
    log(f"{run.agent_name} starting as {run.agent_id}")
    code = 0
    try:
        modality = await run.setup()
        run.record["modality"] = modality
        run.record["tag"] = os.environ.get("SKYNET_TAG", "")
        forced = knob("SKYNET_FORCE_MODALITY", "").strip()  # test hook: start with this guess
        only = knob("SKYNET_ONLY", "").strip()  # experiment knob: skip the other modality
        if only and only != modality:
            log(f"skipping {modality} run (SKYNET_ONLY={only})")
            run.record["skipped"] = True
        else:
            try:
                await guarded(run, run.run_image if (forced or modality) == "image" else run.run_text)
            except WrongModality as exc:
                log(f"server says this is a {exc.actual} challenge; switching")
                run.record["modality"] = exc.actual
                await guarded(run, run.run_image if exc.actual == "image" else run.run_text)
    except SystemExit as exc:
        run.record["error"] = f"exit: {exc}"
        log(f"exiting: {exc}")
        raise
    except (Exception, asyncio.CancelledError) as exc:  # noqa: BLE001 - a cancelled run still answers
        code = 1
        current = asyncio.current_task()
        if isinstance(exc, asyncio.CancelledError) and current is not None and hasattr(current, "uncancel"):
            current.uncancel()
        log(f"run failed: {type(exc).__name__}: {exc}")
        run.record["error"] = f"{type(exc).__name__}: {exc}"
        # A text run that crashed after the challenge opened still submits its
        # best candidate: a missing answer scores worse than an imperfect one.
        if not run.submitted and run.router is not None:
            await quietly(run.submit_fallback("crash-fallback"))
    finally:
        run.record.update(
            timeline=run.timeline,
            llm_attempts=run.router.attempts if run.router else [],
            llm_usage=run.router.usage if run.router else {},
            tools_called=run.arena.tools_called,
        )
        save_record(run.agent_id, run.record)
        await run.arena.close()
    return code


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
    except KeyboardInterrupt:
        exit_code = 130
    sys.stdout.flush()
    # Abandoned SSE contexts can keep the interpreter alive; the run is over.
    os._exit(exit_code)
