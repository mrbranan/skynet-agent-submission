"""Keep an image edit local: restore the original pixels wherever the edit did not change anything.

Image models re-render the whole frame, so even a good edit drifts slightly
everywhere (texture, colour, resolution). An edit judge scores preservation of
everything that was not asked to change, so the untouched regions are copied
back from the input image and only the changed region comes from the model.

Pillow is optional: without it, or on any failure, callers keep the model's
output unchanged.
"""

from __future__ import annotations

import base64
import io
import ipaddress
import socket
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

try:
    from PIL import Image, ImageChops, ImageFilter

    HAVE_PIL = True
except Exception:  # noqa: BLE001
    HAVE_PIL = False

# A mask covering more of the frame than this means the edit was global
# (restyle, relight) or the output is misaligned: do not composite.
MAX_CHANGED_FRACTION = 0.45
MIN_CHANGED_FRACTION = 0.002


# The address comes from the arena or from an image tool, so it is not trusted: only web links are
# fetched (never file: or ftp:), never the link-local range where cloud machines keep their
# credentials, and never more than an image could plausibly need.
MAX_IMAGE_BYTES = 25_000_000


_NAT64 = ipaddress.ip_network("64:ff9b::/96")
# Carrier-grade NAT space and the IPv6 address of the EC2 metadata service.
_REFUSED_NETWORKS = (ipaddress.ip_network("100.64.0.0/10"), ipaddress.ip_network("fd00:ec2::/64"))


def vet_image_address(uri: str) -> None:
    """Raise unless `uri` is a web link to a host an image could reasonably come from.

    Every address the host name resolves to is checked, in whatever notation it was written.
    Link-local (where cloud machines keep credentials), multicast, reserved and unspecified
    addresses are refused. Private and loopback addresses are allowed on purpose: the arena itself
    may be reached on one. The name is resolved again when the connection is made, so this narrows
    what a hostile address can reach; it is not a guarantee.
    """
    parts = urlsplit(uri)
    host = (parts.hostname or "").lower()
    if parts.scheme not in ("http", "https") or not host:
        raise ValueError("only data: and http(s) image addresses are loaded")
    for info in socket.getaddrinfo(host, parts.port or (443 if parts.scheme == "https" else 80), type=socket.SOCK_STREAM):
        address = ipaddress.ip_address(info[4][0].split("%")[0])
        # An IPv4 address carried inside an IPv6 one (mapped, 6to4, Teredo, NAT64) is judged as itself.
        inner = getattr(address, "ipv4_mapped", None) or getattr(address, "sixtofour", None)
        teredo = getattr(address, "teredo", None)
        if inner is None and teredo:
            inner = teredo[1]
        if inner is None and address.version == 6 and address in _NAT64:
            inner = ipaddress.ip_address(int(address) & 0xFFFFFFFF)
        for candidate in (address, inner):
            if candidate is None:
                continue
            if (candidate.is_link_local or candidate.is_multicast or candidate.is_reserved or candidate.is_unspecified
                    or any(candidate.version == net.version and candidate in net for net in _REFUSED_NETWORKS)):
                raise ValueError("this image address is not loaded")


class _VettedRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001, D102
        vet_image_address(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def load_image_bytes(uri: str, timeout: float = 8.0) -> bytes:
    if uri.startswith("data:"):
        return base64.b64decode(uri.partition(",")[2])
    vet_image_address(uri)
    request = Request(uri, headers={"User-Agent": "agent/1.0"})
    with build_opener(_VettedRedirects).open(request, timeout=timeout) as response:  # noqa: S310 - address vetted above
        data = response.read(MAX_IMAGE_BYTES + 1)
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError("image too large")
    return data


def change_mask(original, edited):
    """Soft mask (L mode): white where the edit differs from the original."""
    diff = ImageChops.difference(original, edited).convert("L")
    size = max(original.size)
    # Blur first so re-rendering noise averages out and only real changes remain.
    diff = diff.filter(ImageFilter.GaussianBlur(radius=max(2, size // 160)))
    mask = diff.point(lambda v: 255 if v > 26 else 0)
    # Drop specks, then grow the region so the edit's soft edges are included.
    mask = mask.filter(ImageFilter.MinFilter(3))
    mask = mask.filter(ImageFilter.MaxFilter(2 * max(2, size // 85) + 1))
    return mask


def changed_fraction(mask) -> float:
    histogram = mask.histogram()
    total = sum(histogram) or 1
    return sum(histogram[128:]) / total


def localize_edit(original_bytes: bytes, edited_bytes: bytes) -> tuple[bytes, dict] | None:
    """Return (png_bytes, info) with the edit composited onto the original, or None to keep the model output."""
    if not HAVE_PIL:
        return None
    original = Image.open(io.BytesIO(original_bytes)).convert("RGB")
    edited = Image.open(io.BytesIO(edited_bytes)).convert("RGB")
    ratio_in = original.width / original.height
    ratio_out = edited.width / edited.height
    if abs(ratio_in - ratio_out) > 0.03:
        return None  # the model changed the framing; nothing lines up
    if edited.size != original.size:
        edited = edited.resize(original.size, Image.LANCZOS)
    mask = change_mask(original, edited)
    fraction = changed_fraction(mask)
    info = {"changed_fraction": round(fraction, 4), "size": original.size}
    if not MIN_CHANGED_FRACTION <= fraction <= MAX_CHANGED_FRACTION:
        return None
    feather = mask.filter(ImageFilter.GaussianBlur(radius=max(2, max(original.size) // 170)))
    result = Image.composite(edited, original, feather)
    buffer = io.BytesIO()
    result.save(buffer, format="PNG", optimize=False)
    return buffer.getvalue(), info


def localize_edit_uri(input_uri: str, edited_uri: str) -> tuple[str, dict] | None:
    """Data-URI wrapper around `localize_edit`."""
    if not HAVE_PIL or not edited_uri.startswith("data:"):
        return None
    outcome = localize_edit(load_image_bytes(input_uri), load_image_bytes(edited_uri))
    if outcome is None:
        return None
    png, info = outcome
    return "data:image/png;base64," + base64.b64encode(png).decode("ascii"), info


# The Practice server refuses a request body of about 4 MB (HTTP 413), and the MCP client then
# waits out its whole timeout: an image sent as a 3.3 MB PNG (4.4 MB once base64-encoded) cost a
# lab heat 106 s and its image. A 2.5 MB PNG (3.3 MB encoded) went through. Anything longer than
# this many characters is re-encoded before it is sent.
MAX_DATA_URI_CHARS = 2_800_000


def fit_data_uri(uri: str, limit: int = MAX_DATA_URI_CHARS) -> str:
    """The same image as a data URI no longer than `limit` characters.

    Short enough already, not a data URI, or no Pillow: returned as it is. Otherwise re-encoded as
    JPEG, first at high quality and full size, then smaller, until it fits.
    """
    if not HAVE_PIL or not uri.startswith("data:") or len(uri) <= limit:
        return uri
    try:
        image = Image.open(io.BytesIO(load_image_bytes(uri))).convert("RGB")
        fitted = uri
        for quality, scale in ((92, 1.0), (88, 1.0), (88, 0.8), (85, 0.65), (82, 0.5), (80, 0.35)):
            frame = image if scale == 1.0 else image.resize(
                (max(1, int(image.width * scale)), max(1, int(image.height * scale))), Image.LANCZOS)
            buffer = io.BytesIO()
            frame.save(buffer, "JPEG", quality=quality, optimize=True)
            fitted = "data:image/jpeg;base64," + base64.b64encode(buffer.getvalue()).decode("ascii")
            if len(fitted) <= limit:
                break
        return fitted
    except Exception:  # noqa: BLE001 - never lose the image over this
        return uri
