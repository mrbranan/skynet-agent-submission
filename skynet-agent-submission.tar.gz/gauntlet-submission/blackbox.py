"""Decoding helpers for an unfamiliar arena: spot encoded text and decode it with real code.

Two entry points:

* `find_encoded(text)` scans challenge text or a tool result for pieces that
  look encoded (base64, hex, binary, Morse, ROT/Caesar, reversed, ...) and
  returns what they decode to. It only reports a decoding that turns the
  piece into readable text, so plain prose passes through with no findings.
* `decode(method, data, key)` is the explicit tool a model can call when it
  knows (or wants to try) a method, including keyed ones: XOR, Vigenere, AES,
  Fernet. `method="auto"` tries every keyless method and, when a key is given,
  every keyed one.

No network, no model calls, standard library plus `cryptography` if installed.
"""

from __future__ import annotations

import ast
import base64
import binascii
import codecs
import hashlib
import json
import math
import operator
import re
import urllib.parse
import zlib
from typing import Callable

_COMMON = set(
    "the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an "
    "will my one all would there their what so up out if about who get which go me when make can like time no just him "
    "know take into your some could them see other than then now look only come its over also back after use two how our "
    "first is are was were answer key code secret password flag clue next step tool call use hidden find order before "
    "after left right team event image text final submit challenge unlock decode value result data message read open "
    "must each every never always between immediately not last second third fourth fifth happened stands presents".split()
)

_MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G", "....": "H", "..": "I",
    ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R",
    "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z",
    "-----": "0", ".----": "1", "..---": "2", "...--": "3", "....-": "4", ".....": "5", "-....": "6", "--...": "7",
    "---..": "8", "----.": "9", ".-.-.-": ".", "--..--": ",", "..--..": "?", "-....-": "-", "-..-.": "/", "---...": ":",
}


def readable(text: str) -> float:
    """0..1: how much `text` looks like ordinary readable text (English words, ids, numbers, JSON)."""
    if not text or len(text) < 2:
        return 0.0
    printable = sum(1 for ch in text if ch == "\n" or ch == "\t" or 32 <= ord(ch) < 127) / len(text)
    if printable < 0.97:
        return 0.0
    words = re.findall(r"[A-Za-z]+", text)
    if not words:
        return 0.3 if re.fullmatch(r"[\d\s.,:;/+\-]+", text) else 0.0
    hits = sum(1 for w in words if w.lower() in _COMMON)
    letters = sum(len(w) for w in words)
    vowels = sum(1 for w in words for ch in w.lower() if ch in "aeiou")
    vowel_ratio = vowels / max(letters, 1)
    score = hits / len(words)
    if hits and 0.25 <= vowel_ratio <= 0.55:
        score += 0.25
    if hits and (" " in text.strip() or len(words) == 1):
        score += 0.1
    return min(score, 1.0)


def printable(text: str) -> bool:
    """Decoded bytes that came out as clean text: strong evidence the piece really was encoded."""
    text = text.strip()
    return len(text) >= 3 and all(ch in "\n\t" or 32 <= ord(ch) < 127 for ch in text) and bool(re.search(r"[A-Za-z0-9]{2}", text))


def _sentence(text: str) -> bool:
    """Stricter than `readable`: several real words, as a letter cipher of prose decodes to."""
    words = re.findall(r"[A-Za-z]+", text)
    hits = sum(1 for w in words if w.lower() in _COMMON)
    return len(words) >= 3 and hits >= 2 and hits / len(words) >= 0.4


def _text(raw: bytes) -> str | None:
    for inflate in (None, zlib.decompress, lambda b: zlib.decompress(b, 31)):
        try:
            data = inflate(raw) if inflate else raw
            return data.decode("utf-8")
        except Exception:  # noqa: BLE001
            continue
    return None


def _pad(data: str) -> str:
    return data + "=" * (-len(data) % 4)


def _b64(data: str) -> str | None:
    compact = re.sub(r"\s+", "", data)
    if len(compact) < 8 or not re.fullmatch(r"[A-Za-z0-9+/_\-]+=*", compact):
        return None
    try:
        return _text(base64.b64decode(_pad(compact.replace("-", "+").replace("_", "/")), validate=True))
    except (binascii.Error, ValueError):
        return None


def _b32(data: str) -> str | None:
    compact = re.sub(r"\s+", "", data).upper()
    if len(compact) < 8 or not re.fullmatch(r"[A-Z2-7]+=*", compact):
        return None
    try:
        return _text(base64.b32decode(compact + "=" * (-len(compact) % 8)))
    except (binascii.Error, ValueError):
        return None


def _b85(data: str) -> str | None:
    for fn in (base64.b85decode, base64.a85decode):
        try:
            out = _text(fn(data.strip()))
            if out:
                return out
        except Exception:  # noqa: BLE001
            continue
    return None


def _hex(data: str) -> str | None:
    compact = re.sub(r"(0x|\\x|[\s:,\-])", "", data)
    if len(compact) < 8 or len(compact) % 2 or not re.fullmatch(r"[0-9a-fA-F]+", compact):
        return None
    return _text(bytes.fromhex(compact))


def _binary(data: str) -> str | None:
    compact = re.sub(r"\s+", "", data)
    if len(compact) < 16 or len(compact) % 8 or not re.fullmatch(r"[01]+", compact):
        return None
    return _text(bytes(int(compact[i:i + 8], 2) for i in range(0, len(compact), 8)))


def _decimal(data: str) -> str | None:
    parts = re.split(r"[\s,]+", data.strip())
    if len(parts) < 6 or not all(p.isdigit() and int(p) < 256 for p in parts):
        return None
    # Ordinary figures (prices, scores, counts) also fall in the byte range: only accept
    # a run that spells out real words.
    out = _text(bytes(int(p) for p in parts))
    return out if out and _sentence(out) else None


def _morse(data: str) -> str | None:
    if not re.fullmatch(r"[.\-_/| \n]+", data) or len(data) < 5:
        return None
    words = re.split(r"\s*[/|]\s*|\s{2,}", data.replace("_", "-").strip())
    out = []
    for word in words:
        letters = [_MORSE.get(sym) for sym in word.split()]
        if not letters or any(letter is None for letter in letters):
            return None
        out.append("".join(letters))
    return " ".join(out)


def _url(data: str) -> str | None:
    if not re.search(r"%[0-9A-Fa-f]{2}", data):
        return None
    return urllib.parse.unquote_plus(data)


def rot(data: str, shift: int) -> str:
    out = []
    for ch in data:
        if "a" <= ch <= "z":
            out.append(chr((ord(ch) - 97 + shift) % 26 + 97))
        elif "A" <= ch <= "Z":
            out.append(chr((ord(ch) - 65 + shift) % 26 + 65))
        else:
            out.append(ch)
    return "".join(out)


def atbash(data: str) -> str:
    return "".join(
        chr(219 - ord(ch)) if "a" <= ch <= "z" else chr(155 - ord(ch)) if "A" <= ch <= "Z" else ch for ch in data
    )


def _best_rot(data: str) -> tuple[int, str, float]:
    best = (0, data, readable(data))
    for shift in range(1, 26):
        candidate = rot(data, shift)
        score = readable(candidate)
        if score > best[2]:
            best = (shift, candidate, score)
    return best


def vigenere(data: str, key: str, decrypt: bool = True) -> str:
    shifts = [ord(ch.lower()) - 97 for ch in key if ch.isalpha()]
    if not shifts:
        return data
    out, index = [], 0
    for ch in data:
        if ch.isalpha():
            shift = shifts[index % len(shifts)] * (-1 if decrypt else 1)
            out.append(rot(ch, shift % 26))
            index += 1
        else:
            out.append(ch)
    return "".join(out)


def _bytes_from(data: str) -> list[bytes]:
    """Every plausible byte reading of a string: hex, base64, then raw text."""
    readings: list[bytes] = []
    compact = re.sub(r"\s+", "", data)
    if re.fullmatch(r"(?:[0-9a-fA-F]{2})+", compact):
        readings.append(bytes.fromhex(compact))
    if re.fullmatch(r"[A-Za-z0-9+/_\-]+=*", compact) and len(compact) >= 4:
        try:
            readings.append(base64.b64decode(_pad(compact.replace("-", "+").replace("_", "/")), validate=True))
        except (binascii.Error, ValueError):
            pass
    readings.append(data.encode("utf-8"))
    return readings


def xor(data: str, key: str) -> str | None:
    best: tuple[float, str] | None = None
    for cipher in _bytes_from(data)[:2] or _bytes_from(data):
        for key_bytes in _bytes_from(key):
            if not key_bytes:
                continue
            plain = _text(bytes(b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(cipher)))
            if plain is not None and (best is None or readable(plain) > best[0]):
                best = (readable(plain), plain)
    return best[1] if best else None


def _xor_single_byte(data: str) -> tuple[str, str] | None:
    """Brute-force a one-byte XOR key over hex or base64 data."""
    best: tuple[float, str, int] | None = None
    for cipher in _bytes_from(data)[:-1]:
        for key in range(1, 256):
            plain = _text(bytes(b ^ key for b in cipher))
            if plain is not None:
                score = readable(plain)
                if best is None or score > best[0]:
                    best = (score, plain, key)
    if best and best[0] >= 0.6:
        return f"xor key 0x{best[2]:02x}", best[1]
    return None


def _key_candidates(key: str, size: int | None = None) -> list[bytes]:
    out = [k for k in _bytes_from(key) if size is None or len(k) == size]
    raw = key.encode("utf-8")
    out.append(hashlib.sha256(raw).digest())
    out.append(hashlib.md5(raw).digest())  # noqa: S324 - trying a common key derivation, not securing anything
    for width in (16, 24, 32):
        out.append(raw.ljust(width, b"\0")[:width])
    return [k for k in out if len(k) in (16, 24, 32)]


def aes(data: str, key: str, iv: str = "") -> str | None:
    try:
        from cryptography.hazmat.primitives import padding
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except Exception:  # noqa: BLE001
        return None
    ciphers = [c for c in _bytes_from(data)[:-1] if len(c) >= 16] or []
    ivs = [v for v in _bytes_from(iv) if len(v) in (12, 16)] if iv else []
    for cipher in ciphers:
        for key_bytes in _key_candidates(key):
            attempts: list[Callable[[], bytes]] = []
            for nonce in ivs + [cipher[:12]]:
                body = cipher if nonce in ivs else cipher[12:]
                attempts.append(lambda n=nonce, b=body: AESGCM(key_bytes).decrypt(n, b, None))
            if len(cipher) % 16 == 0:
                for vector in [v for v in ivs if len(v) == 16] + [cipher[:16], b"\0" * 16]:
                    body = cipher[16:] if vector == cipher[:16] and vector not in ivs else cipher
                    if body:
                        attempts.append(
                            lambda v=vector, b=body: (lambda d: d.update(b) + d.finalize())(
                                Cipher(algorithms.AES(key_bytes), modes.CBC(v)).decryptor()
                            )
                        )
                attempts.append(
                    lambda: (lambda d: d.update(cipher) + d.finalize())(Cipher(algorithms.AES(key_bytes), modes.ECB()).decryptor())  # noqa: S305
                )
            for attempt in attempts:
                try:
                    plain = attempt()
                except Exception:  # noqa: BLE001
                    continue
                for unpad in (True, False):
                    candidate = plain
                    if unpad:
                        try:
                            unpadder = padding.PKCS7(128).unpadder()
                            candidate = unpadder.update(plain) + unpadder.finalize()
                        except Exception:  # noqa: BLE001
                            continue
                    text = _text(candidate)
                    if text and readable(text.strip("\0")) >= 0.3:
                        return text.strip("\0")
    return None


def fernet(data: str, key: str) -> str | None:
    try:
        from cryptography.fernet import Fernet
    except Exception:  # noqa: BLE001
        return None
    keys = [key.strip().encode()]
    keys.append(base64.urlsafe_b64encode(hashlib.sha256(key.encode()).digest()))
    for candidate in keys:
        try:
            return Fernet(candidate).decrypt(data.strip().encode()).decode("utf-8")
        except Exception:  # noqa: BLE001
            continue
    return None


_KEYLESS: dict[str, Callable[[str], str | None]] = {
    "base64": _b64, "hex": _hex, "binary": _binary, "base32": _b32, "morse": _morse, "url": _url,
    "decimal": _decimal, "base85": _b85,
    "rot13": lambda d: codecs.decode(d, "rot_13"), "atbash": atbash, "reverse": lambda d: d[::-1],
}
METHODS = sorted([*_KEYLESS, "caesar", "xor", "vigenere", "aes", "fernet", "auto", "sha256", "md5", "sha1"])


def decode(method: str, data: str, key: str = "", iv: str = "") -> str:
    """Decode `data` with `method`; returns the result or a short explanation of why it failed."""
    method = (method or "auto").strip().lower().replace("-", "").replace("_", "")
    data = str(data)
    if not data.strip():
        return "error: no data given"
    if method in {"sha256", "md5", "sha1"}:
        return hashlib.new(method, data.encode("utf-8")).hexdigest()
    rot_match = re.fullmatch(r"(?:rot|caesar)(\d+)", method)
    if rot_match:
        return rot(data, -int(rot_match.group(1)) % 26) if method.startswith("caesar") else rot(data, int(rot_match.group(1)))
    if method == "caesar":
        if key.strip().lstrip("-").isdigit():
            return rot(data, -int(key) % 26)
        shift, text, score = _best_rot(data)
        return f"(shift {26 - shift if shift else 0}) {text}" if score >= 0.4 else "error: no shift gives readable text"
    if method == "xor":
        if key:
            return xor(data, key) or "error: XOR with that key does not give text"
        found = _xor_single_byte(data)
        return f"({found[0]}) {found[1]}" if found else "error: give a key (single-byte keys were tried)"
    if method == "vigenere":
        return vigenere(data, key) if key else "error: Vigenere needs a key"
    if method == "aes":
        return aes(data, key, iv) or "error: AES decryption failed with that key (tried GCM, CBC, ECB; key as hex/base64/text/SHA-256)"
    if method == "fernet":
        return fernet(data, key) or "error: Fernet decryption failed with that key"
    if method in _KEYLESS:
        out = _KEYLESS[method](data)
        return out if out is not None else f"error: the data is not valid {method}"
    # auto: every keyless reading, then keyed ones if a key was supplied.
    lines = [f"{name}: {text}" for name, text in _decodings(data, depth=2)]
    if key:
        for name, fn in (("xor", lambda: xor(data, key)), ("vigenere", lambda: vigenere(data, key)),
                         ("aes", lambda: aes(data, key, iv)), ("fernet", lambda: fernet(data, key))):
            out = fn()
            if out and readable(out) >= 0.4:
                lines.append(f"{name}: {out}")
    return "\n".join(lines) if lines else "error: no method produced readable text; a key may be needed"


def _decodings(piece: str, depth: int = 2) -> list[tuple[str, str]]:
    """Readable decodings of one piece, following up to `depth` nested layers (e.g. base64 of hex)."""
    found: list[tuple[str, str]] = []
    base = readable(piece)
    for name in ("base64", "hex", "binary", "base32", "morse", "url", "decimal"):
        out = _KEYLESS[name](piece)
        if not out or out == piece:
            continue
        out = out.strip()
        if not printable(out):
            continue
        inner = _decodings(out, depth - 1) if depth > 1 and readable(out) < 0.4 else []
        if inner:
            found.extend((f"{name} then {method}", text) for method, text in inner)
        else:
            found.append((name, out))
    if not found and base < 0.35 and re.search(r"[A-Za-z]{4}", piece):
        shift, text, score = _best_rot(piece)
        if shift and _sentence(text) and score - base >= 0.3:
            found.append(("rot13" if shift == 13 else f"caesar shift {26 - shift}", text))
        for name in ("atbash", "reverse"):
            out = _KEYLESS[name](piece) or ""
            if _sentence(out) and readable(out) - base >= 0.3:
                found.append((name, out))
    if not found and depth > 1:
        single = _xor_single_byte(piece) if re.fullmatch(r"\s*(?:[0-9a-fA-F]{2}\s*){8,}", piece) else None
        if single:
            found.append(single)
    return found


_PIECES = re.compile(
    r"(?:[01]{8}[ ]?){3,}"                                   # binary
    r"|(?:(?:0x)?[0-9a-fA-F]{2}[ :]?){8,}"                   # hex
    r"|[A-Za-z0-9+/_\-]{16,}={0,2}"                          # base64 / base32
    r"|(?:[.\-]{1,6}[ /|]+){4,}[.\-]{1,6}"                   # Morse
    r"|(?:\d{2,3}[ ,]+){4,}\d{2,3}"                          # decimal bytes
    r"|(?:%[0-9A-Fa-f]{2}|[\w.\-+]){0,40}(?:%[0-9A-Fa-f]{2}[\w.\-+]*){2,}"  # URL-encoded
)


def find_encoded(text: str, limit: int = 6) -> list[tuple[str, str, str]]:
    """(piece, method, decoded) for each part of `text` that decodes to something readable."""
    findings: list[tuple[str, str, str]] = []
    seen: set[str] = set()

    def consider(piece: str) -> None:
        piece = piece.strip().strip("\"'`")
        if len(piece) < 8 or piece in seen or len(findings) >= limit:
            return
        seen.add(piece)
        for method, decoded in _decodings(piece)[:2]:
            findings.append((piece, method, decoded))

    text = str(text or "")
    for match in _PIECES.finditer(text):
        consider(match.group(0))
    # Whole lines and quoted strings catch letter ciphers (ROT13, Atbash, reversed text).
    quoted = re.findall(r"\"([^\"\n]{8,400})\"", text) + re.findall(r"(?<!\w)'([^'\n]{8,400})'(?!\w)", text)
    for piece in quoted + ([] if quoted else re.findall(r"^(.{8,400})$", text, flags=re.MULTILINE)):
        if readable(piece) < 0.35 and re.search(r"[A-Za-z]{4}", piece):
            consider(piece)
    for match in re.finditer(r":\s*([A-Za-z][A-Za-z ,.'!?\-]{11,300})", text):  # "ciphertext: Gur nafjre vf ..."
        if readable(match.group(1)) < 0.35:
            consider(match.group(1))
    return findings


def annotate(text: str) -> str:
    """Notes on what the encoded parts of `text` say, or '' when nothing in it is encoded."""
    notes = [f"- {piece[:60]}{'...' if len(piece) > 60 else ''} decodes ({method}) to: {decoded[:600]}"
             for piece, method, decoded in find_encoded(text)]
    return "\n".join(notes)


# ------------------------------------------------------------------ calculator

_BINARY = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow,
}
_COMPARE = {
    ast.Eq: operator.eq, ast.NotEq: operator.ne, ast.Lt: operator.lt, ast.LtE: operator.le,
    ast.Gt: operator.gt, ast.GtE: operator.ge, ast.In: lambda a, b: a in b, ast.NotIn: lambda a, b: a not in b,
}
_FUNCTIONS = {
    "round": round, "abs": abs, "min": min, "max": max, "sum": sum, "len": len, "sorted": sorted, "int": int,
    "float": float, "str": str, "bool": bool, "list": list, "tuple": tuple, "dict": dict, "set": set, "range": range,
    "enumerate": enumerate, "zip": zip, "any": any, "all": all, "reversed": reversed, "divmod": divmod, "pow": pow,
    "sqrt": math.sqrt, "floor": math.floor, "ceil": math.ceil, "log": math.log, "log2": math.log2,
    "log10": math.log10, "exp": math.exp, "gcd": math.gcd, "factorial": math.factorial, "comb": math.comb,
}
_METHODS = {"upper", "lower", "title", "strip", "split", "join", "replace", "startswith", "endswith", "format",
            "items", "keys", "values", "get", "index", "count", "zfill", "capitalize", "isdigit"}
_CONSTANTS = {"pi": math.pi, "e": math.e, "True": True, "False": False, "None": None}


class _Calc:
    """Evaluate one Python expression made only of data, arithmetic and a few pure functions."""

    def __init__(self) -> None:
        self.steps = 0

    def run(self, node: ast.AST, scope: dict):  # noqa: C901 - a flat dispatch reads best
        self.steps += 1
        if self.steps > 200_000:
            raise ValueError("too much work for one expression")
        if isinstance(node, ast.Expression):
            return self.run(node.body, scope)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            if node.id in scope:
                return scope[node.id]
            if node.id in _CONSTANTS:
                return _CONSTANTS[node.id]
            if node.id in _FUNCTIONS:
                return _FUNCTIONS[node.id]
            raise ValueError(f"unknown name {node.id!r}; put every value in the expression itself")
        if isinstance(node, ast.BinOp) and type(node.op) in _BINARY:
            left, right = self.run(node.left, scope), self.run(node.right, scope)
            if isinstance(node.op, ast.Pow) and isinstance(right, (int, float)) and abs(right) > 1000:
                raise ValueError("exponent too large")
            if isinstance(node.op, ast.Mult) and isinstance(left, (str, list, tuple)) != isinstance(right, (str, list, tuple)):
                if max((v for v in (left, right) if isinstance(v, int)), default=0) > 10_000:
                    raise ValueError("repeat count too large")
            return _BINARY[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp):
            value = self.run(node.operand, scope)
            return -value if isinstance(node.op, ast.USub) else +value if isinstance(node.op, ast.UAdd) else not value
        if isinstance(node, ast.BoolOp):
            values = [self.run(v, scope) for v in node.values]
            return all(values) if isinstance(node.op, ast.And) else any(values)
        if isinstance(node, ast.Compare):
            left = self.run(node.left, scope)
            for op, comparator in zip(node.ops, node.comparators):
                right = self.run(comparator, scope)
                if type(op) not in _COMPARE or not _COMPARE[type(op)](left, right):
                    return False
                left = right
            return True
        if isinstance(node, ast.IfExp):
            return self.run(node.body if self.run(node.test, scope) else node.orelse, scope)
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            items = [self.run(e, scope) for e in node.elts]
            return items if isinstance(node, ast.List) else tuple(items) if isinstance(node, ast.Tuple) else set(items)
        if isinstance(node, ast.Dict):
            return {self.run(k, scope): self.run(v, scope) for k, v in zip(node.keys, node.values)}
        if isinstance(node, ast.Subscript):
            target = self.run(node.value, scope)
            if isinstance(node.slice, ast.Slice):
                parts = [None if p is None else self.run(p, scope) for p in (node.slice.lower, node.slice.upper, node.slice.step)]
                return target[slice(*parts)]
            return target[self.run(node.slice, scope)]
        if isinstance(node, ast.Lambda):
            names = [a.arg for a in node.args.args]
            return lambda *args: self.run(node.body, {**scope, **dict(zip(names, args))})
        if isinstance(node, (ast.ListComp, ast.GeneratorExp, ast.SetComp, ast.DictComp)):
            out: list = []
            self._comprehend(node, node.generators, scope, out)
            return dict(out) if isinstance(node, ast.DictComp) else set(out) if isinstance(node, ast.SetComp) else out
        if isinstance(node, ast.JoinedStr):
            return "".join(str(self.run(v, scope)) for v in node.values)
        if isinstance(node, ast.FormattedValue):
            value = self.run(node.value, scope)
            return format(value, self.run(node.format_spec, scope)) if node.format_spec else str(value)
        if isinstance(node, ast.Call):
            args = [self.run(a, scope) for a in node.args]
            kwargs = {k.arg: self.run(k.value, scope) for k in node.keywords if k.arg}
            if isinstance(node.func, ast.Attribute):
                if node.func.attr not in _METHODS:
                    raise ValueError(f"method {node.func.attr!r} is not available")
                return getattr(self.run(node.func.value, scope), node.func.attr)(*args, **kwargs)
            function = self.run(node.func, scope)
            if not callable(function):
                raise ValueError("not a function")
            return function(*args, **kwargs)
        raise ValueError(f"{type(node).__name__} is not supported: use one expression of numbers, lists and arithmetic")

    def _comprehend(self, node, generators, scope, out) -> None:
        if not generators:
            out.append((self.run(node.key, scope), self.run(node.value, scope)) if isinstance(node, ast.DictComp) else self.run(node.elt, scope))
            return
        first = generators[0]
        for item in self.run(first.iter, scope):
            inner = dict(scope)
            if isinstance(first.target, ast.Name):
                inner[first.target.id] = item
            elif isinstance(first.target, ast.Tuple):
                inner.update({t.id: v for t, v in zip(first.target.elts, item) if isinstance(t, ast.Name)})
            if all(self.run(cond, inner) for cond in first.ifs):
                self._comprehend(node, generators[1:], inner, out)


def calculate(expression: str) -> str:
    """Exact result of one Python expression (arithmetic, comparisons, sorting, rounding); never raises."""
    text = str(expression or "").strip().strip("`")
    if not text:
        return "error: no expression given"
    if len(text) > 4000:
        return "error: expression too long"
    try:
        value = _Calc().run(ast.parse(text, mode="eval"), {})
    except SyntaxError as exc:
        return f"error: not a single valid expression ({exc.msg}); statements and assignments are not supported"
    except Exception as exc:  # noqa: BLE001
        return f"error: {type(exc).__name__}: {str(exc)[:200]}"
    if isinstance(value, float) and value.is_integer() and abs(value) < 1e15:
        return f"{value} (= {int(value)})"
    if callable(value):
        return "error: the expression is a function; call it"
    try:
        return json.dumps(value) if isinstance(value, (dict, list, bool)) else str(value)
    except Exception:  # noqa: BLE001
        return str(value)


# ------------------------------------------------------------------ python tool

# Runs in the child before the model's code. The code is written by a model that has read text
# from outside (the challenge, tool results), so it is treated as possibly hostile: an audit hook,
# which cannot be removed once installed, refuses sockets, new processes, ctypes, and any file
# outside the child's own empty directory (the interpreter's own library stays readable). That
# keeps the code away from the network, from .env and from the home directory. It is a guard
# inside the interpreter, not an operating-system sandbox.
PYTHON_GUARD = r"""
import os, sys
def _install():
    real, fsdecode, sep = os.path.realpath, os.fsdecode, os.sep
    root = real(os.getcwd())
    library = set()
    for entry in [sys.prefix, sys.base_prefix, sys.exec_prefix, sys.base_exec_prefix, *sys.path]:
        if entry:
            library.add(real(entry))
    library.discard(root)
    library = tuple(library)
    write_flags = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_APPEND | os.O_TRUNC
    refused = ("socket.", "subprocess.", "ctypes.", "urllib.", "http.", "ftplib.", "smtplib.", "poplib.", "imaplib.",
               "nntplib.", "telnetlib.", "webbrowser.", "os.exec", "os.fork", "os.posix_spawn", "os.spawn", "os.system",
               "os.startfile", "os.kill", "pty.", "winreg.", "mmap.", "shutil.", "os.chmod", "os.chown", "os.symlink", "os.link")
    barred = ("ctypes", "_ctypes", "_posixsubprocess", "subprocess", "_socket", "socket", "multiprocessing", "_multiprocessing",
              "sqlite3", "_sqlite3", "gc", "mmap", "pty", "_posixshmem", "asyncio", "ssl", "_ssl", "dbm", "_dbm", "_gdbm", "shelve")
    paths = ("os.listdir", "os.scandir", "os.remove", "os.rename", "os.rmdir", "os.mkdir", "os.truncate", "os.chdir", "os.walk", "glob.glob")
    def inside(path, base):
        return path == base or path.startswith(base + sep)
    def where(value):
        if isinstance(value, int):  # a file descriptor stands for a place this check cannot see
            raise PermissionError("not available here: files by descriptor")
        return None if value is None else real(fsdecode(value))
    def guard(event, args):
        if event.startswith(refused) or (event == "import" and args and any(part in barred for part in str(args[0]).split("."))):
            raise PermissionError("not available here: no network, no processes, no native code")
        if event == "open":
            if isinstance(args[0], int):  # an existing descriptor (closefd wrappers, pipes): nothing new is reached
                return
            path = where(args[0])
            if path is None or inside(path, root):
                return
            mode, flags = args[1], args[2] if len(args) > 2 else 0
            writing = any(c in mode for c in "wax+") if isinstance(mode, str) else bool((flags or 0) & write_flags)
            if not writing and (path in ("/dev/null", "/dev/urandom", "/dev/random") or any(inside(path, base) for base in library)):
                return
            raise PermissionError("not available here: files outside the working directory")
        if event in paths:
            if any(isinstance(value, int) for value in args[2:]):  # dir_fd: a path relative to somewhere unseen
                raise PermissionError("not available here: files by descriptor")
            for value in args[:2]:
                try:
                    path = where(value)
                except TypeError:
                    continue
                if path is None or inside(path, root):
                    continue
                # The import system lists the interpreter's own library folders.
                if not (event in ("os.listdir", "os.scandir") and any(inside(path, base) for base in library)):
                    raise PermissionError("not available here: files outside the working directory")
    sys.addaudithook(guard)
_install()
del _install
_code = sys.argv[1]
del sys.argv[1:]
exec(compile(_code, "<code>", "exec"), {"__name__": "__main__"})
"""


_OS_SANDBOX: dict[str, object] = {}


def os_sandbox(workdir: str) -> list[str]:
    """The command prefix that puts a child under the operating system's own sandbox, or [].

    PYTHON_GUARD lives inside the interpreter, so code set on escaping it could. Where the machine
    offers one, the child also runs under an operating-system sandbox that takes the network away
    (macOS and Linux) and, on macOS, also every write outside `workdir` and every read under the
    home and project directories other than the interpreter's own files. Whether it works here is
    tried once, with a real child; where it does not, the guard stands alone.
    """
    import os
    import shutil
    import subprocess
    import sys

    def seatbelt(folder: str) -> list[str]:
        real = os.path.realpath
        quoted = lambda path: '"' + real(path).replace("\\", "\\\\").replace('"', '\\"') + '"'  # noqa: E731
        private = {os.path.expanduser("~"), os.getcwd(), os.path.dirname(os.path.abspath(__file__))}
        library = {entry for entry in (sys.prefix, sys.base_prefix, sys.exec_prefix, sys.base_exec_prefix) if entry}
        profile = (
            "(version 1)(allow default)(deny network*)(deny process-fork)(deny appleevent-send)(deny lsopen)"
            f"(deny file-write* (subpath \"/\"))(allow file-write* (subpath {quoted(folder)}) (literal \"/dev/null\"))"
            + "(deny file-read-data " + " ".join(f"(subpath {quoted(path)})" for path in sorted(private)) + ")"
            + "(allow file-read-data " + " ".join(f"(subpath {quoted(path)})" for path in sorted(library | {folder})) + ")"
        )
        return ["/usr/bin/sandbox-exec", "-p", profile]

    if "kind" not in _OS_SANDBOX:
        kind = ""
        candidates = []
        if sys.platform == "darwin" and os.path.exists("/usr/bin/sandbox-exec"):
            candidates.append("seatbelt")
        if sys.platform.startswith("linux") and shutil.which("unshare"):
            candidates.append("unshare")
        for candidate in candidates:
            prefix = seatbelt(workdir) if candidate == "seatbelt" else [shutil.which("unshare") or "unshare", "-rn"]
            try:
                probe = subprocess.run([*prefix, sys.executable, "-I", "-B", "-c", "import json, hashlib; print(41 + 1)"], cwd=workdir,
                                       stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=5.0,
                                       env={"PATH": os.defpath})
                if probe.returncode == 0 and probe.stdout.strip() == "42":
                    kind = candidate
                    break
            except Exception:  # noqa: BLE001 - no sandbox here; the guard still applies
                pass
        _OS_SANDBOX["kind"] = kind
    kind = _OS_SANDBOX["kind"]
    if kind == "seatbelt":
        return seatbelt(workdir)
    if kind == "unshare":
        return [shutil.which("unshare") or "unshare", "-rn"]
    return []


def run_python(code: str, timeout_s: float = 10.0, results: dict[str, Any] | None = None) -> str:
    """Run a snippet of Python in a separate, isolated interpreter and return what it printed.

    `results`, when given, is available to the code as a dict of the same name (tool results the
    model was only shown part of): it is written to a file in the empty working directory and
    loaded before the code runs, so the model never has to retype data.

    This is the general tool for exact work (arithmetic, sorting, decoding,
    decryption, brute force, parsing): the model writes the code, real code
    runs. Isolated mode, an empty working directory, a bare environment,
    resource limits and PYTHON_GUARD keep it from touching the agent, the
    network or the rest of the machine, or running away.
    """
    import os
    import subprocess
    import sys
    import tempfile

    code = str(code or "")
    if not code.strip():
        return "error: no code given"
    if len(code) > 20000:
        return "error: code too long"

    def limits() -> None:  # pragma: no cover - runs in the child
        try:
            import resource

            resource.setrlimit(resource.RLIMIT_CPU, (int(timeout_s) + 2, int(timeout_s) + 2))
            resource.setrlimit(resource.RLIMIT_FSIZE, (1 << 20, 1 << 20))
        except Exception:  # noqa: BLE001
            pass

    child_env = {"PATH": os.defpath, "PYTHONIOENCODING": "utf-8"}
    if os.name == "nt":  # Windows will not start an interpreter without these
        child_env.update({name: os.environ[name] for name in ("SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "TEMP", "TMP") if name in os.environ})
    with tempfile.TemporaryDirectory() as workdir:
        if results:
            try:
                with open(os.path.join(workdir, "results.json"), "w", encoding="utf-8") as handle:
                    json.dump(results, handle, default=str)
                code = "import json as _json\nresults = _json.load(open('results.json', encoding='utf-8'))\n" + code
            except Exception:  # noqa: BLE001 - the code still runs, without the data
                pass
        try:
            proc = subprocess.run(  # noqa: S603 - the interpreter is our own; the code is the model's, behind PYTHON_GUARD
                [*os_sandbox(workdir), sys.executable, "-I", "-B", "-c", PYTHON_GUARD, code], cwd=workdir, stdin=subprocess.DEVNULL, capture_output=True, text=True,
                timeout=max(1.0, timeout_s), env=child_env,
                preexec_fn=limits if os.name == "posix" else None,
            )
        except subprocess.TimeoutExpired:
            return f"error: timed out after {timeout_s:.0f}s"
        except Exception as exc:  # noqa: BLE001
            return f"error: {type(exc).__name__}: {str(exc)[:200]}"
    out = (proc.stdout or "").strip()
    err = (proc.stderr or "").strip()
    if proc.returncode != 0:
        last = err.splitlines()[-1] if err else f"exit code {proc.returncode}"
        return (out[:3000] + "\n" if out else "") + f"error: {last[:400]}"
    if not out:
        return "(no output: print() the result)"
    return out if len(out) <= 6000 else out[:4500] + "\n...\n" + out[-1200:]
